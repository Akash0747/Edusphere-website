import { describe, it, expect, beforeEach } from 'vitest';
import {
  getQuestionPaletteStatus,
  scoreTestAttempt,
  isAnswerCorrect,
} from '../src/core/scoringEngine';
import {
  filterResources,
  filterQuestions,
  getAdaptiveFilterMetadata,
} from '../src/core/searchEngine';
import {
  validateQuestionDataset,
  validateResourceDataset,
} from '../src/core/validator';
import {
  saveActiveTestSession,
  getActiveTestSession,
  saveCompletedAttempt,
  getAttemptHistory,
  computeRemainingSeconds,
  clearAllLocalEduSphereData,
  toggleBookmarkedResource,
  getBookmarkedResourceIds,
} from '../src/core/storage';
import { QUESTIONS_DATASET } from '../src/data/questionsData';
import { STUDY_RESOURCES_DATASET } from '../src/data/resourcesData';
import { MOCK_TESTS_DATASET } from '../src/data/mockTestsData';
import { ActiveTestSession } from '../src/core/types';

describe('EduSphere Core Platform Automated Test Suite', () => {
  beforeEach(() => {
    clearAllLocalEduSphereData();
  });

  describe('1. Content Integrity & Dataset Validation', () => {
    it('validates all 151 production questions (including all 75 JEE Main 2024 Qs & all 52 CBSE Board 2024 Qs) with 0 errors', () => {
      const report = validateQuestionDataset(QUESTIONS_DATASET);
      expect(report.valid).toBe(true);
      expect(report.checkedCount).toBe(151);
      expect(report.errorCount).toBe(0);

      // Verify full 75-Question JEE Main 2024 Paper (25 Phy + 25 Chem + 25 Math)
      const jeeFullTest = MOCK_TESTS_DATASET.find(
        (t) => t.id === 'test-jee-2024-jan-real-pyq'
      )!;
      expect(jeeFullTest.questionIds.length).toBe(75);
      expect(jeeFullTest.durationMinutes).toBe(180);

      // Verify full CBSE Class 12 Board 2024 Papers (16 Phy + 16 Chem + 20 Math = 52 Section-A Qs)
      const cbseCombinedTest = MOCK_TESTS_DATASET.find(
        (t) => t.id === 'test-cbse-2024-set1-real-pyq'
      )!;
      expect(cbseCombinedTest.questionIds.length).toBe(52);
      expect(
        MOCK_TESTS_DATASET.find((t) => t.id === 'test-cbse-2024-phy-set1')!
          .questionIds.length
      ).toBe(16);
      expect(
        MOCK_TESTS_DATASET.find((t) => t.id === 'test-cbse-2024-chem-set1')!
          .questionIds.length
      ).toBe(16);
      expect(
        MOCK_TESTS_DATASET.find((t) => t.id === 'test-cbse-2024-math-set1')!
          .questionIds.length
      ).toBe(20);
    });

    it('validates all 17 study resources including both ready PDFs and honest pending archival entries', () => {
      const report = validateResourceDataset(STUDY_RESOURCES_DATASET);
      expect(report.valid).toBe(true);
      expect(report.checkedCount).toBe(17);
      expect(report.errorCount).toBe(0);

      const readyPdfs = STUDY_RESOURCES_DATASET.filter((r) => r.pdfAvailable);
      const pendingPdfs = STUDY_RESOURCES_DATASET.filter(
        (r) => !r.pdfAvailable
      );
      expect(readyPdfs.length).toBe(14);
      expect(pendingPdfs.length).toBe(3);

      // Every unavailable PDF must have an honest unavailableReason
      for (const pending of pendingPdfs) {
        expect(pending.unavailableReason).toBeTruthy();
        expect(pending.verification.status).toBe('pending_verification');
      }
    });

    it('rejects malformed question imports missing options or verification metadata', () => {
      const badPayload = [
        {
          id: 'BAD-01',
          exam: 'JEE Main',
          classLevel: 'Class 12',
          subject: 'Physics',
          chapter: 'Electrostatics',
          questionType: 'mcq_single',
          questionText: 'Short?',
          options: [{ id: 'A', text: 'Only one option' }],
          correctAnswer: 'Z',
          marksCorrect: 4,
          marksIncorrect: 2, // Invalid positive penalty
        },
      ];
      const report = validateQuestionDataset(badPayload);
      expect(report.valid).toBe(false);
      expect(report.errorCount).toBeGreaterThanOrEqual(4);
    });
  });

  describe('2. Adaptive Search & Filtering Engine', () => {
    it('adapts filter categories and session labels dynamically between JEE Main and CBSE Board', () => {
      const jeeMeta = getAdaptiveFilterMetadata(
        { exam: 'JEE Main', subject: 'ALL', classLevel: 'ALL' },
        STUDY_RESOURCES_DATASET
      );
      expect(jeeMeta.sessionFilterLabel).toBe('JEE Session & Shift');
      expect(jeeMeta.availableCategories).toContain('JEE Main PYQ');
      expect(jeeMeta.availableCategories).not.toContain('Board PYQ');

      const cbseMeta = getAdaptiveFilterMetadata(
        { exam: 'CBSE Board', subject: 'ALL', classLevel: 'ALL' },
        STUDY_RESOURCES_DATASET
      );
      expect(cbseMeta.sessionFilterLabel).toBe('Board Paper Set / Code');
      expect(cbseMeta.availableCategories).toContain('Board PYQ');
      expect(cbseMeta.availableCategories).not.toContain('JEE Main PYQ');
    });

    it('filters resources accurately by multi-token search query and pdfAvailable toggle', () => {
      const results = filterResources(STUDY_RESOURCES_DATASET, {
        searchQuery: 'Electrostatics JEE',
        exam: 'ALL',
        classLevel: 'ALL',
        subject: 'ALL',
        chapter: 'ALL',
        year: 'ALL',
        sessionOrSet: 'ALL',
        category: 'ALL',
        onlyPdfAvailable: true,
      });
      expect(results.length).toBeGreaterThanOrEqual(1);
      expect(results[0].pdfAvailable).toBe(true);
      expect(results[0].subject).toBe('Physics');
    });

    it('filters questions by diagram presence and difficulty', () => {
      const withDiagrams = filterQuestions(QUESTIONS_DATASET, {
        searchQuery: '',
        exam: 'ALL',
        classLevel: 'ALL',
        subject: 'ALL',
        chapter: 'ALL',
        difficulty: 'ALL',
        verificationStatus: 'ALL',
        onlyWithDiagrams: true,
      });
      expect(withDiagrams.length).toBe(7);
      for (const q of withDiagrams) {
        expect(q.diagram).toBeDefined();
        expect(q.diagram?.svgContent).toContain('<svg');
      }
    });
  });

  describe('3. Question Palette Status & Mock Test Scoring Engine', () => {
    it('computes all 5 question palette states accurately', () => {
      expect(getQuestionPaletteStatus(undefined)).toBe('not_visited');
      expect(
        getQuestionPaletteStatus({
          questionId: 'Q1',
          selectedOption: null,
          markedForReview: false,
          visited: true,
          timeSpentSeconds: 5,
        })
      ).toBe('not_answered');
      expect(
        getQuestionPaletteStatus({
          questionId: 'Q1',
          selectedOption: 'A',
          markedForReview: false,
          visited: true,
          timeSpentSeconds: 10,
        })
      ).toBe('answered');
      expect(
        getQuestionPaletteStatus({
          questionId: 'Q1',
          selectedOption: null,
          markedForReview: true,
          visited: true,
          timeSpentSeconds: 8,
        })
      ).toBe('marked_for_review');
      expect(
        getQuestionPaletteStatus({
          questionId: 'Q1',
          selectedOption: 'B',
          markedForReview: true,
          visited: true,
          timeSpentSeconds: 12,
        })
      ).toBe('answered_marked_for_review');
    });

    it('scores JEE Main (+4 / -1 / 0) with negative marking and distinguishes Percentage vs Accuracy', () => {
      const jeePhysicsTest = MOCK_TESTS_DATASET.find(
        (t) => t.id === 'test-jee-phy-elec-curr'
      )!;
      // 5 questions, +4 correct, -1 incorrect, 0 unanswered (Max score = 20)
      // Let's answer 3 correctly (+12), 1 incorrectly (-1), and leave 1 unanswered (0) => Total Score = 11 / 20
      const qIds = jeePhysicsTest.questionIds;
      const qMap = new Map(QUESTIONS_DATASET.map((q) => [q.id, q]));

      const wrongOptionForQ3 =
        qMap.get(qIds[3])!.correctAnswer === 'A' ? 'B' : 'A';

      const session: ActiveTestSession = {
        sessionId: 'unit-test-jee-1',
        testId: jeePhysicsTest.id,
        startedAtIso: new Date().toISOString(),
        lastUpdatedAtIso: new Date().toISOString(),
        durationSeconds: 1080,
        elapsedSecondsBeforeResume: 420,
        lastTickTimestampMs: Date.now(),
        currentQuestionIndex: 0,
        isSubmitted: true,
        responses: {
          [qIds[0]]: {
            questionId: qIds[0],
            selectedOption: qMap.get(qIds[0])!.correctAnswer,
            markedForReview: false,
            visited: true,
            timeSpentSeconds: 90,
          },
          [qIds[1]]: {
            questionId: qIds[1],
            selectedOption: qMap.get(qIds[1])!.correctAnswer,
            markedForReview: false,
            visited: true,
            timeSpentSeconds: 100,
          },
          [qIds[2]]: {
            questionId: qIds[2],
            selectedOption: qMap.get(qIds[2])!.correctAnswer,
            markedForReview: true,
            visited: true,
            timeSpentSeconds: 80,
          },
          [qIds[3]]: {
            questionId: qIds[3],
            selectedOption: wrongOptionForQ3,
            markedForReview: false,
            visited: true,
            timeSpentSeconds: 90,
          },
          [qIds[4]]: {
            questionId: qIds[4],
            selectedOption: null,
            markedForReview: false,
            visited: true,
            timeSpentSeconds: 60,
          },
        },
      };

      const result = scoreTestAttempt(
        jeePhysicsTest,
        QUESTIONS_DATASET,
        session,
        'manual_submit'
      );

      expect(result.maxScore).toBe(20);
      expect(result.positiveMarksEarned).toBe(12);
      expect(result.negativeMarksDeducted).toBe(1);
      expect(result.totalScore).toBe(11);
      expect(result.correctCount).toBe(3);
      expect(result.incorrectCount).toBe(1);
      expect(result.unansweredCount).toBe(1);
      expect(result.attemptedCount).toBe(4);

      // Percentage = (11 / 20) * 100 = 55%
      expect(result.percentage).toBe(55);
      // Accuracy = (3 / 4) * 100 = 75%
      expect(result.accuracy).toBe(75);
      expect(result.feedbackTier).toBe('good');

      // Mistake analysis must separate measuredFacts from possibleExplanations
      expect(result.mistakeAnalysis.length).toBe(2);
      expect(result.mistakeAnalysis[0].measuredFacts.length).toBeGreaterThan(0);
      expect(
        result.mistakeAnalysis[0].possibleExplanations.length
      ).toBeGreaterThan(0);
    });

    it('scores CBSE Board (+1 / 0 / 0) with zero negative marking', () => {
      const cbseTest = MOCK_TESTS_DATASET.find(
        (t) => t.id === 'test-cbse-11-foundation'
      )!;
      const qIds = cbseTest.questionIds;
      const qMap = new Map(QUESTIONS_DATASET.map((q) => [q.id, q]));

      // Answer 1 correctly (+1) and 5 incorrectly (0 penalty)
      const responses: ActiveTestSession['responses'] = {};
      qIds.forEach((id, idx) => {
        const correct = qMap.get(id)!.correctAnswer;
        responses[id] = {
          questionId: id,
          selectedOption: idx === 0 ? correct : correct === 'A' ? 'B' : 'A',
          markedForReview: false,
          visited: true,
          timeSpentSeconds: 30,
        };
      });

      const session: ActiveTestSession = {
        sessionId: 'unit-test-cbse-1',
        testId: cbseTest.id,
        startedAtIso: new Date().toISOString(),
        lastUpdatedAtIso: new Date().toISOString(),
        durationSeconds: 1200,
        elapsedSecondsBeforeResume: 180,
        lastTickTimestampMs: Date.now(),
        currentQuestionIndex: 0,
        isSubmitted: true,
        responses,
      };

      const result = scoreTestAttempt(
        cbseTest,
        QUESTIONS_DATASET,
        session,
        'timer_expired'
      );

      expect(result.submissionReason).toBe('timer_expired');
      expect(result.positiveMarksEarned).toBe(1);
      expect(result.negativeMarksDeducted).toBe(0);
      expect(result.totalScore).toBe(1);
      expect(result.feedbackTier).toBe('developing');
      expect(result.feedbackHeadline).toBe(
        "Let's strengthen a few topics before your next attempt."
      );
    });
  });

  describe('4. Local Session Persistence, Timer Calculation & Duplicate Submission Prevention', () => {
    it('persists active session, computes remaining time accurately, and prevents duplicate submission', () => {
      const now = 1_700_000_000_000;
      const session: ActiveTestSession = {
        sessionId: 'persist-101',
        testId: 'test-jee-phy-elec-curr',
        startedAtIso: new Date(now).toISOString(),
        lastUpdatedAtIso: new Date(now).toISOString(),
        durationSeconds: 600,
        elapsedSecondsBeforeResume: 120,
        lastTickTimestampMs: now,
        currentQuestionIndex: 2,
        responses: {},
        isSubmitted: false,
      };

      saveActiveTestSession(session);
      const loaded = getActiveTestSession('test-jee-phy-elec-curr');
      expect(loaded).not.toBeNull();
      expect(loaded?.currentQuestionIndex).toBe(2);

      // 30 seconds later, total elapsed = 120 + 30 = 150s => remaining = 600 - 150 = 450s
      const rem = computeRemainingSeconds(loaded!, now + 30_000);
      expect(rem).toBe(450);

      // Score and save completed attempt twice to test duplicate prevention
      const testConfig = MOCK_TESTS_DATASET.find(
        (t) => t.id === 'test-jee-phy-elec-curr'
      )!;
      const result = scoreTestAttempt(
        testConfig,
        QUESTIONS_DATASET,
        session,
        'manual_submit'
      );

      const firstSave = saveCompletedAttempt(result);
      expect(firstSave.saved).toBe(true);
      expect(firstSave.alreadyExisted).toBe(false);

      // Active session should be automatically cleared on submission
      expect(getActiveTestSession('test-jee-phy-elec-curr')).toBeNull();

      // Second save of same attemptId must be rejected as duplicate
      const secondSave = saveCompletedAttempt(result);
      expect(secondSave.saved).toBe(false);
      expect(secondSave.alreadyExisted).toBe(true);
      expect(getAttemptHistory().length).toBe(1);
    });

    it('toggles bookmarks and clears all local data cleanly', () => {
      toggleBookmarkedResource('res-jee-2025-phy-elec-paper');
      expect(getBookmarkedResourceIds()).toContain(
        'res-jee-2025-phy-elec-paper'
      );

      clearAllLocalEduSphereData();
      expect(getBookmarkedResourceIds().length).toBe(0);
      expect(getAttemptHistory().length).toBe(0);
    });

    it('matches numerical and MCQ answers accurately', () => {
      const q = QUESTIONS_DATASET[0];
      expect(isAnswerCorrect(q, q.correctAnswer)).toBe(true);
      expect(isAnswerCorrect(q, '  ' + q.correctAnswer.toLowerCase() + ' ')).toBe(
        true
      );
      expect(isAnswerCorrect(q, null)).toBe(false);
    });
  });
});
