# EduSphere — Open-Access Academic Study Platform (Class 11, Class 12 & JEE Main)

EduSphere is a free, open-access educational web platform built for students preparing for **CBSE Class 11**, **CBSE Class 12 Board Examinations**, and **JEE Main**.

It provides a Study-Material Library with downloadable multi-page PDFs, an interactive Chapter-Wise Question Bank with vector diagrams, a distraction-free Mock-Test Engine with configurable marking schemes (`+4 / −1 / 0` for JEE Main and `+1 / 0 / 0` for CBSE Section A), and an Evidence-Based Mistake Analysis engine—all with **zero mandatory registration or paywalls**.

---

## 1. Project Directory Structure

```text
/home/user
├── index.html                        # Application HTML entry & metadata
├── package.json                      # Dependencies & npm scripts
├── tsconfig.json                     # Strict TypeScript configuration
├── vite.config.ts                    # Vite dev/build config + /api/v1 REST middleware
├── tailwind.config.js                # Deep Navy & Academic Indigo design tokens
├── postcss.config.js                 # PostCSS configuration
├── .env.example                      # Documented environment variables (no secrets)
├── public/
│   ├── favicon.svg                   # Original EduSphere vector brand mark
│   └── pdfs/                         # Real 2-page PDF papers & worked solution keys
│       ├── res-jee-2025-phy-elec-paper.pdf
│       ├── res-cbse-2025-phy-sample.pdf
│       ├── res-jee-2024-chem-pyq-solutions.pdf
│       ├── res-jee-2025-math-calc-paper.pdf
│       ├── res-cbse-2025-math-sample.pdf
│       ├── res-cbse-2025-chem-sample.pdf
│       ├── res-class11-phy-mech-therm.pdf
│       ├── res-class11-chem-atom-bond.pdf
│       └── res-official-marking-reference-2025.pdf
├── scripts/
│   ├── generate_pdfs.py              # Reproducible Python 3 generator for study PDFs
│   └── validate_content.ts           # CLI dataset & PDF file integrity validator
├── src/
│   ├── main.tsx                      # React DOM entry point
│   ├── App.tsx                       # Application router & Light/Dark theme controller
│   ├── index.css                     # Tailwind CSS + reduced-motion accessibility rules
│   ├── core/                         # UI-agnostic domain logic (Android-reusable)
│   │   ├── types.ts                  # Strict TypeScript interfaces for entire domain
│   │   ├── scoringEngine.ts          # Configurable marking & mistake analysis engine
│   │   ├── searchEngine.ts           # Multi-token search & exam-adaptive filter logic
│   │   ├── validator.ts              # Schema & provenance integrity validator
│   │   └── storage.ts                # LocalStorage session, timer & history manager
│   ├── data/                         # Structured, validated academic content repository
│   │   ├── questionsData.ts          # 24 verified Physics, Chemistry & Maths questions
│   │   ├── resourcesData.ts          # 12 study resources (9 ready PDFs + 3 honest pending)
│   │   └── mockTestsData.ts          # 6 chapter-wise & full-length mock test configs
│   ├── components/
│   │   ├── Navbar.tsx                # Responsive header + Resume Active Test indicator
│   │   ├── Footer.tsx                # Academic footer + Local Storage privacy notice
│   │   ├── VerificationBadge.tsx     # Provenance status badge component
│   │   ├── DiagramView.tsx           # Aspect-ratio preserving SVG diagram renderer
│   │   ├── ResourceCard.tsx          # Study material card with working PDF & test actions
│   │   └── PdfViewerModal.tsx        # Dual Structured Reader + Embedded PDF viewer
│   └── pages/
│       ├── HomePage.tsx              # Hero search, 4 main categories, featured study sets
│       ├── LibraryPage.tsx           # Adaptive filter library + URL-preserved filter state
│       ├── PracticePage.tsx          # Interactive Question Bank + Revision mode
│       ├── MockTestsPage.tsx         # Mock test directory + Resume/Retake controls
│       ├── TestEnginePage.tsx        # Distraction-free timed exam UI + Question Palette
│       ├── TestResultPage.tsx        # Score, % vs Accuracy, Mistake Analysis & Review
│       ├── ProgressPage.tsx          # Local attempt history, bookmarks & Clear Data
│       └── ArchitecturePage.tsx      # Interactive JSON validator & Android roadmap
└── tests/
    └── edusphere.test.ts             # Automated Vitest suite (12 unit & integration tests)
```

---

## 2. Installation, Running & Testing Instructions

### Prerequisites
- **Node.js** `v18+` (tested on `v20.20.2`) and **npm** `v9+`
- **Python 3** (optional, only needed if regenerating PDFs via `npm run generate:pdfs`)

### Install Dependencies
```bash
npm install
```

### Start the Local Development Server (Frontend + `/api/v1` REST Middleware)
```bash
npm run dev
```
The server binds to `0.0.0.0:5173`.

### Run Automated Content Integrity & Schema Validation
```bash
npm run validate:content
```

### Run Automated Unit & Integration Tests (Vitest)
```bash
npm test
```

### Build for Production
```bash
npm run build
npm run preview
```

---

## 3. Adding Verified Educational Content

1. **Author or Import Questions**: Follow the `Question` interface in `src/core/types.ts`. Every question must include explicit `verification` metadata (`verified_official_key`, `independently_prepared_solution`, `edusphere_original_practice`, or `pending_verification`), `source`, and `contentVersion`.
2. **Validate via UI or CLI**: Paste the candidate JSON array into the **Interactive Question Dataset Schema Validator** at `/architecture` or add it to `src/data/questionsData.ts` and run `npm run validate:content`.
3. **Generate or Attach PDFs**: Place verified PDF files in `public/pdfs/` (or update `scripts/generate_pdfs.py` and run `npm run generate:pdfs`). Run `npm run validate:content` to confirm every `pdfAvailable: true` entry has a matching file on disk.
