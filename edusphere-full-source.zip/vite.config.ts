import { defineConfig, Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { QUESTIONS_DATASET } from './src/data/questionsData';
import { STUDY_RESOURCES_DATASET } from './src/data/resourcesData';
import { MOCK_TESTS_DATASET } from './src/data/mockTestsData';
import { validateQuestionDataset } from './src/core/validator';
import { scoreTestAttempt } from './src/core/scoringEngine';

function edusphereApiPlugin(): Plugin {
  return {
    name: 'edusphere-api-middleware',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url || !req.url.startsWith('/api/v1/')) {
          return next();
        }

        const urlObj = new URL(req.url, 'http://localhost');
        const pathname = urlObj.pathname;

        const sendJson = (status: number, payload: unknown) => {
          res.statusCode = status;
          res.setHeader('Content-Type', 'application/json; charset=utf-8');
          res.setHeader('Cache-Control', 'no-store');
          res.end(JSON.stringify(payload));
        };

        if (req.method === 'GET' && pathname === '/api/v1/health') {
          return sendJson(200, {
            status: 'ok',
            service: 'EduSphere Academic Content & Test Engine API',
            version: '1.0.0',
            counts: {
              resources: STUDY_RESOURCES_DATASET.length,
              questions: QUESTIONS_DATASET.length,
              mockTests: MOCK_TESTS_DATASET.length,
            },
            androidReady: true,
          });
        }

        if (req.method === 'GET' && pathname === '/api/v1/resources') {
          const exam = urlObj.searchParams.get('exam');
          const subject = urlObj.searchParams.get('subject');
          const classLevel = urlObj.searchParams.get('classLevel');
          let items = [...STUDY_RESOURCES_DATASET];
          if (exam && exam !== 'ALL') {
            items = items.filter((r) => r.exam === exam);
          }
          if (subject && subject !== 'ALL') {
            items = items.filter((r) => r.subject === subject);
          }
          if (classLevel && classLevel !== 'ALL') {
            items = items.filter(
              (r) =>
                r.classLevel === classLevel || r.classLevel === 'Class 11 & 12'
            );
          }
          return sendJson(200, {
            count: items.length,
            resources: items,
          });
        }

        if (req.method === 'GET' && pathname === '/api/v1/questions') {
          const exam = urlObj.searchParams.get('exam');
          const subject = urlObj.searchParams.get('subject');
          let items = [...QUESTIONS_DATASET];
          if (exam && exam !== 'ALL') {
            items = items.filter((q) => q.exam === exam);
          }
          if (subject && subject !== 'ALL') {
            items = items.filter((q) => q.subject === subject);
          }
          return sendJson(200, {
            count: items.length,
            questions: items,
          });
        }

        if (req.method === 'GET' && pathname === '/api/v1/tests') {
          return sendJson(200, {
            count: MOCK_TESTS_DATASET.length,
            tests: MOCK_TESTS_DATASET,
          });
        }

        if (req.method === 'POST' && pathname === '/api/v1/validate-content') {
          let body = '';
          req.on('data', (chunk) => {
            body += chunk;
          });
          req.on('end', () => {
            try {
              const parsed = JSON.parse(body);
              const report = validateQuestionDataset(parsed);
              return sendJson(200, report);
            } catch {
              return sendJson(400, {
                valid: false,
                error: 'Invalid JSON payload provided.',
              });
            }
          });
          return;
        }

        if (req.method === 'POST' && pathname === '/api/v1/score') {
          let body = '';
          req.on('data', (chunk) => {
            body += chunk;
          });
          req.on('end', () => {
            try {
              const { testId, session, submissionReason } = JSON.parse(body);
              const testConfig = MOCK_TESTS_DATASET.find(
                (t) => t.id === testId
              );
              if (!testConfig || !session) {
                return sendJson(400, {
                  error: 'Missing valid testId or session object.',
                });
              }
              const result = scoreTestAttempt(
                testConfig,
                QUESTIONS_DATASET,
                session,
                submissionReason || 'manual_submit'
              );
              return sendJson(200, result);
            } catch {
              return sendJson(400, {
                error: 'Failed to process test scoring payload.',
              });
            }
          });
          return;
        }

        return sendJson(404, {
          error: `Unknown API route: ${pathname}`,
        });
      });
    },
  };
}

export default defineConfig({
  plugins: [react(), edusphereApiPlugin()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,
  },
  preview: {
    host: '0.0.0.0',
    port: 4173,
    allowedHosts: true,
  },
});
