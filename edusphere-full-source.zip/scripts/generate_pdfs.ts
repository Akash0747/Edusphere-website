import fs from 'fs';
import path from 'path';
import { STUDY_RESOURCES_DATASET } from '../src/data/resourcesData';
import { QUESTIONS_DATASET } from '../src/data/questionsData';
import { Question } from '../src/core/types';

const OUTPUT_DIR = path.resolve(process.cwd(), 'public', 'pdfs');

function sanitizePdfText(input: string): string {
  const replacements: Record<string, string> = {
    '×': 'x',
    '⁻': '-',
    '⁰': '^0',
    '¹': '^1',
    '²': '^2',
    '³': '^3',
    '⁴': '^4',
    '⁵': '^5',
    '⁶': '^6',
    '⁷': '^7',
    '⁸': '^8',
    '⁹': '^9',
    '₀': '_0',
    '₁': '_1',
    '₂': '_2',
    '₃': '_3',
    '₄': '_4',
    '₅': '_5',
    '₆': '_6',
    '₇': '_7',
    '₈': '_8',
    '₉': '_9',
    '°': ' deg',
    'θ': 'theta',
    'τ': 'tau',
    'φ': 'phi',
    'μ': 'mu',
    'π': 'pi',
    'λ': 'lambda',
    'ω': 'omega',
    'α': 'alpha',
    'β': 'beta',
    'γ': 'gamma',
    'ε': 'eps',
    'σ': 'sigma',
    'ρ': 'rho',
    'χ': 'chi',
    'ν': 'nu',
    'Δ': 'Delta ',
    'Φ': 'Phi',
    'Λ': 'Lambda',
    'Ω': 'Ohm',
    '√': 'sqrt',
    '⇒': '=>',
    '→': '->',
    '⇌': '<=>',
    '−': '-',
    '—': '--',
    '–': '-',
    '’': "'",
    '‘': "'",
    '“': '"',
    '”': '"',
    '≈': '~=',
    '≠': '!=',
    '≤': '<=',
    '≥': '>=',
    '≪': '<<',
    '≫': '>>',
    '∝': ' prop ',
    '∞': 'inf',
    '∫': 'Integral ',
    '∑': 'Sum ',
    '∈': ' in ',
    '∉': ' not-in ',
    '⊆': ' subset ',
    '∪': ' U ',
    '∩': ' cap ',
    '±': '+/-',
    '⃗': '',
    '̂': '_hat',
    '′': "'",
    '″': "''",
    '•': '*',
    'ℝ': 'R',
    'ℤ': 'Z',
    'ℕ': 'N',
    '⁺': '+',
    'ⁿ': '^n',
    '·': '.',
    '½': '1/2',
  };

  let text = input;
  for (const [k, v] of Object.entries(replacements)) {
    text = text.split(k).join(v);
  }
  let cleaned = '';
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    cleaned += code >= 32 && code <= 126 ? text[i] : ' ';
  }
  return cleaned.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
}

function wrapText(text: string, maxWidth = 90): string[] {
  const paragraphs = text.split('\n');
  const lines: string[] = [];
  for (const para of paragraphs) {
    const words = para.trim().split(/\s+/);
    if (words.length === 0 || (words.length === 1 && words[0] === '')) continue;
    let current = words[0];
    for (let i = 1; i < words.length; i++) {
      if ((current + ' ' + words[i]).length <= maxWidth) {
        current += ' ' + words[i];
      } else {
        lines.push(current);
        current = words[i];
      }
    }
    if (current) lines.push(current);
  }
  return lines.length > 0 ? lines : [''];
}

interface PdfLineSpec {
  font: 'F1' | 'F2';
  size: number;
  leading: number;
  text: string;
}

function buildMultiPagePdf(lines: PdfLineSpec[], docTitle: string): Buffer {
  // Paginate lines into pages
  const pages: PdfLineSpec[][] = [];
  let currentPage: PdfLineSpec[] = [];
  let y = 755;

  const pushPage = () => {
    if (currentPage.length > 0) {
      pages.push(currentPage);
      currentPage = [];
      y = 755;
    }
  };

  for (const line of lines) {
    if (y - line.leading < 68 && currentPage.length > 0) {
      pushPage();
    }
    currentPage.push(line);
    y -= line.leading;
  }
  pushPage();

  const totalPages = Math.max(1, pages.length);

  // Build page streams with footer page numbers
  const pageStreams: Buffer[] = pages.map((pageLines, pageIdx) => {
    const ops: string[] = ['BT'];
    let curY = 755;
    ops.push('1 0 0 1 45 755 Tm');
    let lastY = 755;

    for (let i = 0; i < pageLines.length; i++) {
      const item = pageLines[i];
      const targetY = i === 0 ? 755 : curY - item.leading;
      const dy = targetY - lastY;
      curY = targetY;
      lastY = curY;
      ops.push(`/${item.font} ${item.size} Tf`);
      ops.push(`0 ${dy} Td`);
      ops.push(`(${sanitizePdfText(item.text)}) Tj`);
    }

    // Footer at y = 38
    const footerDy = 38 - lastY;
    ops.push('/F1 8 Tf');
    ops.push(`0 ${footerDy} Td`);
    ops.push(
      `(${sanitizePdfText(
        `EduSphere Open-Access Study Platform  |  ${docTitle.slice(0, 64)}  |  Page ${pageIdx + 1} of ${totalPages}`
      )}) Tj`
    );
    ops.push('ET');

    const rules =
      '0.06 0.09 0.16 RG 1.2 w 45 738 m 550 738 l S 0.75 0.78 0.84 RG 0.7 w 45 50 m 550 50 l S\n';
    return Buffer.from(rules + ops.join('\n'), 'latin1');
  });

  // Object numbering:
  // 1: Catalog
  // 2: Pages
  // 3: Font F1 (Helvetica)
  // 4: Font F2 (Helvetica-Bold)
  // For each page i (0..totalPages-1):
  //   pageObjId = 5 + 2*i
  //   contentObjId = 6 + 2*i
  const objects: Map<number, Buffer> = new Map();
  objects.set(1, Buffer.from('<< /Type /Catalog /Pages 2 0 R >>', 'latin1'));

  const kidsRefs: string[] = [];
  for (let i = 0; i < totalPages; i++) {
    kidsRefs.push(`${5 + 2 * i} 0 R`);
  }
  objects.set(
    2,
    Buffer.from(
      `<< /Type /Pages /Kids [${kidsRefs.join(' ')}] /Count ${totalPages} >>`,
      'latin1'
    )
  );
  objects.set(
    3,
    Buffer.from('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>', 'latin1')
  );
  objects.set(
    4,
    Buffer.from('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>', 'latin1')
  );

  for (let i = 0; i < totalPages; i++) {
    const pageObjId = 5 + 2 * i;
    const contentObjId = 6 + 2 * i;
    const streamBuf = pageStreams[i];
    objects.set(
      pageObjId,
      Buffer.from(
        `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentObjId} 0 R >>`,
        'latin1'
      )
    );
    const header = Buffer.from(`<< /Length ${streamBuf.length} >>\nstream\n`, 'latin1');
    const footer = Buffer.from('\nendstream', 'latin1');
    objects.set(contentObjId, Buffer.concat([header, streamBuf, footer]));
  }

  const maxObjId = 4 + 2 * totalPages;
  const chunks: Buffer[] = [Buffer.from('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n', 'latin1')];
  let currentLength = chunks[0].length;
  const offsets: number[] = [0];

  for (let objId = 1; objId <= maxObjId; objId++) {
    offsets[objId] = currentLength;
    const objHeader = Buffer.from(`${objId} 0 obj\n`, 'latin1');
    const objBody = objects.get(objId)!;
    const objFooter = Buffer.from('\nendobj\n', 'latin1');
    chunks.push(objHeader, objBody, objFooter);
    currentLength += objHeader.length + objBody.length + objFooter.length;
  }

  const xrefOffset = currentLength;
  const xrefLines = [`xref\n0 ${maxObjId + 1}\n`, '0000000000 65535 f \n'];
  for (let objId = 1; objId <= maxObjId; objId++) {
    xrefLines.push(`${String(offsets[objId]).padStart(10, '0')} 00000 n \n`);
  }
  const trailer =
    xrefLines.join('') +
    `trailer\n<< /Size ${maxObjId + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;
  chunks.push(Buffer.from(trailer, 'latin1'));

  return Buffer.concat(chunks);
}

function main() {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  const questionsMap = new Map<string, Question>(QUESTIONS_DATASET.map((q) => [q.id, q]));

  let generatedCount = 0;
  for (const res of STUDY_RESOURCES_DATASET) {
    if (!res.pdfAvailable || !res.pdfUrl) continue;

    const lines: PdfLineSpec[] = [
      {
        font: 'F2',
        size: 13,
        leading: 0,
        text: 'EDUSPHERE ACADEMIC STUDY PLATFORM  |  COMPLETE QUESTION PAPER & SOLUTIONS',
      },
      {
        font: 'F1',
        size: 8.5,
        leading: 13,
        text: `Resource ID: ${res.id}  |  Exam: ${res.exam} (${res.classLevel})  |  Subject: ${res.subject}  |  Year: ${res.year}`,
      },
      {
        font: 'F2',
        size: 11,
        leading: 22,
        text: res.title,
      },
      {
        font: 'F1',
        size: 9,
        leading: 13,
        text: `Provenance: ${res.verification.label} -- ${res.verification.source}`,
      },
    ];

    // Add documentPreview sections (including CBSE Sections B, C, D, E or summary notes)
    if (res.documentPreview && res.documentPreview.length > 0) {
      for (const sec of res.documentPreview) {
        lines.push({
          font: 'F2',
          size: 10,
          leading: 18,
          text: sec.heading,
        });
        for (const bullet of sec.content) {
          const wrapped = wrapText(bullet, 92);
          wrapped.forEach((wline, idx) => {
            lines.push({
              font: 'F1',
              size: 8.8,
              leading: 12,
              text: idx === 0 ? `  * ${wline}` : `    ${wline}`,
            });
          });
        }
      }
    }

    // Add all linked questions + options
    const linkedQuestions = res.linkedQuestionIds
      .map((id) => questionsMap.get(id))
      .filter((q): q is Question => Boolean(q));

    if (linkedQuestions.length > 0) {
      lines.push({
        font: 'F2',
        size: 10.5,
        leading: 20,
        text: `COMPLETE QUESTION SET (${linkedQuestions.length} VERIFIED QUESTIONS)`,
      });

      linkedQuestions.forEach((q, idx) => {
        lines.push({
          font: 'F2',
          size: 9.2,
          leading: 15,
          text: `Q.${idx + 1} [${q.id}] (${q.subject} - ${q.chapter} | +${q.marksCorrect}/${q.marksIncorrect})`,
        });
        for (const wline of wrapText(q.questionText, 92)) {
          lines.push({
            font: 'F1',
            size: 8.8,
            leading: 11.5,
            text: `   ${wline}`,
          });
        }
        const opts = q.options ?? [];
        const optA = opts[0] ? `(A) ${opts[0].text}` : '';
        const optB = opts[1] ? `(B) ${opts[1].text}` : '';
        const optC = opts[2] ? `(C) ${opts[2].text}` : '';
        const optD = opts[3] ? `(D) ${opts[3].text}` : '';
        for (const wopt of wrapText(`   ${optA}    |    ${optB}`, 94)) {
          lines.push({ font: 'F1', size: 8.5, leading: 11, text: wopt });
        }
        for (const wopt of wrapText(`   ${optC}    |    ${optD}`, 94)) {
          lines.push({ font: 'F1', size: 8.5, leading: 11, text: wopt });
        }
      });

      // Add Official Answer Key & Worked Solutions Section
      lines.push({
        font: 'F2',
        size: 10.5,
        leading: 22,
        text: `OFFICIAL ANSWER KEY & STEP-BY-STEP WORKED SOLUTIONS (${linkedQuestions.length} QUESTIONS)`,
      });

      linkedQuestions.forEach((q, idx) => {
        const correctOpt = (q.options ?? []).find((o) => o.id === q.correctAnswer);
        lines.push({
          font: 'F2',
          size: 9,
          leading: 14,
          text: `Q.${idx + 1} [${q.id}] -> Correct Option: (${q.correctAnswer}) ${correctOpt ? correctOpt.text : ''}`,
        });
        for (const wexp of wrapText(`Solution: ${q.explanation}`, 94)) {
          lines.push({
            font: 'F1',
            size: 8.5,
            leading: 11,
            text: `   ${wexp}`,
          });
        }
      });
    }

    const pdfBuffer = buildMultiPagePdf(lines, res.title);
    const filename = path.basename(res.pdfUrl);
    const outPath = path.join(OUTPUT_DIR, filename);
    fs.writeFileSync(outPath, pdfBuffer);
    generatedCount++;
    console.log(
      `[PDF OK] ${filename} (${(pdfBuffer.length / 1024).toFixed(1)} KB, ${linkedQuestions.length} questions)`
    );
  }

  console.log(`\nSuccessfully generated ${generatedCount} multi-page PDF study documents in ${OUTPUT_DIR}`);
}

main();
