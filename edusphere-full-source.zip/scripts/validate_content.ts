import fs from 'node:fs';
import path from 'node:path';
import { QUESTIONS_DATASET } from '../src/data/questionsData';
import { STUDY_RESOURCES_DATASET } from '../src/data/resourcesData';
import { MOCK_TESTS_DATASET } from '../src/data/mockTestsData';
import {
  validateQuestionDataset,
  validateResourceDataset,
} from '../src/core/validator';

function main() {
  console.log('=== EduSphere Content & Integrity Validation ===');

  const qReport = validateQuestionDataset(QUESTIONS_DATASET);
  console.log(
    `Questions Checked: ${qReport.checkedCount} | Errors: ${qReport.errorCount} | Warnings: ${qReport.warningCount}`
  );
  if (!qReport.valid) {
    console.error('Question Validation Issues:', qReport.issues);
    process.exit(1);
  }

  const rReport = validateResourceDataset(STUDY_RESOURCES_DATASET);
  console.log(
    `Resources Checked: ${rReport.checkedCount} | Errors: ${rReport.errorCount} | Warnings: ${rReport.warningCount}`
  );
  if (!rReport.valid) {
    console.error('Resource Validation Issues:', rReport.issues);
    process.exit(1);
  }

  // Verify that every pdfAvailable=true resource has an actual file on disk
  const publicDir = path.resolve(process.cwd(), 'public');
  let missingPdfs = 0;
  for (const r of STUDY_RESOURCES_DATASET) {
    if (r.pdfAvailable && r.pdfUrl) {
      const diskPath = path.join(publicDir, r.pdfUrl);
      if (!fs.existsSync(diskPath)) {
        console.error(`Missing PDF file on disk for ${r.id}: ${diskPath}`);
        missingPdfs += 1;
      }
    }
  }

  // Verify that every MockTestConfig references valid Question IDs
  const qIdSet = new Set(QUESTIONS_DATASET.map((q) => q.id));
  let brokenTestLinks = 0;
  for (const t of MOCK_TESTS_DATASET) {
    for (const qId of t.questionIds) {
      if (!qIdSet.has(qId)) {
        console.error(`MockTest ${t.id} references unknown Question ID: ${qId}`);
        brokenTestLinks += 1;
      }
    }
  }

  if (missingPdfs > 0 || brokenTestLinks > 0) {
    process.exit(1);
  }

  console.log(
    `Mock Tests Checked: ${MOCK_TESTS_DATASET.length} | All question references & PDF files verified!`
  );
}

main();
