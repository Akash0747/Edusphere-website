import { Question } from '../core/types';
import { JEE_2024_FULL_75_QUESTIONS } from './jee2024Full75Questions';
import { CBSE_2024_FULL_BOARD_QUESTIONS } from './cbse2024FullBoardQuestions';

export const QUESTIONS_DATASET: Question[] = [
  // ======================== PHYSICS ========================
  {
    id: 'PHY-12-ELEC-001',
    exam: 'JEE Main',
    classLevel: 'Class 12',
    subject: 'Physics',
    chapter: 'Electrostatics',
    topic: 'Electric Dipole in a Uniform External Field',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'An electric dipole of dipole moment p = 4.0 × 10⁻⁸ C·m is aligned at an angle θ = 30° with the direction of a uniform electric field of magnitude E = 5.0 × 10⁴ N/C. What is the magnitude of the torque acting on the dipole and the work required to rotate it slowly from θ₁ = 30° to θ₂ = 90°?',
    diagram: {
      id: 'diag-dipole-field',
      title: 'Electric Dipole in Uniform Field E',
      altText:
        'Diagram showing uniform horizontal electric field lines E pointing right, and an electric dipole with charges -q and +q inclined at angle theta = 30 degrees to the field.',
      caption:
        'Figure 1: Electric dipole p = 2aq inclined at θ = 30° to a uniform electric field E.',
      width: 520,
      height: 240,
      aspectRatio: '13/6',
      svgContent: `<svg viewBox="0 0 520 240" xmlns="http://www.w3.org/2000/svg" fill="none">
        <rect width="520" height="240" rx="12" fill="#F8FAFC"/>
        <!-- Uniform E field lines -->
        <g stroke="#94A3B8" stroke-width="1.5" stroke-dasharray="6 4">
          <line x1="40" y1="50" x2="460" y2="50"/>
          <line x1="40" y1="95" x2="460" y2="95"/>
          <line x1="40" y1="140" x2="460" y2="140"/>
          <line x1="40" y1="185" x2="460" y2="185"/>
        </g>
        <g fill="#64748B">
          <polygon points="465,50 455,45 455,55"/>
          <polygon points="465,95 455,90 455,100"/>
          <polygon points="465,140 455,135 455,145"/>
          <polygon points="465,185 455,180 455,190"/>
        </g>
        <text x="475" y="100" fill="#334155" font-family="sans-serif" font-size="14" font-weight="700">E</text>
        <!-- Angle arc -->
        <path d="M 305 140 A 45 45 0 0 0 298 117" stroke="#4F46E5" stroke-width="2" fill="none"/>
        <text x="315" y="132" fill="#4F46E5" font-family="sans-serif" font-size="13" font-weight="600">θ = 30°</text>
        <!-- Dipole rod -->
        <line x1="170" y1="185" x2="350" y2="95" stroke="#0F172A" stroke-width="4" stroke-linecap="round"/>
        <!-- Center O -->
        <circle cx="260" cy="140" r="4" fill="#0F172A"/>
        <text x="252" y="160" fill="#0F172A" font-family="sans-serif" font-size="12" font-weight="600">O</text>
        <!-- Charges -->
        <circle cx="170" cy="185" r="14" fill="#2563EB"/>
        <text x="162" y="190" fill="#FFFFFF" font-family="sans-serif" font-size="12" font-weight="700">-q</text>
        <circle cx="350" cy="95" r="14" fill="#DC2626"/>
        <text x="341" y="100" fill="#FFFFFF" font-family="sans-serif" font-size="12" font-weight="700">+q</text>
        <!-- Force vectors -->
        <line x1="364" y1="95" x2="420" y2="95" stroke="#DC2626" stroke-width="2.5"/>
        <polygon points="425,95 416,90 416,100" fill="#DC2626"/>
        <text x="385" y="84" fill="#DC2626" font-family="sans-serif" font-size="12" font-weight="700">+qE</text>
        <line x1="156" y1="185" x2="100" y2="185" stroke="#2563EB" stroke-width="2.5"/>
        <polygon points="95,185 104,180 104,190" fill="#2563EB"/>
        <text x="105" y="174" fill="#2563EB" font-family="sans-serif" font-size="12" font-weight="700">-qE</text>
      </svg>`,
    },
    options: [
      { id: 'A', text: 'τ = 1.0 × 10⁻³ N·m; W = 1.73 × 10⁻³ J' },
      { id: 'B', text: 'τ = 1.73 × 10⁻³ N·m; W = 1.0 × 10⁻³ J' },
      { id: 'C', text: 'τ = 2.0 × 10⁻³ N·m; W = 1.73 × 10⁻³ J' },
      { id: 'D', text: 'τ = 1.0 × 10⁻³ N·m; W = 1.0 × 10⁻³ J' },
    ],
    correctAnswer: 'A',
    explanation:
      'Step 1 (Torque): The magnitude of torque on an electric dipole in a uniform electric field is τ = pE sin θ. Substituting p = 4.0 × 10⁻⁸ C·m, E = 5.0 × 10⁴ N/C, and sin 30° = 0.5: τ = (4.0 × 10⁻⁸)(5.0 × 10⁴)(0.5) = (2.0 × 10⁻³)(0.5) = 1.0 × 10⁻³ N·m.\nStep 2 (Work Done): The external work required to rotate the dipole quasi-statically from θ₁ = 30° to θ₂ = 90° equals the change in electrostatic potential energy: W = U(90°) − U(30°) = pE(cos 30° − cos 90°) = (2.0 × 10⁻³)(√3/2 − 0) = 1.732 × 10⁻³ J ≈ 1.73 × 10⁻³ J.',
    keyTakeaway:
      'Use τ = pE sin θ for instantaneous torque and W_ext = pE(cos θ₁ − cos θ₂) for slow rotation in a uniform electric field.',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Session 1 (Jan Shift Pattern)',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Physics Team — NCERT Class 12 Ch. 1 & JEE Main Syllabus Aligned',
      contentVersion: 'v1.2',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'PHY-12-CURR-002',
    exam: 'JEE Main',
    classLevel: 'Class 12',
    subject: 'Physics',
    chapter: 'Current Electricity',
    topic: 'Wheatstone Bridge & Equivalent Resistance',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'In the bridge circuit shown below, the resistances are R₁ = 4 Ω, R₂ = 8 Ω, R₃ = 6 Ω, R₄ = 12 Ω, and the central galvanometer branch resistance is R_G = 10 Ω connected across nodes C and D. If an ideal 12 V DC source is connected across terminals A and B, what is the total current drawn from the battery?',
    diagram: {
      id: 'diag-wheatstone-bridge',
      title: 'Bridge Network Circuit',
      altText:
        'Wheatstone bridge diamond network between terminals A and B with top branches R1 = 4 ohm and R2 = 8 ohm, bottom branches R3 = 6 ohm and R4 = 12 ohm, and central bridge resistor RG = 10 ohm between C and D.',
      caption:
        'Figure 2: Four-arm resistor bridge with central branch R_G = 10 Ω connected across a 12 V source.',
      width: 520,
      height: 260,
      aspectRatio: '2/1',
      svgContent: `<svg viewBox="0 0 520 260" xmlns="http://www.w3.org/2000/svg" fill="none">
        <rect width="520" height="260" rx="12" fill="#F8FAFC"/>
        <!-- Terminals A and B -->
        <line x1="60" y1="130" x2="140" y2="130" stroke="#0F172A" stroke-width="2.5"/>
        <line x1="380" y1="130" x2="460" y2="130" stroke="#0F172A" stroke-width="2.5"/>
        <!-- Diamond arms -->
        <line x1="140" y1="130" x2="260" y2="45" stroke="#0F172A" stroke-width="2.5"/>
        <line x1="260" y1="45" x2="380" y2="130" stroke="#0F172A" stroke-width="2.5"/>
        <line x1="140" y1="130" x2="260" y2="215" stroke="#0F172A" stroke-width="2.5"/>
        <line x1="260" y1="215" x2="380" y2="130" stroke="#0F172A" stroke-width="2.5"/>
        <!-- Central branch C to D -->
        <line x1="260" y1="45" x2="260" y2="215" stroke="#4F46E5" stroke-width="2.5" stroke-dasharray="4 3"/>
        <!-- Resistor boxes -->
        <rect x="172" y="72" width="54" height="24" rx="4" fill="#FFFFFF" stroke="#1E293B" stroke-width="2"/>
        <text x="180" y="88" fill="#0F172A" font-family="sans-serif" font-size="11" font-weight="700">R₁=4Ω</text>
        <rect x="294" y="72" width="54" height="24" rx="4" fill="#FFFFFF" stroke="#1E293B" stroke-width="2"/>
        <text x="302" y="88" fill="#0F172A" font-family="sans-serif" font-size="11" font-weight="700">R₂=8Ω</text>
        <rect x="172" y="164" width="54" height="24" rx="4" fill="#FFFFFF" stroke="#1E293B" stroke-width="2"/>
        <text x="180" y="180" fill="#0F172A" font-family="sans-serif" font-size="11" font-weight="700">R₃=6Ω</text>
        <rect x="294" y="164" width="60" height="24" rx="4" fill="#FFFFFF" stroke="#1E293B" stroke-width="2"/>
        <text x="299" y="180" fill="#0F172A" font-family="sans-serif" font-size="11" font-weight="700">R₄=12Ω</text>
        <rect x="228" y="118" width="64" height="24" rx="4" fill="#EEF2FF" stroke="#4F46E5" stroke-width="2"/>
        <text x="234" y="134" fill="#3730A3" font-family="sans-serif" font-size="11" font-weight="700">R_G=10Ω</text>
        <!-- Nodes -->
        <circle cx="140" cy="130" r="5" fill="#0F172A"/>
        <text x="118" y="122" fill="#0F172A" font-family="sans-serif" font-size="13" font-weight="700">A</text>
        <circle cx="380" cy="130" r="5" fill="#0F172A"/>
        <text x="390" y="122" fill="#0F172A" font-family="sans-serif" font-size="13" font-weight="700">B</text>
        <circle cx="260" cy="45" r="5" fill="#4F46E5"/>
        <text x="255" y="32" fill="#4F46E5" font-family="sans-serif" font-size="13" font-weight="700">C</text>
        <circle cx="260" cy="215" r="5" fill="#4F46E5"/>
        <text x="255" y="238" fill="#4F46E5" font-family="sans-serif" font-size="13" font-weight="700">D</text>
        <text x="45" y="152" fill="#059669" font-family="sans-serif" font-size="12" font-weight="700">V = 12V</text>
      </svg>`,
    },
    options: [
      { id: 'A', text: '1.25 A' },
      { id: 'B', text: '1.67 A' },
      { id: 'C', text: '2.00 A' },
      { id: 'D', text: '2.50 A' },
    ],
    correctAnswer: 'B',
    explanation:
      'Step 1 (Check Bridge Balance): Compute the ratio of adjacent arms: R₁ / R₃ = 4 / 6 = 2/3, and R₂ / R₄ = 8 / 12 = 2/3. Because R₁/R₃ = R₂/R₄ (equivalently R₁/R₂ = R₃/R₄ = 1/2), nodes C and D are at the exact same electric potential (V_C = V_D).\nStep 2 (Equivalent Resistance): No current flows through the central resistor R_G = 10 Ω, so it can be removed. The upper branch has series resistance R_upper = R₁ + R₂ = 4 + 8 = 12 Ω. The lower branch has series resistance R_lower = R₃ + R₄ = 6 + 12 = 18 Ω.\nStep 3 (Parallel Combination & Current): R_eq = (12 × 18) / (12 + 18) = 216 / 30 = 7.2 Ω. Therefore, total current from the 12 V ideal battery is I = V / R_eq = 12 / 7.2 = 5 / 3 A ≈ 1.67 A.',
    keyTakeaway:
      'Always verify the Wheatstone balance condition (R₁R₄ = R₂R₃) before applying delta-star transformations.',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Session 2 (Apr Shift Pattern)',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Physics Team — NCERT Class 12 Ch. 3 & JEE Main Syllabus Aligned',
      contentVersion: 'v1.2',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'PHY-12-OPT-003',
    exam: 'CBSE Board',
    classLevel: 'Class 12',
    subject: 'Physics',
    chapter: 'Ray Optics and Optical Instruments',
    topic: 'Thin Lens Formula & Linear Magnification',
    questionType: 'mcq_single',
    difficulty: 'Easy',
    questionText:
      'An object of height 3.0 cm is placed perpendicular to the principal axis at a distance of 30 cm in front of a thin equiconvex lens of focal length f = +20 cm. What are the position (v) and nature/height (h_i) of the image formed?',
    diagram: {
      id: 'diag-convex-lens',
      title: 'Ray Diagram for Thin Convex Lens (u = -30 cm, f = +20 cm)',
      altText:
        'Ray diagram showing an object placed between F1 (20 cm) and 2F1 (40 cm) at 30 cm in front of a convex lens, forming a real, inverted, magnified image at v = +60 cm beyond 2F2.',
      caption:
        'Figure 3: Object placed between F₁ and 2F₁ produces a real, inverted, magnified image beyond 2F₂.',
      width: 520,
      height: 220,
      aspectRatio: '26/11',
      svgContent: `<svg viewBox="0 0 520 220" xmlns="http://www.w3.org/2000/svg" fill="none">
        <rect width="520" height="220" rx="12" fill="#F8FAFC"/>
        <!-- Principal axis -->
        <line x1="20" y1="110" x2="500" y2="110" stroke="#64748B" stroke-width="1.5"/>
        <!-- Convex Lens at x=220 -->
        <path d="M 220 35 Q 238 110 220 185 Q 202 110 220 35 Z" fill="#E0E7FF" stroke="#4338CA" stroke-width="2"/>
        <line x1="220" y1="30" x2="220" y2="190" stroke="#4338CA" stroke-width="1" stroke-dasharray="3 3"/>
        <!-- Focal points (scale: 10cm = 40px) -->
        <!-- F1 at 140, 2F1 at 60, Object at 100 (30cm) -->
        <!-- F2 at 300, 2F2 at 380, Image at 460 (60cm) -->
        <circle cx="140" cy="110" r="3" fill="#0F172A"/>
        <text x="133" y="128" fill="#0F172A" font-family="sans-serif" font-size="11" font-weight="600">F₁</text>
        <circle cx="60" cy="110" r="3" fill="#0F172A"/>
        <text x="50" y="128" fill="#0F172A" font-family="sans-serif" font-size="11" font-weight="600">2F₁</text>
        <circle cx="300" cy="110" r="3" fill="#0F172A"/>
        <text x="294" y="128" fill="#0F172A" font-family="sans-serif" font-size="11" font-weight="600">F₂</text>
        <circle cx="380" cy="110" r="3" fill="#0F172A"/>
        <text x="370" y="128" fill="#0F172A" font-family="sans-serif" font-size="11" font-weight="600">2F₂</text>
        <!-- Object at x=100, height=30px -->
        <line x1="100" y1="110" x2="100" y2="80" stroke="#059669" stroke-width="3"/>
        <polygon points="100,75 95,84 105,84" fill="#059669"/>
        <text x="72" y="72" fill="#059669" font-family="sans-serif" font-size="11" font-weight="700">u = -30cm</text>
        <!-- Rays -->
        <line x1="100" y1="80" x2="220" y2="80" stroke="#DC2626" stroke-width="1.6"/>
        <line x1="220" y1="80" x2="460" y2="170" stroke="#DC2626" stroke-width="1.6"/>
        <line x1="100" y1="80" x2="460" y2="170" stroke="#2563EB" stroke-width="1.6"/>
        <!-- Image at x=460, height=-60px -->
        <line x1="460" y1="110" x2="460" y2="170" stroke="#7C3AED" stroke-width="3"/>
        <polygon points="460,175 455,166 465,166" fill="#7C3AED"/>
        <text x="415" y="192" fill="#7C3AED" font-family="sans-serif" font-size="11" font-weight="700">v = +60cm</text>
      </svg>`,
    },
    options: [
      { id: 'A', text: 'v = +60 cm; Real, inverted image of height 6.0 cm' },
      { id: 'B', text: 'v = -60 cm; Virtual, erect image of height 6.0 cm' },
      { id: 'C', text: 'v = +12 cm; Real, inverted image of height 1.2 cm' },
      { id: 'D', text: 'v = +60 cm; Real, erect image of height 1.5 cm' },
    ],
    correctAnswer: 'A',
    explanation:
      'By sign convention, object distance u = −30 cm and focal length f = +20 cm.\nUsing the thin lens equation: 1/v − 1/u = 1/f ⇒ 1/v = 1/f + 1/u = 1/20 + 1/(−30) = (3 − 2)/60 = 1/60 ⇒ v = +60 cm.\nLinear magnification m = v / u = (+60) / (−30) = −2.0.\nTherefore, image height h_i = m × h_o = (−2.0) × 3.0 cm = −6.0 cm (real and inverted, height 6.0 cm).',
    keyTakeaway:
      'For a convex lens, an object placed at u = 1.5f (between F and 2F) always forms a real, inverted image at v = 3f with magnification m = −2.',
    marksCorrect: 1,
    marksIncorrect: 0,
    marksUnanswered: 0,
    year: 2025,
    session: 'CBSE Class 12 Section A Pattern',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Physics Team — NCERT Class 12 Ch. 9 Ray Optics',
      contentVersion: 'v1.1',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'PHY-12-MOD-004',
    exam: 'JEE Main',
    classLevel: 'Class 12',
    subject: 'Physics',
    chapter: 'Dual Nature of Radiation and Matter',
    topic: 'Einstein Photoelectric Equation & Stopping Potential',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'Monochromatic light of photon energy 4.2 eV is incident on a photosensitive metal surface having a work function φ₀ = 2.2 eV. If the photon energy of the incident radiation is increased to 6.2 eV, by what factor does the stopping potential V₀ change?',
    options: [
      { id: 'A', text: 'Increases by a factor of 1.5' },
      { id: 'B', text: 'Doubles (increases by a factor of 2.0)' },
      { id: 'C', text: 'Increases by a factor of 3.0' },
      { id: 'D', text: 'Remains unchanged because work function is constant' },
    ],
    correctAnswer: 'B',
    explanation:
      'According to Einstein’s photoelectric equation, eV₀ = E_photon − φ₀.\nCase 1: For E₁ = 4.2 eV and φ₀ = 2.2 eV, eV₀₁ = 4.2 − 2.2 = 2.0 eV ⇒ V₀₁ = 2.0 V.\nCase 2: For E₂ = 6.2 eV and φ₀ = 2.2 eV, eV₀₂ = 6.2 − 2.2 = 4.0 eV ⇒ V₀₂ = 4.0 V.\nRatio V₀₂ / V₀₁ = 4.0 V / 2.0 V = 2.0 (the stopping potential doubles).',
    keyTakeaway:
      'Stopping potential varies linearly with incident photon energy (eV₀ = hν − φ₀), not proportionally to hν itself.',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Session 1 (Jan Shift Pattern)',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Physics Team — NCERT Class 12 Ch. 11',
      contentVersion: 'v1.1',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'PHY-11-MECH-005',
    exam: 'JEE Main',
    classLevel: 'Class 11',
    subject: 'Physics',
    chapter: 'Motion in a Plane',
    topic: 'Projectile Motion Range & Maximum Height',
    questionType: 'mcq_single',
    difficulty: 'Easy',
    questionText:
      'A projectile is launched from horizontal ground with initial speed u at an angle θ above the horizontal. If the horizontal range R of the projectile is equal to 4√3 times its maximum vertical height H_max, what is the angle of projection θ?',
    diagram: {
      id: 'diag-projectile',
      title: 'Projectile Trajectory on Horizontal Ground',
      altText:
        'Parabolic trajectory of a projectile launched with initial velocity u at angle theta, showing maximum height H_max at the apex and horizontal range R.',
      caption:
        'Figure 4: Parabolic trajectory illustrating maximum height H_max and horizontal range R = 4√3 H_max.',
      width: 520,
      height: 200,
      aspectRatio: '13/5',
      svgContent: `<svg viewBox="0 0 520 200" xmlns="http://www.w3.org/2000/svg" fill="none">
        <rect width="520" height="200" rx="12" fill="#F8FAFC"/>
        <line x1="40" y1="165" x2="480" y2="165" stroke="#334155" stroke-width="2"/>
        <!-- Parabola -->
        <path d="M 60 165 Q 250 -10 440 165" stroke="#4F46E5" stroke-width="3" fill="none"/>
        <!-- Velocity vector u -->
        <line x1="60" y1="165" x2="135" y2="115" stroke="#DC2626" stroke-width="2.5"/>
        <polygon points="140,111 130,113 135,121" fill="#DC2626"/>
        <text x="115" y="105" fill="#DC2626" font-family="sans-serif" font-size="13" font-weight="700">u</text>
        <path d="M 105 165 A 45 45 0 0 0 98 140" stroke="#0F172A" stroke-width="1.8" fill="none"/>
        <text x="112" y="156" fill="#0F172A" font-family="sans-serif" font-size="12" font-weight="700">θ</text>
        <!-- H_max -->
        <line x1="250" y1="78" x2="250" y2="165" stroke="#059669" stroke-width="2" stroke-dasharray="4 3"/>
        <text x="258" y="125" fill="#059669" font-family="sans-serif" font-size="12" font-weight="700">H_max</text>
        <!-- Range R -->
        <text x="220" y="186" fill="#334155" font-family="sans-serif" font-size="12" font-weight="700">Range R = 4√3 H_max</text>
      </svg>`,
    },
    options: [
      { id: 'A', text: '30°' },
      { id: 'B', text: '45°' },
      { id: 'C', text: '60°' },
      { id: 'D', text: '75°' },
    ],
    correctAnswer: 'A',
    explanation:
      'For a ground-to-ground projectile, horizontal range is R = (u² sin 2θ)/g = (2u² sin θ cos θ)/g, and maximum height is H_max = (u² sin²θ)/(2g).\nTaking their ratio: R / H_max = 4 / tan θ, or tan θ = 4 H_max / R.\nGiven R = 4√3 H_max, we substitute: tan θ = 4 H_max / (4√3 H_max) = 1 / √3.\nTherefore, θ = 30°.',
    keyTakeaway:
      'Remember the direct identity R · tan θ = 4 H_max for any symmetric ground-to-ground projectile trajectory.',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Class 11 Mechanics Foundation',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Physics Team — NCERT Class 11 Ch. 3',
      contentVersion: 'v1.1',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'PHY-11-LAWS-006',
    exam: 'CBSE Board',
    classLevel: 'Class 11',
    subject: 'Physics',
    chapter: 'Laws of Motion',
    topic: 'Connected Bodies on a Frictionless Pulley (Atwood Machine)',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'Two blocks of masses m₁ = 6 kg and m₂ = 4 kg are connected by a light inextensible string passing over a frictionless, massless pulley. Taking g = 10 m/s², what are the magnitude of acceleration of the system and the tension T in the string when released from rest?',
    options: [
      { id: 'A', text: 'a = 2.0 m/s², T = 48 N' },
      { id: 'B', text: 'a = 2.0 m/s², T = 50 N' },
      { id: 'C', text: 'a = 2.5 m/s², T = 48 N' },
      { id: 'D', text: 'a = 1.5 m/s², T = 45 N' },
    ],
    correctAnswer: 'A',
    explanation:
      'For an ideal Atwood machine with m₁ = 6 kg and m₂ = 4 kg:\nStep 1 (Acceleration): a = [(m₁ − m₂) / (m₁ + m₂)] g = [(6 − 4) / (6 + 4)] × 10 = (2 / 10) × 10 = 2.0 m/s².\nStep 2 (Tension): Using the equation of motion for m₂ moving upward: T − m₂g = m₂a ⇒ T = m₂(g + a) = 4 × (10 + 2.0) = 48 N. (Equivalently, T = 2m₁m₂g / (m₁ + m₂) = 2 × 6 × 4 × 10 / 10 = 48 N.)',
    keyTakeaway:
      'In an Atwood machine, T = 2m₁m₂g/(m₁+m₂) always lies strictly between m₂g (40 N) and m₁g (60 N).',
    marksCorrect: 1,
    marksIncorrect: 0,
    marksUnanswered: 0,
    year: 2025,
    session: 'CBSE Class 11 Annual Pattern',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Physics Team — NCERT Class 11 Ch. 4',
      contentVersion: 'v1.0',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'PHY-11-THERM-007',
    exam: 'JEE Main',
    classLevel: 'Class 11',
    subject: 'Physics',
    chapter: 'Thermodynamics',
    topic: 'Carnot Cycle & Reversible Heat Engine Efficiency',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'A Carnot heat engine operates between a source at 600 K and a sink at T_L, exhibiting a thermal efficiency of 40%. If the sink temperature is kept constant, to what temperature must the hot reservoir (source) be raised so that the efficiency increases to 50%?',
    options: [
      { id: 'A', text: '680 K' },
      { id: 'B', text: '720 K' },
      { id: 'C', text: '750 K' },
      { id: 'D', text: '800 K' },
    ],
    correctAnswer: 'B',
    explanation:
      'Step 1 (Find Sink Temperature T_L): Carnot efficiency is η₁ = 1 − (T_L / T_H1). Given η₁ = 0.40 and T_H1 = 600 K:\n0.40 = 1 − (T_L / 600) ⇒ T_L / 600 = 0.60 ⇒ T_L = 360 K.\nStep 2 (Find New Source Temperature T_H2 for η₂ = 0.50):\n0.50 = 1 − (360 / T_H2) ⇒ 360 / T_H2 = 0.50 ⇒ T_H2 = 720 K.',
    keyTakeaway:
      'Always use absolute temperatures in Kelvin when applying η = 1 − T_sink / T_source.',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Session 2 (Apr Shift Pattern)',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Physics Team — NCERT Class 11 Ch. 11',
      contentVersion: 'v1.1',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'PHY-12-MAG-008',
    exam: 'CBSE Board',
    classLevel: 'Class 12',
    subject: 'Physics',
    chapter: 'Moving Charges and Magnetism',
    topic: 'Biot-Savart Law for a Circular Current Loop',
    questionType: 'mcq_single',
    difficulty: 'Easy',
    questionText:
      'A circular coil of radius R = 10 cm having N = 50 closely wound turns carries a steady current of I = 2.0 A. What is the magnitude of the magnetic field B at the geometric center of the coil? (Use μ₀ = 4π × 10⁻⁷ T·m/A)',
    options: [
      { id: 'A', text: '3.14 × 10⁻⁴ T' },
      { id: 'B', text: '6.28 × 10⁻⁴ T' },
      { id: 'C', text: '1.26 × 10⁻³ T' },
      { id: 'D', text: '6.28 × 10⁻⁵ T' },
    ],
    correctAnswer: 'B',
    explanation:
      'By the Biot-Savart law, the magnetic field at the center of an N-turn circular coil of radius R carrying current I is:\nB = (μ₀ N I) / (2R).\nSubstituting μ₀ = 4π × 10⁻⁷ T·m/A, N = 50, I = 2.0 A, and R = 0.10 m:\nB = (4π × 10⁻⁷ × 50 × 2.0) / (2 × 0.10) = (4π × 10⁻⁵) / 0.20 = 20π × 10⁻⁵ T = 2π × 10⁻⁴ T ≈ 6.28 × 10⁻⁴ T.',
    keyTakeaway:
      'Convert radius from cm to meters (10 cm = 0.10 m) before applying B = μ₀NI / (2R).',
    marksCorrect: 1,
    marksIncorrect: 0,
    marksUnanswered: 0,
    year: 2025,
    session: 'CBSE Class 12 Section A Pattern',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Physics Team — NCERT Class 12 Ch. 4',
      contentVersion: 'v1.0',
      lastChecked: '2026-10-01',
    },
  },

  // ======================== CHEMISTRY ========================
  {
    id: 'CHEM-12-ELEC-001',
    exam: 'JEE Main',
    classLevel: 'Class 12',
    subject: 'Chemistry',
    chapter: 'Electrochemistry',
    topic: 'Nernst Equation & Standard Gibbs Free Energy',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'For the galvanic cell Zn(s) | Zn²⁺(1.0 M) || Cu²⁺(1.0 M) | Cu(s) at 298 K, the standard reduction potentials are E°(Zn²⁺/Zn) = −0.76 V and E°(Cu²⁺/Cu) = +0.34 V. Given Faraday constant F = 96500 C/mol, what are the standard cell EMF (E°_cell) and standard Gibbs free energy change (ΔG°)?',
    diagram: {
      id: 'diag-daniell-cell',
      title: 'Daniell Galvanic Cell (Zn-Cu Standard Cell)',
      altText:
        'Diagram of a Daniell electrochemical cell showing a Zinc anode in ZnSO4 solution on the left, a Copper cathode in CuSO4 solution on the right, connected by a KCl salt bridge and an external voltmeter reading 1.10 V.',
      caption:
        'Figure 5: Standard Daniell cell showing electron flow from Zn anode to Cu cathode.',
      width: 520,
      height: 230,
      aspectRatio: '52/23',
      svgContent: `<svg viewBox="0 0 520 230" xmlns="http://www.w3.org/2000/svg" fill="none">
        <rect width="520" height="230" rx="12" fill="#F8FAFC"/>
        <!-- External wire and voltmeter -->
        <polyline points="130,65 130,25 390,25 390,65" stroke="#0F172A" stroke-width="2.5" fill="none"/>
        <circle cx="260" cy="25" r="18" fill="#EEF2FF" stroke="#4F46E5" stroke-width="2.2"/>
        <text x="242" y="30" fill="#3730A3" font-family="sans-serif" font-size="11" font-weight="700">1.10V</text>
        <text x="175" y="18" fill="#4F46E5" font-family="sans-serif" font-size="11" font-weight="700">e⁻ →</text>
        <!-- Left Beaker (Anode) -->
        <rect x="75" y="75" width="120" height="125" rx="6" fill="#E0F2FE" stroke="#0284C7" stroke-width="2"/>
        <rect x="115" y="55" width="26" height="115" rx="3" fill="#64748B" stroke="#334155" stroke-width="2"/>
        <text x="92" y="188" fill="#0369A1" font-family="sans-serif" font-size="11" font-weight="700">Zn²⁺ (1.0 M)</text>
        <text x="75" y="216" fill="#0F172A" font-family="sans-serif" font-size="11" font-weight="700">Anode: Zn (-0.76V)</text>
        <!-- Right Beaker (Cathode) -->
        <rect x="325" y="75" width="120" height="125" rx="6" fill="#DBEAFE" stroke="#2563EB" stroke-width="2"/>
        <rect x="377" y="55" width="26" height="115" rx="3" fill="#D97706" stroke="#92400E" stroke-width="2"/>
        <text x="348" y="188" fill="#1D4ED8" font-family="sans-serif" font-size="11" font-weight="700">Cu²⁺ (1.0 M)</text>
        <text x="322" y="216" fill="#0F172A" font-family="sans-serif" font-size="11" font-weight="700">Cathode: Cu (+0.34V)</text>
        <!-- Salt Bridge -->
        <path d="M 172 135 L 172 60 Q 260 50 348 60 L 348 135" stroke="#059669" stroke-width="12" stroke-linecap="round" fill="none" opacity="0.25"/>
        <path d="M 172 135 L 172 60 Q 260 50 348 60 L 348 135" stroke="#059669" stroke-width="2" fill="none"/>
        <text x="225" y="75" fill="#065F46" font-family="sans-serif" font-size="11" font-weight="700">Salt Bridge</text>
      </svg>`,
    },
    options: [
      { id: 'A', text: 'E°_cell = +1.10 V; ΔG° = −212.3 kJ/mol' },
      { id: 'B', text: 'E°_cell = +1.10 V; ΔG° = −106.15 kJ/mol' },
      { id: 'C', text: 'E°_cell = −0.42 V; ΔG° = +81.06 kJ/mol' },
      { id: 'D', text: 'E°_cell = +0.42 V; ΔG° = −81.06 kJ/mol' },
    ],
    correctAnswer: 'A',
    explanation:
      'Step 1 (Standard Cell Potential): E°_cell = E°_cathode − E°_anode = E°(Cu²⁺/Cu) − E°(Zn²⁺/Zn) = (+0.34 V) − (−0.76 V) = +1.10 V.\nStep 2 (Number of Moles of Electrons Transferred): The balanced cell reaction is Zn(s) + Cu²⁺(aq) → Zn²⁺(aq) + Cu(s), so n = 2.\nStep 3 (Standard Gibbs Energy): ΔG° = −n F E°_cell = −(2) × (96500 C/mol) × (1.10 V) = −212,300 J/mol = −212.3 kJ/mol.',
    keyTakeaway:
      'Always identify n (moles of electrons transferred in the balanced half-reactions) before computing ΔG° = −nFE°_cell.',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Session 1 (Jan Shift Pattern)',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Chemistry Team — NCERT Class 12 Ch. 2 Electrochemistry',
      contentVersion: 'v1.2',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'CHEM-12-KIN-002',
    exam: 'CBSE Board',
    classLevel: 'Class 12',
    subject: 'Chemistry',
    chapter: 'Chemical Kinetics',
    topic: 'First-Order Integrated Rate Law & Half-Life',
    questionType: 'mcq_single',
    difficulty: 'Easy',
    questionText:
      'A first-order chemical reaction has a rate constant k = 6.93 × 10⁻³ s⁻¹ at 300 K. How much time is required for 75% of the initial reactant concentration to be consumed? (Use ln 2 = 0.693)',
    options: [
      { id: 'A', text: '100 s' },
      { id: 'B', text: '150 s' },
      { id: 'C', text: '200 s' },
      { id: 'D', text: '300 s' },
    ],
    correctAnswer: 'C',
    explanation:
      'Step 1 (Half-Life Calculation): For a first-order reaction, half-life is independent of initial concentration: t_{1/2} = 0.693 / k = 0.693 / (6.93 × 10⁻³ s⁻¹) = 100 s.\nStep 2 (Time for 75% Completion): When 75% of the reactant is consumed, 25% (or 1/4 = (1/2)²) of the initial reactant remains. For any first-order reaction, t_{75%} = 2 × t_{1/2} = 2 × 100 s = 200 s.',
    keyTakeaway:
      'For a first-order reaction, t_{75%} = 2 × t_{50%} and t_{87.5%} = 3 × t_{50%}.',
    marksCorrect: 1,
    marksIncorrect: 0,
    marksUnanswered: 0,
    year: 2025,
    session: 'CBSE Class 12 Section A Pattern',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Chemistry Team — NCERT Class 12 Ch. 3',
      contentVersion: 'v1.1',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'CHEM-12-COORD-003',
    exam: 'JEE Main',
    classLevel: 'Class 12',
    subject: 'Chemistry',
    chapter: 'Coordination Compounds',
    topic: 'Crystal Field Theory & Spin-Only Magnetic Moment',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'Compare the octahedral coordination entities [Fe(CN)₆]⁴⁻ and [Fe(H₂O)₆]²⁺ (Atomic number of Fe = 26). Which statement accurately describes their hybridization and spin-only magnetic moment (μ)?',
    options: [
      {
        id: 'A',
        text: '[Fe(CN)₆]⁴⁻ is d²sp³ (diamagnetic, μ = 0 BM) and [Fe(H₂O)₆]²⁺ is sp³d² (paramagnetic, μ = 4.90 BM)',
      },
      {
        id: 'B',
        text: 'Both are d²sp³ inner-orbital complexes with μ = 0 BM',
      },
      {
        id: 'C',
        text: '[Fe(CN)₆]⁴⁻ is d²sp³ (μ = 1.73 BM) and [Fe(H₂O)₆]²⁺ is sp³d² (μ = 5.92 BM)',
      },
      {
        id: 'D',
        text: '[Fe(CN)₆]⁴⁻ is sp³d² (μ = 0 BM) and [Fe(H₂O)₆]²⁺ is d²sp³ (μ = 4.90 BM)',
      },
    ],
    correctAnswer: 'A',
    explanation:
      'In both complexes, iron is in the +2 oxidation state (Fe²⁺ has a 3d⁶ electronic configuration).\n1) In [Fe(CN)₆]⁴⁻, CN⁻ is a strong-field ligand (Δ_o > P), causing all 6 d-electrons to pair up in the lower t_{2g} orbitals (t_{2g}⁶ e_g⁰). Thus there are n = 0 unpaired electrons (diamagnetic, μ = 0 BM) and inner 3d orbitals participate in d²sp³ hybridization.\n2) In [Fe(H₂O)₆]²⁺, H₂O is a weak-field ligand (Δ_o < P), giving the high-spin configuration t_{2g}⁴ e_g² with n = 4 unpaired electrons. Using outer 4d orbitals gives sp³d² hybridization, and μ = √(n(n+2)) = √(4 × 6) = √24 ≈ 4.90 BM.',
    keyTakeaway:
      'Fe²⁺ (3d⁶) with strong-field ligands gives a diamagnetic t₂g⁶ low-spin complex; with weak-field ligands it gives 4 unpaired electrons (μ ≈ 4.90 BM).',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Session 1 (Jan Shift Pattern)',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Chemistry Team — NCERT Class 12 Ch. 5',
      contentVersion: 'v1.1',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'CHEM-12-ORG-004',
    exam: 'CBSE Board',
    classLevel: 'Class 12',
    subject: 'Chemistry',
    chapter: 'Aldehydes, Ketones and Carboxylic Acids',
    topic: 'Cannizzaro vs Aldol Reaction Selectivity',
    questionType: 'mcq_single',
    difficulty: 'Easy',
    questionText:
      'Which of the following carbonyl compounds undergoes the Cannizzaro disproportionation reaction when warmed with concentrated aqueous NaOH (50%), rather than self-aldol condensation?',
    options: [
      { id: 'A', text: 'Ethanal (CH₃CHO)' },
      { id: 'B', text: 'Propanone (CH₃COCH₃)' },
      { id: 'C', text: 'Benzaldehyde (C₆H₅CHO)' },
      { id: 'D', text: 'Phenylacetaldehyde (C₆H₅CH₂CHO)' },
    ],
    correctAnswer: 'C',
    explanation:
      'Aldehydes that lack an α-hydrogen atom cannot form an enolate ion and therefore undergo the Cannizzaro disproportionation reaction in concentrated alkali to yield one molecule of alcohol and one molecule of carboxylic acid salt.\nBenzaldehyde (C₆H₅CHO) has no α-hydrogen attached to the sp² ring carbon adjacent to −CHO, so it reacts with conc. NaOH to give benzyl alcohol (C₆H₅CH₂OH) and sodium benzoate (C₆H₅COONa). Ethanal, propanone, and phenylacetaldehyde all possess acidic α-hydrogens and undergo aldol condensation.',
    keyTakeaway:
      'Check the carbon directly bonded to the carbonyl group (C_α): if it has zero hydrogens (like HCHO, C₆H₅CHO, (CH₃)₃C-CHO), it gives the Cannizzaro reaction.',
    marksCorrect: 1,
    marksIncorrect: 0,
    marksUnanswered: 0,
    year: 2025,
    session: 'CBSE Class 12 Section A Pattern',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Chemistry Team — NCERT Class 12 Ch. 8',
      contentVersion: 'v1.0',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'CHEM-11-ATOM-005',
    exam: 'JEE Main',
    classLevel: 'Class 11',
    subject: 'Chemistry',
    chapter: 'Structure of Atom',
    topic: 'Bohr Model for Hydrogen-Like Ions',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'According to Bohr’s model for one-electron species, what are the energy (E₂) and radius (r₂) of the first excited state (n = 2) of a singly ionized helium ion (He⁺, Z = 2), given that the ground-state Bohr radius of hydrogen is a₀ = 52.9 pm?',
    options: [
      { id: 'A', text: 'E₂ = −13.6 eV; r₂ = 105.8 pm (2a₀)' },
      { id: 'B', text: 'E₂ = −54.4 eV; r₂ = 26.45 pm (0.5a₀)' },
      { id: 'C', text: 'E₂ = −3.4 eV; r₂ = 211.6 pm (4a₀)' },
      { id: 'D', text: 'E₂ = −13.6 eV; r₂ = 52.9 pm (a₀)' },
    ],
    correctAnswer: 'A',
    explanation:
      'Note that "first excited state" corresponds to principal quantum number n = 2, and for He⁺ the atomic number is Z = 2.\nStep 1 (Energy): E_n = −13.6 × (Z² / n²) eV = −13.6 × (2² / 2²) eV = −13.6 eV.\nStep 2 (Radius): r_n = a₀ × (n² / Z) = 52.9 pm × (2² / 2) = 52.9 × 2 = 105.8 pm (which equals 2a₀).',
    keyTakeaway:
      'The first excited state is n = 2 (not n = 1). For He⁺ (Z = 2, n = 2), E₂ equals the ground-state energy of Hydrogen (−13.6 eV).',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Class 11 Physical Chemistry Foundation',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Chemistry Team — NCERT Class 11 Ch. 2',
      contentVersion: 'v1.1',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'CHEM-11-BOND-006',
    exam: 'CBSE Board',
    classLevel: 'Class 11',
    subject: 'Chemistry',
    chapter: 'Chemical Bonding and Molecular Structure',
    topic: 'VSEPR Theory & Molecular Geometry',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'Using VSEPR theory, identify the correct molecular geometry (shape) and number of lone pairs on the central atom for SF₄, ClF₃, and XeF₄ respectively:',
    options: [
      {
        id: 'A',
        text: 'SF₄: See-saw (1 LP); ClF₃: Bent T-shaped (2 LP); XeF₄: Square planar (2 LP)',
      },
      {
        id: 'B',
        text: 'SF₄: Tetrahedral (0 LP); ClF₃: Trigonal planar (0 LP); XeF₄: Tetrahedral (0 LP)',
      },
      {
        id: 'C',
        text: 'SF₄: Square planar (2 LP); ClF₃: Pyramidal (1 LP); XeF₄: See-saw (1 LP)',
      },
      {
        id: 'D',
        text: 'SF₄: See-saw (1 LP); ClF₃: Trigonal pyramidal (1 LP); XeF₄: Square pyramidal (1 LP)',
      },
    ],
    correctAnswer: 'A',
    explanation:
      '1) SF₄: Central S has 6 valence electrons. With 4 F atoms, there are 4 bond pairs and (6−4)/2 = 1 lone pair (Steric number 5, sp³d) → See-saw molecular shape.\n2) ClF₃: Central Cl has 7 valence electrons. With 3 F atoms, there are 3 bond pairs and (7−3)/2 = 2 lone pairs occupying equatorial positions (Steric number 5, sp³d) → Bent T-shaped geometry.\n3) XeF₄: Central Xe has 8 valence electrons. With 4 F atoms, there are 4 bond pairs and (8−4)/2 = 2 lone pairs trans to each other (Steric number 6, sp³d²) → Square planar geometry.',
    keyTakeaway:
      'In sp³d (trigonal bipyramidal) systems, lone pairs always occupy equatorial positions to minimize 90° lone-pair repulsions.',
    marksCorrect: 1,
    marksIncorrect: 0,
    marksUnanswered: 0,
    year: 2025,
    session: 'CBSE Class 11 Annual Pattern',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Chemistry Team — NCERT Class 11 Ch. 4',
      contentVersion: 'v1.0',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'CHEM-11-EQUIL-007',
    exam: 'JEE Main',
    classLevel: 'Class 11',
    subject: 'Chemistry',
    chapter: 'Equilibrium',
    topic: 'Ionic Equilibrium & Acidic Buffer Solutions',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'An aqueous acidic buffer is prepared by mixing 100 mL of 0.20 M acetic acid (CH₃COOH, pK_a = 4.76) with 100 mL of 0.40 M sodium acetate (CH₃COONa). Given log₁₀(2) = 0.30, what is the pH of the resulting buffer solution at 298 K?',
    options: [
      { id: 'A', text: '4.46' },
      { id: 'B', text: '4.76' },
      { id: 'C', text: '5.06' },
      { id: 'D', text: '5.36' },
    ],
    correctAnswer: 'C',
    explanation:
      'Using the Henderson-Hasselbalch equation for an acidic buffer:\npH = pK_a + log₁₀([Conjugate Base] / [Weak Acid]).\nIn the mixed 200 mL solution, millimoles of CH₃COONa (salt) = 100 × 0.40 = 40 mmol, and millimoles of CH₃COOH (acid) = 100 × 0.20 = 20 mmol.\nRatio [Salt] / [Acid] = 40 / 20 = 2.0.\nTherefore, pH = 4.76 + log₁₀(2) = 4.76 + 0.30 = 5.06.',
    keyTakeaway:
      'When [Conjugate Base] > [Acid], the buffer pH is higher than pK_a by log₁₀([Salt]/[Acid]).',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Session 2 (Apr Shift Pattern)',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Chemistry Team — NCERT Class 11 Ch. 6',
      contentVersion: 'v1.1',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'CHEM-12-SOL-008',
    exam: 'CBSE Board',
    classLevel: 'Class 12',
    subject: 'Chemistry',
    chapter: 'Solutions',
    topic: 'Colligative Properties & Van’t Hoff Factor',
    questionType: 'mcq_single',
    difficulty: 'Easy',
    questionText:
      'Assuming complete (100%) dissociation in dilute aqueous solution, what is the elevation in boiling point (ΔT_b) of a 0.10 molal aqueous solution of potassium sulphate (K₂SO₄)? (Given ebullioscopic constant for water K_b = 0.52 K·kg·mol⁻¹)',
    options: [
      { id: 'A', text: '0.052 K' },
      { id: 'B', text: '0.104 K' },
      { id: 'C', text: '0.156 K' },
      { id: 'D', text: '0.208 K' },
    ],
    correctAnswer: 'C',
    explanation:
      'Step 1 (Van’t Hoff Factor i): Potassium sulphate dissociates completely as K₂SO₄(aq) → 2 K⁺(aq) + SO₄²⁻(aq), yielding 3 ions per formula unit, so i = 3.\nStep 2 (Boiling Point Elevation): ΔT_b = i × K_b × m = 3 × 0.52 K·kg·mol⁻¹ × 0.10 mol·kg⁻¹ = 0.156 K.',
    keyTakeaway:
      'Do not forget the van’t Hoff factor i = 3 for strong AB₂/A₂B electrolytes like K₂SO₄, CaCl₂, or Na₂CO₃.',
    marksCorrect: 1,
    marksIncorrect: 0,
    marksUnanswered: 0,
    year: 2025,
    session: 'CBSE Class 12 Section A Pattern',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Chemistry Team — NCERT Class 12 Ch. 1',
      contentVersion: 'v1.0',
      lastChecked: '2026-10-01',
    },
  },

  // ======================== MATHEMATICS ========================
  {
    id: 'MATH-12-CALC-001',
    exam: 'JEE Main',
    classLevel: 'Class 12',
    subject: 'Mathematics',
    chapter: 'Integrals',
    topic: 'Properties of Definite Integrals (Symmetry Identity)',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'Evaluate the definite integral I = ∫₀^(π/2) [ sin^(3/2)(x) / ( sin^(3/2)(x) + cos^(3/2)(x) ) ] dx:',
    diagram: {
      id: 'diag-symmetry-integral',
      title: 'Symmetry of f(x) and f(π/2 − x) on [0, π/2]',
      altText:
        'Coordinate graph on interval [0, pi/2] showing the curve y = f(x) rising from (0,0) to (pi/2,1), passing through the midpoint (pi/4, 1/2), illustrating that f(x) + f(pi/2 - x) = 1 everywhere.',
      caption:
        'Figure 6: Symmetry about x = π/4 where f(x) + f(π/2 − x) = 1 yields area = (π/2)/2 = π/4.',
      width: 520,
      height: 220,
      aspectRatio: '26/11',
      svgContent: `<svg viewBox="0 0 520 220" xmlns="http://www.w3.org/2000/svg" fill="none">
        <rect width="520" height="220" rx="12" fill="#F8FAFC"/>
        <!-- Axes -->
        <line x1="70" y1="180" x2="450" y2="180" stroke="#334155" stroke-width="2"/>
        <line x1="70" y1="190" x2="70" y2="30" stroke="#334155" stroke-width="2"/>
        <!-- Top bound y = 1 at y = 50 -->
        <line x1="70" y1="50" x2="390" y2="50" stroke="#94A3B8" stroke-width="1.5" stroke-dasharray="5 4"/>
        <line x1="390" y1="50" x2="390" y2="180" stroke="#94A3B8" stroke-width="1.5" stroke-dasharray="5 4"/>
        <!-- Shaded area under f(x) -->
        <path d="M 70 180 C 180 180, 280 50, 390 50 L 390 180 Z" fill="#E0E7FF" opacity="0.7"/>
        <!-- Curve f(x) -->
        <path d="M 70 180 C 180 180, 280 50, 390 50" stroke="#4F46E5" stroke-width="3" fill="none"/>
        <!-- Curve f(pi/2 - x) -->
        <path d="M 70 50 C 180 50, 280 180, 390 180" stroke="#059669" stroke-width="2" stroke-dasharray="4 3" fill="none"/>
        <!-- Midpoint (pi/4, 1/2) at (230, 115) -->
        <circle cx="230" cy="115" r="5" fill="#DC2626"/>
        <text x="240" y="120" fill="#DC2626" font-family="sans-serif" font-size="12" font-weight="700">(π/4, 1/2)</text>
        <!-- Labels -->
        <text x="45" y="55" fill="#0F172A" font-family="sans-serif" font-size="12" font-weight="700">1</text>
        <text x="52" y="185" fill="#0F172A" font-family="sans-serif" font-size="12" font-weight="700">0</text>
        <text x="220" y="200" fill="#0F172A" font-family="sans-serif" font-size="12" font-weight="700">π/4</text>
        <text x="380" y="200" fill="#0F172A" font-family="sans-serif" font-size="12" font-weight="700">π/2</text>
        <text x="305" y="88" fill="#4338CA" font-family="sans-serif" font-size="12" font-weight="700">y = f(x)</text>
      </svg>`,
    },
    options: [
      { id: 'A', text: 'π / 2' },
      { id: 'B', text: 'π / 4' },
      { id: 'C', text: 'π / 3' },
      { id: 'D', text: 'π / 6' },
    ],
    correctAnswer: 'B',
    explanation:
      'Let I = ∫₀^(π/2) [ sin^(3/2)(x) / ( sin^(3/2)(x) + cos^(3/2)(x) ) ] dx  --- (Equation 1).\nUsing the definite integral property ∫₀^a f(x) dx = ∫₀^a f(a − x) dx with a = π/2, and noting that sin(π/2 − x) = cos x and cos(π/2 − x) = sin x:\nI = ∫₀^(π/2) [ cos^(3/2)(x) / ( cos^(3/2)(x) + sin^(3/2)(x) ) ] dx  --- (Equation 2).\nAdding Equation 1 and Equation 2 gives:\n2I = ∫₀^(π/2) [ (sin^(3/2)(x) + cos^(3/2)(x)) / (sin^(3/2)(x) + cos^(3/2)(x)) ] dx = ∫₀^(π/2) 1 dx = π/2.\nDividing by 2 yields I = π / 4.',
    keyTakeaway:
      'For any real exponent n, ∫₀^(π/2) sinⁿx / (sinⁿx + cosⁿx) dx always equals π/4 by reflection symmetry about x = π/4.',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Session 1 (Jan Shift Pattern)',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Mathematics Team — NCERT Class 12 Ch. 7 Integrals',
      contentVersion: 'v1.2',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'MATH-12-MAT-002',
    exam: 'CBSE Board',
    classLevel: 'Class 12',
    subject: 'Mathematics',
    chapter: 'Determinants',
    topic: 'Adjoint & Determinant Properties of Square Matrices',
    questionType: 'mcq_single',
    difficulty: 'Easy',
    questionText:
      'If A is a non-singular square matrix of order 3 × 3 such that |det(A)| = 5, what is the value of det(adj(2A))?',
    options: [
      { id: 'A', text: '100' },
      { id: 'B', text: '400' },
      { id: 'C', text: '1600' },
      { id: 'D', text: '2500' },
    ],
    correctAnswer: 'C',
    explanation:
      'For any square matrix M of order n = 3:\n1) det(adj(M)) = (det(M))^(n−1) = (det(M))².\n2) Setting M = 2A where A is of order 3: det(2A) = 2³ · det(A) = 8 × 5 = 40.\n3) Therefore, det(adj(2A)) = (det(2A))² = 40² = 1600.',
    keyTakeaway:
      'Combine det(kA) = kⁿ det(A) and det(adj(M)) = (det(M))^(n−1) carefully in the right order.',
    marksCorrect: 1,
    marksIncorrect: 0,
    marksUnanswered: 0,
    year: 2025,
    session: 'CBSE Class 12 Section A Pattern',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Mathematics Team — NCERT Class 12 Ch. 4 Determinants',
      contentVersion: 'v1.1',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'MATH-12-VEC-003',
    exam: 'JEE Main',
    classLevel: 'Class 12',
    subject: 'Mathematics',
    chapter: 'Vector Algebra',
    topic: 'Scalar Projection & Dot Product of Vectors',
    questionType: 'mcq_single',
    difficulty: 'Easy',
    questionText:
      'Let a⃗ = 2î + 3ĵ + 6k̂ and b⃗ = 2î − 2ĵ + k̂. What is the scalar projection of vector a⃗ onto vector b⃗?',
    options: [
      { id: 'A', text: '4 / 3' },
      { id: 'B', text: '4 / 7' },
      { id: 'C', text: '8 / 3' },
      { id: 'D', text: '2' },
    ],
    correctAnswer: 'A',
    explanation:
      'Step 1 (Dot Product): a⃗ · b⃗ = (2)(2) + (3)(−2) + (6)(1) = 4 − 6 + 6 = 4.\nStep 2 (Magnitude of b⃗): |b⃗| = √(2² + (−2)² + 1²) = √(4 + 4 + 1) = √9 = 3.\nStep 3 (Scalar Projection of a⃗ on b⃗): Proj_{b⃗}(a⃗) = (a⃗ · b⃗) / |b⃗| = 4 / 3.',
    keyTakeaway:
      'The projection of a⃗ on b⃗ divides by |b⃗| (not |a⃗|). Here |b⃗| = 3 and |a⃗| = 7.',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Session 2 (Apr Shift Pattern)',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Mathematics Team — NCERT Class 12 Ch. 10',
      contentVersion: 'v1.1',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'MATH-12-PROB-004',
    exam: 'CBSE Board',
    classLevel: 'Class 12',
    subject: 'Mathematics',
    chapter: 'Probability',
    topic: 'Bayes’ Theorem & Total Probability',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'Bag I contains 3 red and 4 black balls, while Bag II contains 5 red and 2 black balls. One bag is chosen at random (equally likely) and a ball is drawn from it. If the drawn ball is found to be red, what is the probability that it was drawn from Bag II?',
    options: [
      { id: 'A', text: '3 / 8' },
      { id: 'B', text: '5 / 8' },
      { id: 'C', text: '5 / 7' },
      { id: 'D', text: '4 / 7' },
    ],
    correctAnswer: 'B',
    explanation:
      'Let E₁ be the event of choosing Bag I and E₂ be the event of choosing Bag II, so P(E₁) = P(E₂) = 1/2.\nLet R be the event of drawing a red ball. Then P(R | E₁) = 3/7 and P(R | E₂) = 5/7.\nBy Bayes’ theorem:\nP(E₂ | R) = [ P(E₂) P(R | E₂) ] / [ P(E₁) P(R | E₁) + P(E₂) P(R | E₂) ]\n= [ (1/2)(5/7) ] / [ (1/2)(3/7) + (1/2)(5/7) ] = (5/7) / (8/7) = 5 / 8.',
    keyTakeaway:
      'When prior probabilities P(E₁) and P(E₂) are equal, the posterior probability is simply the ratio of likelihoods: (5/7) / (3/7 + 5/7) = 5/8.',
    marksCorrect: 1,
    marksIncorrect: 0,
    marksUnanswered: 0,
    year: 2025,
    session: 'CBSE Class 12 Section A Pattern',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Mathematics Team — NCERT Class 12 Ch. 13',
      contentVersion: 'v1.0',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'MATH-11-CONIC-005',
    exam: 'JEE Main',
    classLevel: 'Class 11',
    subject: 'Mathematics',
    chapter: 'Conic Sections',
    topic: 'Eccentricity & Latus Rectum of an Ellipse',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'For the ellipse 9x² + 25y² = 225, what are the eccentricity (e) and the length of the latus rectum (L)?',
    options: [
      { id: 'A', text: 'e = 4/5; L = 18/5' },
      { id: 'B', text: 'e = 3/5; L = 18/5' },
      { id: 'C', text: 'e = 4/5; L = 50/3' },
      { id: 'D', text: 'e = 3/5; L = 9/5' },
    ],
    correctAnswer: 'A',
    explanation:
      'Divide both sides by 225 to put the ellipse in standard form:\nx² / 25 + y² / 9 = 1 ⇒ a² = 25 (a = 5) and b² = 9 (b = 3).\nStep 1 (Eccentricity): Since b² = a²(1 − e²), we have e = √(1 − b²/a²) = √(1 − 9/25) = √(16/25) = 4/5.\nStep 2 (Length of Latus Rectum): L = 2b² / a = 2(9) / 5 = 18/5.',
    keyTakeaway:
      'In standard form x²/a² + y²/b² = 1 with a > b, latus rectum is 2b²/a and c = ae = √(a² − b²).',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Class 11 Coordinate Geometry',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Mathematics Team — NCERT Class 11 Ch. 10',
      contentVersion: 'v1.1',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'MATH-11-SEQ-006',
    exam: 'JEE Main',
    classLevel: 'Class 11',
    subject: 'Mathematics',
    chapter: 'Sequences and Series',
    topic: 'Arithmetic Progression & Sum of Terms',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'In an arithmetic progression (A.P.), the sum of the first n terms is given by S_n = 3n² + 5n. Which term of this A.P. has the value 164?',
    options: [
      { id: 'A', text: '26th term' },
      { id: 'B', text: '27th term' },
      { id: 'C', text: '28th term' },
      { id: 'D', text: '29th term' },
    ],
    correctAnswer: 'B',
    explanation:
      'Step 1 (Find the n-th term formula a_n): For any sequence, a_n = S_n − S_{n−1}.\nS_n = 3n² + 5n, and S_{n−1} = 3(n−1)² + 5(n−1) = 3(n² − 2n + 1) + 5n − 5 = 3n² − n − 2.\nSubtracting gives a_n = (3n² + 5n) − (3n² − n − 2) = 6n + 2.\nStep 2 (Solve a_n = 164): 6n + 2 = 164 ⇒ 6n = 162 ⇒ n = 27 (the 27th term).',
    keyTakeaway:
      'If S_n = An² + Bn for an A.P., then the common difference is d = 2A and the n-th term is a_n = 2An + (B − A).',
    marksCorrect: 4,
    marksIncorrect: -1,
    marksUnanswered: 0,
    year: 2024,
    session: 'Session 1 (Jan Shift Pattern)',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Mathematics Team — NCERT Class 11 Ch. 8',
      contentVersion: 'v1.1',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'MATH-11-COMP-007',
    exam: 'CBSE Board',
    classLevel: 'Class 11',
    subject: 'Mathematics',
    chapter: 'Complex Numbers and Quadratic Equations',
    topic: 'Modulus & Principal Argument of Complex Numbers',
    questionType: 'mcq_single',
    difficulty: 'Easy',
    questionText:
      'What is the least positive integer n such that ((1 + i) / (1 − i))ⁿ = 1, where i = √(−1)?',
    options: [
      { id: 'A', text: 'n = 2' },
      { id: 'B', text: 'n = 4' },
      { id: 'C', text: 'n = 8' },
      { id: 'D', text: 'n = 1' },
    ],
    correctAnswer: 'B',
    explanation:
      'First simplify the quotient inside the parentheses by multiplying numerator and denominator by (1 + i):\n(1 + i) / (1 − i) = (1 + i)² / ((1 − i)(1 + i)) = (1 + 2i + i²) / (1 − i²) = (1 + 2i − 1) / (1 + 1) = 2i / 2 = i.\nTherefore, ((1 + i) / (1 − i))ⁿ = iⁿ.\nThe smallest positive integer n for which iⁿ = 1 is n = 4.',
    keyTakeaway:
      'Memorize the standard simplification (1 + i)/(1 − i) = i and (1 − i)/(1 + i) = −i.',
    marksCorrect: 1,
    marksIncorrect: 0,
    marksUnanswered: 0,
    year: 2025,
    session: 'CBSE Class 11 Annual Pattern',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Mathematics Team — NCERT Class 11 Ch. 4',
      contentVersion: 'v1.0',
      lastChecked: '2026-10-01',
    },
  },
  {
    id: 'MATH-12-DIFF-008',
    exam: 'CBSE Board',
    classLevel: 'Class 12',
    subject: 'Mathematics',
    chapter: 'Application of Derivatives',
    topic: 'Maxima and Minima of Functions',
    questionType: 'mcq_single',
    difficulty: 'Moderate',
    questionText:
      'For the function f(x) = 2x³ − 9x² + 12x + 5 defined on ℝ, at what points does f(x) attain its local maximum and local minimum values respectively?',
    options: [
      { id: 'A', text: 'Local maximum at x = 1 (value 10); Local minimum at x = 2 (value 9)' },
      { id: 'B', text: 'Local maximum at x = 2 (value 9); Local minimum at x = 1 (value 10)' },
      { id: 'C', text: 'Local maximum at x = −1 (value −18); Local minimum at x = 2 (value 9)' },
      { id: 'D', text: 'Local maximum at x = 1 (value 12); Local minimum at x = 3 (value 5)' },
    ],
    correctAnswer: 'A',
    explanation:
      'Step 1 (First Derivative & Critical Points): f′(x) = 6x² − 18x + 12 = 6(x² − 3x + 2) = 6(x − 1)(x − 2). Setting f′(x) = 0 gives critical points x = 1 and x = 2.\nStep 2 (Second Derivative Test): f″(x) = 12x − 18.\n• At x = 1: f″(1) = 12(1) − 18 = −6 < 0 ⇒ Local maximum at x = 1 with f(1) = 2(1) − 9(1) + 12(1) + 5 = 10.\n• At x = 2: f″(2) = 12(2) − 18 = +6 > 0 ⇒ Local minimum at x = 2 with f(2) = 2(8) − 9(4) + 12(2) + 5 = 16 − 36 + 24 + 5 = 9.',
    keyTakeaway:
      'Use the second-derivative test: f′(c) = 0 and f″(c) < 0 indicates a local maximum; f″(c) > 0 indicates a local minimum.',
    marksCorrect: 1,
    marksIncorrect: 0,
    marksUnanswered: 0,
    year: 2025,
    session: 'CBSE Class 12 Section A Pattern',
    verification: {
      status: 'edusphere_original_practice',
      label: 'EduSphere Verified Practice Question',
      source: 'EduSphere Academic Mathematics Team — NCERT Class 12 Ch. 6',
      contentVersion: 'v1.0',
      lastChecked: '2026-10-01',
    },
  },

  // ======================== FULL 75-QUESTION JEE MAIN 2024 PAPER (25 PHY + 25 CHEM + 25 MATH) ========================
  ...JEE_2024_FULL_75_QUESTIONS,

  // ======================== FULL CBSE CLASS 12 BOARD 2024 PAPERS (PHY 55/4/1 + CHEM 56/2/1 + MATH 65/2/1) ========================
  ...CBSE_2024_FULL_BOARD_QUESTIONS,
];


