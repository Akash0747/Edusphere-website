import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  X,
  Download,
  ExternalLink,
  FileText,
  AlertTriangle,
  RefreshCw,
  CheckCircle2,
  Play,
  BookOpen,
  ArrowLeft,
} from 'lucide-react';
import { Question, StudyResource } from '../core/types';
import { VerificationBadge } from './VerificationBadge';
import { DiagramView } from './DiagramView';

interface PdfViewerModalProps {
  resource: StudyResource | null;
  linkedQuestions: Question[];
  onClose: () => void;
}

export const PdfViewerModal: React.FC<PdfViewerModalProps> = ({
  resource,
  linkedQuestions,
  onClose,
}) => {
  const [viewMode, setViewMode] = useState<'structured' | 'native_pdf'>(
    'structured'
  );
  const [pdfCheckState, setPdfCheckState] = useState<
    'idle' | 'checking' | 'verified' | 'error'
  >('idle');
  const [showAnswersInPreview, setShowAnswersInPreview] = useState(true);

  const verifyPdfAvailability = async (url?: string) => {
    if (!url) {
      setPdfCheckState('idle');
      return;
    }
    setPdfCheckState('checking');
    try {
      const response = await fetch(url, { method: 'HEAD' });
      if (response.ok) {
        setPdfCheckState('verified');
      } else {
        setPdfCheckState('error');
      }
    } catch {
      setPdfCheckState('error');
    }
  };

  useEffect(() => {
    if (resource && resource.pdfAvailable && resource.pdfUrl) {
      verifyPdfAvailability(resource.pdfUrl);
      setViewMode('structured');
    } else {
      setPdfCheckState('idle');
    }
  }, [resource]);

  if (!resource) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-2 sm:p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pdf-viewer-title"
    >
      <div className="relative flex flex-col w-full max-w-5xl max-h-[92vh] rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl overflow-hidden">
        {/* Top Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>Back to Library (Filters Saved)</span>
            </button>
            <div className="hidden sm:block truncate">
              <h2
                id="pdf-viewer-title"
                className="text-sm font-bold text-slate-900 dark:text-white truncate"
              >
                {resource.title}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {resource.exam} • {resource.classLevel} • {resource.subject} (
                {resource.year})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {resource.pdfAvailable && resource.pdfUrl && (
              <>
                <a
                  href={resource.pdfUrl}
                  download={`${resource.id}.pdf`}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-brand-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-brand-700 transition-colors shadow-sm"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>
                    Download PDF{' '}
                    {resource.pdfFileSize ? `(${resource.pdfFileSize})` : ''}
                  </span>
                </a>
                <a
                  href={resource.pdfUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                  title="Open raw PDF in external browser tab"
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                  <span className="hidden md:inline">External Viewer</span>
                </a>
              </>
            )}

            <button
              type="button"
              onClick={onClose}
              className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
              aria-label="Close document viewer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Subheader: Verification & Mode Switcher */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-2.5 sm:px-6">
          <div className="flex flex-wrap items-center gap-2">
            <VerificationBadge verification={resource.verification} showSource />
            {resource.pdfAvailable && pdfCheckState === 'verified' && (
              <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-400">
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>PDF Verified ({resource.pdfPageCount || 2} pages)</span>
              </span>
            )}
            {resource.pdfAvailable && pdfCheckState === 'checking' && (
              <span className="inline-flex items-center gap-1 text-xs text-slate-500">
                <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                <span>Verifying PDF file...</span>
              </span>
            )}
          </div>

          {resource.pdfAvailable && resource.pdfUrl && (
            <div className="flex items-center gap-1 rounded-lg bg-slate-100 dark:bg-slate-800 p-1">
              <button
                type="button"
                onClick={() => setViewMode('structured')}
                className={`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors ${
                  viewMode === 'structured'
                    ? 'bg-white dark:bg-slate-900 text-brand-700 dark:text-brand-300 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                Formatted Study View
              </button>
              <button
                type="button"
                onClick={() => setViewMode('native_pdf')}
                className={`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors ${
                  viewMode === 'native_pdf'
                    ? 'bg-white dark:bg-slate-900 text-brand-700 dark:text-brand-300 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                Embedded PDF Frame
              </button>
            </div>
          )}
        </div>

        {/* Main Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-50/60 dark:bg-slate-950/50">
          {!resource.pdfAvailable ? (
            /* Honest Unavailable / Pending Verification State */
            <div className="mx-auto max-w-2xl rounded-2xl border border-amber-200 dark:border-amber-800/80 bg-amber-50/70 dark:bg-amber-950/30 p-6 space-y-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-6 w-6 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    PDF File Not Yet Added to Local Repository
                  </h3>
                  <p className="text-xs leading-relaxed text-slate-700 dark:text-slate-300">
                    {resource.unavailableReason ||
                      'This archival paper is currently awaiting redistribution clearance and verification. EduSphere never links to fake or placeholder PDFs.'}
                  </p>
                </div>
              </div>

              <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Available Immediately for This Topic:
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  Even though the historical scanned PDF is pending addition,
                  this catalog entry is linked to{' '}
                  <strong>{linkedQuestions.length} verified questions</strong>{' '}
                  with complete worked solutions that you can practice right
                  now:
                </p>
                <div className="flex flex-wrap gap-2.5 pt-1">
                  <Link
                    to={`/practice?exam=${encodeURIComponent(
                      resource.exam
                    )}&subject=${encodeURIComponent(resource.subject)}`}
                    onClick={onClose}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-brand-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-brand-700 transition-colors"
                  >
                    <BookOpen className="h-3.5 w-3.5" />
                    <span>Practice Linked {resource.subject} Questions</span>
                  </Link>
                  {resource.linkedTestId && (
                    <Link
                      to={`/test/${resource.linkedTestId}`}
                      onClick={onClose}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-brand-300 dark:border-brand-700 bg-brand-50 dark:bg-brand-950/60 px-3.5 py-2 text-xs font-semibold text-brand-700 dark:text-brand-300 hover:bg-brand-100 transition-colors"
                    >
                      <Play className="h-3.5 w-3.5" />
                      <span>Start Linked Timed Mock Test</span>
                    </Link>
                  )}
                </div>
              </div>
            </div>
          ) : pdfCheckState === 'error' ? (
            /* Network or Loading Error State with Retry */
            <div className="mx-auto max-w-xl rounded-2xl border border-rose-200 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/30 p-6 text-center space-y-3">
              <AlertTriangle className="h-8 w-8 text-rose-600 mx-auto" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Unable to Verify PDF File Stream
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300">
                The PDF file at <code>{resource.pdfUrl}</code> could not be
                reached due to a temporary connection issue. You can retry
                loading the PDF or read the complete structured paper below.
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => verifyPdfAvailability(resource.pdfUrl)}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 text-white px-4 py-2 text-xs font-semibold hover:bg-slate-800"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>Retry PDF Check</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPdfCheckState('verified');
                    setViewMode('structured');
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  <span>Open Formatted Reader</span>
                </button>
              </div>
            </div>
          ) : viewMode === 'native_pdf' && resource.pdfUrl ? (
            /* Native Browser PDF Iframe View */
            <div className="flex flex-col h-[70vh] rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
              <div className="bg-slate-100 dark:bg-slate-800 px-4 py-2 text-xs text-slate-600 dark:text-slate-300 flex items-center justify-between">
                <span>
                  Viewing <code>{resource.pdfUrl}</code> — If your mobile
                  browser does not render inline PDFs, switch to{' '}
                  <button
                    type="button"
                    onClick={() => setViewMode('structured')}
                    className="underline font-semibold text-brand-600 dark:text-brand-400"
                  >
                    Formatted Study View
                  </button>{' '}
                  or click Download PDF above.
                </span>
              </div>
              <iframe
                src={resource.pdfUrl}
                title={resource.title}
                className="w-full flex-1 border-0"
              />
            </div>
          ) : (
            /* Structured Academic Document & Solutions Reader */
            <div className="mx-auto max-w-4xl space-y-6">
              {/* Document Header Sheet */}
              <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-sm space-y-4">
                <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-brand-600 dark:text-brand-400">
                      <span>{resource.exam}</span>
                      <span>•</span>
                      <span>{resource.classLevel}</span>
                      <span>•</span>
                      <span>{resource.subject}</span>
                      {resource.sessionOrSet && (
                        <>
                          <span>•</span>
                          <span>{resource.sessionOrSet}</span>
                        </>
                      )}
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                      {resource.title}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      {resource.description}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {resource.linkedTestId && (
                      <Link
                        to={`/test/${resource.linkedTestId}`}
                        onClick={onClose}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 dark:bg-brand-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-brand-700 transition-colors"
                      >
                        <Play className="h-3.5 w-3.5" />
                        <span>Attempt as Timed Test</span>
                      </Link>
                    )}
                  </div>
                </div>

                {/* Document Preview Summary Sections */}
                {resource.documentPreview &&
                  resource.documentPreview.length > 0 && (
                    <div className="space-y-3">
                      {resource.documentPreview.map((sec, idx) => (
                        <div
                          key={idx}
                          className="rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/70 p-4"
                        >
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200 mb-2 flex items-center gap-1.5">
                            <FileText className="h-3.5 w-3.5 text-brand-600" />
                            <span>{sec.heading}</span>
                          </h4>
                          <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 list-disc list-inside">
                            {sec.content.map((line, lIdx) => (
                              <li key={lIdx} className="leading-relaxed">
                                {line}
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  )}
              </div>

              {/* Linked Full Questions & Worked Solutions in Document */}
              {linkedQuestions.length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      Complete Paper Questions & Worked Solutions (
                      {linkedQuestions.length} Questions)
                    </h4>
                    <button
                      type="button"
                      onClick={() => setShowAnswersInPreview((prev) => !prev)}
                      className="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100"
                    >
                      {showAnswersInPreview
                        ? 'Hide Answer Key & Solutions'
                        : 'Show Answer Key & Solutions'}
                    </button>
                  </div>

                  {linkedQuestions.map((q, idx) => (
                    <div
                      key={q.id}
                      className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-3"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="inline-flex h-6 w-6 items-center justify-center rounded-md bg-brand-600 text-white font-bold text-xs">
                            Q{idx + 1}
                          </span>
                          <span className="font-mono text-slate-500">
                            {q.id}
                          </span>
                          <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2 py-0.5 font-medium text-slate-700 dark:text-slate-300">
                            {q.chapter}
                          </span>
                        </div>
                        <span className="font-semibold text-slate-600 dark:text-slate-400">
                          Marks: +{q.marksCorrect} / {q.marksIncorrect}
                        </span>
                      </div>

                      <p className="text-sm font-medium leading-relaxed text-slate-900 dark:text-slate-100">
                        {q.questionText}
                      </p>

                      {q.diagram && <DiagramView diagram={q.diagram} />}

                      {q.options && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                          {q.options.map((opt) => {
                            const isCorrect =
                              showAnswersInPreview &&
                              opt.id === q.correctAnswer;
                            return (
                              <div
                                key={opt.id}
                                className={`flex items-start gap-2.5 rounded-lg border p-2.5 text-xs ${
                                  isCorrect
                                    ? 'border-emerald-500 bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 font-semibold'
                                    : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                                }`}
                              >
                                <span className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded bg-slate-100 dark:bg-slate-800 font-bold text-[11px]">
                                  {opt.id}
                                </span>
                                <span>{opt.text}</span>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {showAnswersInPreview && (
                        <div className="mt-3 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 p-3.5 text-xs space-y-1.5">
                          <div className="font-bold text-emerald-700 dark:text-emerald-400">
                            Verified Answer: Option ({q.correctAnswer})
                          </div>
                          <p className="whitespace-pre-line text-slate-700 dark:text-slate-300 leading-relaxed">
                            {q.explanation}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
