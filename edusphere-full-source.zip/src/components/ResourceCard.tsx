import React from 'react';
import { Link } from 'react-router-dom';
import {
  FileText,
  Download,
  BookOpen,
  Play,
  Bookmark,
  CheckCircle2,
  Clock,
  Eye,
} from 'lucide-react';
import { StudyResource } from '../core/types';
import { VerificationBadge } from './VerificationBadge';

interface ResourceCardProps {
  resource: StudyResource;
  isBookmarked: boolean;
  onToggleBookmark: (resourceId: string) => void;
  onOpenViewer: (resource: StudyResource) => void;
}

export const ResourceCard: React.FC<ResourceCardProps> = ({
  resource,
  isBookmarked,
  onToggleBookmark,
  onOpenViewer,
}) => {
  const subjectColors: Record<string, string> = {
    Physics:
      'bg-indigo-50 text-indigo-800 border-indigo-200 dark:bg-indigo-950/60 dark:text-indigo-300 dark:border-indigo-800',
    Chemistry:
      'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800',
    Mathematics:
      'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800',
  };

  return (
    <article className="flex flex-col justify-between rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm hover:shadow-md hover:border-brand-300 dark:hover:border-brand-700 transition-all">
      <div className="space-y-3">
        {/* Top Metadata Row */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="rounded-md bg-slate-900 dark:bg-brand-600 px-2 py-0.5 font-semibold text-white">
              {resource.exam}
            </span>
            <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2 py-0.5 font-medium text-slate-700 dark:text-slate-300">
              {resource.classLevel}
            </span>
            <span
              className={`rounded-md border px-2 py-0.5 font-semibold ${
                subjectColors[resource.subject] || ''
              }`}
            >
              {resource.subject}
            </span>
            <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2 py-0.5 font-medium text-slate-600 dark:text-slate-400">
              {resource.category}
            </span>
          </div>

          <button
            type="button"
            onClick={() => onToggleBookmark(resource.id)}
            className={`inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border transition-colors ${
              isBookmarked
                ? 'border-brand-300 bg-brand-50 text-brand-600 dark:border-brand-700 dark:bg-brand-950 dark:text-brand-400'
                : 'border-slate-200 dark:border-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
            }`}
            aria-label={
              isBookmarked
                ? `Remove ${resource.title} from bookmarks`
                : `Bookmark ${resource.title}`
            }
            title={isBookmarked ? 'Saved to local bookmarks' : 'Save bookmark'}
          >
            <Bookmark
              className={`h-4 w-4 ${isBookmarked ? 'fill-current' : ''}`}
            />
          </button>
        </div>

        {/* Title & Session/Year */}
        <div>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Year: {resource.year}
            </span>
            {resource.sessionOrSet && (
              <>
                <span>•</span>
                <span>{resource.sessionOrSet}</span>
              </>
            )}
            {resource.chapter && (
              <>
                <span>•</span>
                <span>Ch: {resource.chapter}</span>
              </>
            )}
          </div>
          <h3 className="text-base font-bold leading-snug text-slate-900 dark:text-white">
            {resource.title}
          </h3>
          <p className="mt-1.5 text-xs leading-relaxed text-slate-600 dark:text-slate-400 line-clamp-2">
            {resource.description}
          </p>
        </div>

        {/* Provenance & Verification Badge */}
        <div className="pt-0.5">
          <VerificationBadge verification={resource.verification} />
        </div>

        {/* Availability Checklist Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 pt-1 text-[11px]">
          <div
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 font-medium ${
              resource.pdfAvailable
                ? 'bg-emerald-50/80 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-300'
                : 'bg-amber-50/80 dark:bg-amber-950/30 text-amber-800 dark:text-amber-300'
            }`}
          >
            {resource.pdfAvailable ? (
              <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-600" />
            ) : (
              <Clock className="h-3.5 w-3.5 shrink-0 text-amber-600" />
            )}
            <span>
              {resource.pdfAvailable
                ? `PDF (${resource.pdfFileSize || 'Ready'})`
                : 'PDF Pending'}
            </span>
          </div>

          <div
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 font-medium ${
              resource.hasOnlineQuestionSet
                ? 'bg-brand-50/80 dark:bg-brand-950/30 text-brand-800 dark:text-brand-300'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
            }`}
          >
            <BookOpen className="h-3.5 w-3.5 shrink-0 text-brand-600" />
            <span>{resource.linkedQuestionIds.length} Online Qs</span>
          </div>

          <div
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 font-medium ${
              resource.hasAnswerKey
                ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                : 'bg-slate-100 text-slate-400'
            }`}
          >
            <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-600" />
            <span>Answer Key</span>
          </div>

          <div
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 font-medium ${
              resource.hasWorkedSolutions
                ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                : 'bg-slate-100 text-slate-400'
            }`}
          >
            <FileText className="h-3.5 w-3.5 shrink-0 text-brand-600" />
            <span>Solutions</span>
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <div className="mt-4 pt-3.5 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
        {resource.pdfAvailable && resource.pdfUrl ? (
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => onOpenViewer(resource)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 dark:bg-brand-600 px-3 py-2 text-xs font-semibold text-white hover:bg-brand-700 transition-colors"
            >
              <Eye className="h-3.5 w-3.5" />
              <span>View PDF & Key</span>
            </button>
            <a
              href={resource.pdfUrl}
              download={`${resource.id}.pdf`}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download PDF</span>
            </a>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => onOpenViewer(resource)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-amber-300 dark:border-amber-800 bg-amber-50/80 dark:bg-amber-950/40 px-3 py-2 text-xs font-semibold text-amber-900 dark:text-amber-300 hover:bg-amber-100 transition-colors"
          >
            <Clock className="h-3.5 w-3.5" />
            <span>PDF Pending — View Online Set</span>
          </button>
        )}

        <div className="flex items-center gap-2">
          {resource.linkedTestId && (
            <Link
              to={`/test/${resource.linkedTestId}`}
              className="inline-flex items-center gap-1 rounded-lg bg-brand-50 dark:bg-brand-950/80 border border-brand-200 dark:border-brand-800 px-2.5 py-2 text-xs font-semibold text-brand-700 dark:text-brand-300 hover:bg-brand-100 transition-colors"
            >
              <Play className="h-3.5 w-3.5" />
              <span>Mock Test</span>
            </Link>
          )}
        </div>
      </div>
    </article>
  );
};
