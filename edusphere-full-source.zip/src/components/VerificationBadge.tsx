import React from 'react';
import {
  ShieldCheck,
  FileCheck2,
  BookOpenCheck,
  Clock,
} from 'lucide-react';
import { VerificationMetadata } from '../core/types';

interface VerificationBadgeProps {
  verification: VerificationMetadata;
  showSource?: boolean;
  size?: 'sm' | 'md';
}

export const VerificationBadge: React.FC<VerificationBadgeProps> = ({
  verification,
  showSource = false,
  size = 'sm',
}) => {
  const { status, label, source, contentVersion } = verification;

  const badgeStyles: Record<
    VerificationMetadata['status'],
    {
      bg: string;
      text: string;
      border: string;
      Icon: React.ComponentType<{ className?: string }>;
    }
  > = {
    verified_official_key: {
      bg: 'bg-emerald-50 dark:bg-emerald-950/50',
      text: 'text-emerald-800 dark:text-emerald-300',
      border: 'border-emerald-200 dark:border-emerald-800',
      Icon: ShieldCheck,
    },
    independently_prepared_solution: {
      bg: 'bg-indigo-50 dark:bg-indigo-950/50',
      text: 'text-indigo-800 dark:text-indigo-300',
      border: 'border-indigo-200 dark:border-indigo-800',
      Icon: FileCheck2,
    },
    edusphere_original_practice: {
      bg: 'bg-sky-50 dark:bg-sky-950/50',
      text: 'text-sky-800 dark:text-sky-300',
      border: 'border-sky-200 dark:border-sky-800',
      Icon: BookOpenCheck,
    },
    pending_verification: {
      bg: 'bg-amber-50 dark:bg-amber-950/50',
      text: 'text-amber-800 dark:text-amber-300',
      border: 'border-amber-200 dark:border-amber-800',
      Icon: Clock,
    },
  };

  const style = badgeStyles[status] || badgeStyles.edusphere_original_practice;
  const Icon = style.Icon;

  return (
    <div className="inline-flex flex-col gap-0.5">
      <span
        className={`inline-flex items-center gap-1.5 rounded-full border font-medium ${
          style.bg
        } ${style.text} ${style.border} ${
          size === 'sm' ? 'px-2.5 py-0.5 text-xs' : 'px-3 py-1 text-xs'
        }`}
        title={`Source: ${source} (${contentVersion})`}
      >
        <Icon className="h-3.5 w-3.5 shrink-0" />
        <span>{label}</span>
        <span className="opacity-70 font-mono text-[10px]">{contentVersion}</span>
      </span>
      {showSource && (
        <span className="text-[11px] text-slate-500 dark:text-slate-400 pl-1">
          Source: {source}
        </span>
      )}
    </div>
  );
};
