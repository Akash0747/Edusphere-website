import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, HardDrive, BookOpen, CheckCircle2 } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-slate-200 dark:border-slate-800 bg-slate-900 text-slate-300 mt-16">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Column 1: Brand & Vision */}
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600 text-white font-bold">
                E
              </div>
              <span className="text-lg font-bold tracking-tight text-white">
                EduSphere
              </span>
            </div>
            <p className="text-xs leading-relaxed text-slate-400">
              A free, open-access academic study platform for Class 11, Class 12
              CBSE Board examinations, and JEE Main preparation. Built with
              strict content verification and zero mandatory accounts.
            </p>
            <div className="flex items-center gap-2 text-xs text-emerald-400 font-medium pt-1">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              <span>100% Free • No Registration or Paywalls</span>
            </div>
          </div>

          {/* Column 2: Study Categories */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white mb-3">
              Study Resources
            </h3>
            <ul className="space-y-2 text-xs">
              <li>
                <Link
                  to="/library?exam=CBSE+Board"
                  className="hover:text-white transition-colors"
                >
                  CBSE Class 11 & 12 Sample Papers & PYQs
                </Link>
              </li>
              <li>
                <Link
                  to="/library?exam=JEE+Main"
                  className="hover:text-white transition-colors"
                >
                  JEE Main Shift Practice Papers & Solutions
                </Link>
              </li>
              <li>
                <Link
                  to="/practice"
                  className="hover:text-white transition-colors"
                >
                  Interactive Chapter-Wise Question Bank
                </Link>
              </li>
              <li>
                <Link
                  to="/tests"
                  className="hover:text-white transition-colors"
                >
                  Timed Mock Tests & Full Exam Simulations
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Data Integrity & Provenance */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white mb-3">
              Content Integrity
            </h3>
            <div className="space-y-2.5 text-xs text-slate-400">
              <div className="flex items-start gap-2">
                <ShieldCheck className="h-4 w-4 text-brand-400 shrink-0 mt-0.5" />
                <span>
                  Every resource and question displays its exact verification
                  status, source attribution, and version tag.
                </span>
              </div>
              <div className="flex items-start gap-2">
                <BookOpen className="h-4 w-4 text-brand-400 shrink-0 mt-0.5" />
                <span>
                  Unavailable archival PDFs are honestly labeled rather than
                  linking to placeholder or broken files.
                </span>
              </div>
              <Link
                to="/architecture"
                className="inline-block text-brand-400 hover:text-brand-300 font-medium pt-1"
              >
                Inspect Content Schema & Android Roadmap →
              </Link>
            </div>
          </div>

          {/* Column 4: Local Storage & Privacy Notice */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white mb-3">
              Device Storage & Privacy
            </h3>
            <div className="rounded-xl bg-slate-800/80 border border-slate-700/80 p-3.5 text-xs text-slate-300 space-y-2">
              <div className="flex items-center gap-2 font-semibold text-white">
                <HardDrive className="h-4 w-4 text-emerald-400 shrink-0" />
                <span>Local-Only Progress Saving</span>
              </div>
              <p className="text-[11px] leading-relaxed text-slate-400">
                Your test attempts, active timers, and bookmarks are saved
                locally in this browser. Local data does not automatically
                synchronize across separate devices. We never collect passwords
                or personal information.
              </p>
              <Link
                to="/progress"
                className="inline-block text-[11px] font-semibold text-emerald-400 hover:text-emerald-300"
              >
                Manage or Clear Local History →
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-slate-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            © {new Date().getFullYear()} EduSphere Educational Platform (Release
            v1.0). Designed for Class 11, Class 12 & JEE Main Students.
          </p>
          <p>
            Practice simulations are self-paced study tools and not proctored
            official examinations.
          </p>
        </div>
      </div>
    </footer>
  );
};
