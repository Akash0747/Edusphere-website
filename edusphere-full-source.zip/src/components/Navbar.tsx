import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  BookOpen,
  FileText,
  CheckSquare,
  BarChart2,
  Database,
  Menu,
  X,
  Sun,
  Moon,
  PlayCircle,
  Home,
} from 'lucide-react';
import { getActiveTestSessions } from '../core/storage';

interface NavbarProps {
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ theme, onToggleTheme }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTestId, setActiveTestId] = useState<string | null>(null);
  const location = useLocation();

  useEffect(() => {
    setMobileMenuOpen(false);
    const sessions = getActiveTestSessions();
    const unfinishedIds = Object.keys(sessions).filter(
      (k) => !sessions[k].isSubmitted
    );
    setActiveTestId(unfinishedIds.length > 0 ? unfinishedIds[0] : null);
  }, [location.pathname]);

  const navItems = [
    { to: '/', label: 'Home', Icon: Home },
    { to: '/library', label: 'Resource Library', Icon: FileText },
    { to: '/practice', label: 'Question Bank', Icon: BookOpen },
    { to: '/tests', label: 'Mock Tests', Icon: CheckSquare },
    { to: '/progress', label: 'My Progress', Icon: BarChart2 },
    { to: '/architecture', label: 'Data & Android Spec', Icon: Database },
  ];

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          {/* Brand Logo */}
          <Link
            to="/"
            className="flex items-center gap-3 group focus:outline-none focus:ring-2 focus:ring-brand-600 rounded-lg"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-900 dark:bg-brand-600 shadow-sm group-hover:bg-brand-700 transition-colors">
              <svg
                viewBox="0 0 64 64"
                className="h-7 w-7"
                fill="none"
                aria-hidden="true"
              >
                <circle
                  cx="32"
                  cy="32"
                  r="22"
                  stroke="#818CF8"
                  strokeWidth="3.5"
                />
                <ellipse
                  cx="32"
                  cy="32"
                  rx="11"
                  ry="22"
                  stroke="#C7D2FE"
                  strokeWidth="2.5"
                  strokeDasharray="3 2"
                />
                <path
                  d="M11 25C19 29 45 29 53 25"
                  stroke="#C7D2FE"
                  strokeWidth="2.5"
                />
                <path
                  d="M21 34L29 42L45 24"
                  stroke="#34D399"
                  strokeWidth="4.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">
                  EduSphere
                </span>
                <span className="hidden sm:inline-block rounded-md bg-brand-50 dark:bg-brand-950 border border-brand-200 dark:border-brand-800 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-brand-700 dark:text-brand-300">
                  Free Open-Access
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-none">
                Class 11 & 12 • CBSE Board • JEE Main
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav
            aria-label="Main navigation"
            className="hidden lg:flex items-center gap-1"
          >
            {navItems.map(({ to, label, Icon }) => {
              const active = isActive(to);
              return (
                <Link
                  key={to}
                  to={to}
                  className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                    active
                      ? 'bg-brand-50 dark:bg-brand-950/70 text-brand-700 dark:text-brand-300 font-semibold'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span>{label}</span>
                </Link>
              );
            })}
          </nav>

          {/* Right Controls */}
          <div className="flex items-center gap-2">
            {activeTestId && !location.pathname.startsWith('/test/') && (
              <Link
                to={`/test/${activeTestId}`}
                className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/15 border border-amber-500/40 px-3 py-1.5 text-xs font-semibold text-amber-800 dark:text-amber-300 hover:bg-amber-500/25 transition-colors"
                title="Resume your in-progress mock test"
              >
                <PlayCircle className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />
                <span className="hidden sm:inline">Resume Active Test</span>
                <span className="sm:hidden">Resume</span>
              </Link>
            )}

            <button
              type="button"
              onClick={onToggleTheme}
              className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-colors"
              aria-label={
                theme === 'dark'
                  ? 'Switch to light academic appearance'
                  : 'Switch to dark appearance'
              }
              title={
                theme === 'dark'
                  ? 'Switch to Light Academic Mode'
                  : 'Switch to Dark Mode'
              }
            >
              {theme === 'dark' ? (
                <Sun className="h-4 w-4 text-amber-400" />
              ) : (
                <Moon className="h-4 w-4 text-slate-700" />
              )}
            </button>

            {/* Mobile Hamburger Button */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen((prev) => !prev)}
              className="inline-flex lg:hidden h-9 w-9 items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
              aria-expanded={mobileMenuOpen}
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <nav
          aria-label="Mobile navigation"
          className="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-1 shadow-lg"
        >
          {navItems.map(({ to, label, Icon }) => {
            const active = isActive(to);
            return (
              <Link
                key={to}
                to={to}
                className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium ${
                  active
                    ? 'bg-brand-50 dark:bg-brand-950/80 text-brand-700 dark:text-brand-300 font-semibold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span>{label}</span>
              </Link>
            );
          })}
        </nav>
      )}
    </header>
  );
};
