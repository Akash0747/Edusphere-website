import React, { useState } from 'react';
import { Maximize2, Minimize2 } from 'lucide-react';
import { QuestionDiagram } from '../core/types';

interface DiagramViewProps {
  diagram: QuestionDiagram;
}

export const DiagramView: React.FC<DiagramViewProps> = ({ diagram }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <figure
      className="my-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 sm:p-4 shadow-sm"
      aria-label={diagram.altText}
    >
      <div className="flex items-center justify-between gap-2 mb-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
          {diagram.title}
        </span>
        <button
          type="button"
          onClick={() => setExpanded((prev) => !prev)}
          className="inline-flex items-center gap-1 rounded-md border border-slate-200 dark:border-slate-700 px-2 py-1 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          aria-label={expanded ? 'Shrink diagram' : 'Expand diagram'}
        >
          {expanded ? (
            <>
              <Minimize2 className="h-3.5 w-3.5" />
              <span>Compact Size</span>
            </>
          ) : (
            <>
              <Maximize2 className="h-3.5 w-3.5" />
              <span>Enlarge Diagram</span>
            </>
          )}
        </button>
      </div>

      <div
        className={`mx-auto w-full transition-all ${
          expanded ? 'max-w-2xl' : 'max-w-md'
        }`}
        style={{ aspectRatio: diagram.aspectRatio }}
      >
        <div
          role="img"
          aria-label={diagram.altText}
          className="w-full h-full flex items-center justify-center [&>svg]:w-full [&>svg]:h-auto [&>svg]:max-h-full [&>svg]:rounded-lg"
          dangerouslySetInnerHTML={{ __html: diagram.svgContent }}
        />
      </div>

      {diagram.caption && (
        <figcaption className="mt-2 text-center text-xs text-slate-600 dark:text-slate-400">
          {diagram.caption}
        </figcaption>
      )}
    </figure>
  );
};
