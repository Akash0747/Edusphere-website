import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  BookOpen,
  Search,
  CheckCircle2,
  XCircle,
  Bookmark,
  RotateCcw,
  Eye,
  HelpCircle,
  Lightbulb,
} from 'lucide-react';
import { QUESTIONS_DATASET } from '../data/questionsData';
import {
  ClassLevel,
  DifficultyLevel,
  ExamType,
  SubjectType,
  VerificationStatus,
} from '../core/types';
import { filterQuestions, QuestionFilterState } from '../core/searchEngine';
import {
  getBookmarkedQuestionIds,
  toggleBookmarkedQuestion,
  getPracticedQuestions,
  recordPracticedQuestion,
  PracticedQuestionRecord,
} from '../core/storage';
import { VerificationBadge } from '../components/VerificationBadge';
import { DiagramView } from '../components/DiagramView';

export const PracticePage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [selectedOptions, setSelectedOptions] = useState<
    Record<string, string>
  >({});
  const [submittedMap, setSubmittedMap] = useState<Record<string, boolean>>({});
  const [studyRevealAll, setStudyRevealAll] = useState(false);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [practicedMap, setPracticedMap] = useState<
    Record<string, PracticedQuestionRecord>
  >({});

  useEffect(() => {
    setBookmarkedIds(getBookmarkedQuestionIds());
    setPracticedMap(getPracticedQuestions());
  }, []);

  const filters: QuestionFilterState = useMemo(() => {
    const examP = searchParams.get('exam') as ExamType | null;
    const classP = searchParams.get('class') as ClassLevel | null;
    const subP = searchParams.get('subject') as SubjectType | null;
    const chapP = searchParams.get('chapter');
    const diffP = searchParams.get('difficulty') as DifficultyLevel | null;
    const diagP = searchParams.get('diagrams') === 'true';
    const qP = searchParams.get('q') || '';

    return {
      searchQuery: qP,
      exam:
        examP === 'JEE Main' || examP === 'CBSE Board' ? examP : 'ALL',
      classLevel:
        classP === 'Class 11' || classP === 'Class 12' ? classP : 'ALL',
      subject:
        subP === 'Physics' || subP === 'Chemistry' || subP === 'Mathematics'
          ? subP
          : 'ALL',
      chapter: chapP || 'ALL',
      difficulty:
        diffP === 'Easy' || diffP === 'Moderate' || diffP === 'Challenging'
          ? diffP
          : 'ALL',
      verificationStatus: 'ALL' as VerificationStatus | 'ALL',
      onlyWithDiagrams: diagP,
    };
  }, [searchParams]);

  const updateFilter = (patch: Partial<QuestionFilterState>) => {
    const next = { ...filters, ...patch };
    if (patch.subject !== undefined && patch.subject !== filters.subject) {
      next.chapter = 'ALL';
    }
    const params = new URLSearchParams();
    if (next.searchQuery.trim()) params.set('q', next.searchQuery.trim());
    if (next.exam !== 'ALL') params.set('exam', next.exam);
    if (next.classLevel !== 'ALL') params.set('class', next.classLevel);
    if (next.subject !== 'ALL') params.set('subject', next.subject);
    if (next.chapter !== 'ALL') params.set('chapter', next.chapter);
    if (next.difficulty !== 'ALL') params.set('difficulty', next.difficulty);
    if (next.onlyWithDiagrams) params.set('diagrams', 'true');
    setSearchParams(params, { replace: true });
  };

  const availableChapters = useMemo(() => {
    const scoped = QUESTIONS_DATASET.filter((q) => {
      if (filters.exam !== 'ALL' && q.exam !== filters.exam) return false;
      if (filters.classLevel !== 'ALL' && q.classLevel !== filters.classLevel)
        return false;
      if (filters.subject !== 'ALL' && q.subject !== filters.subject)
        return false;
      return true;
    });
    return Array.from(new Set(scoped.map((q) => q.chapter))).sort();
  }, [filters.exam, filters.classLevel, filters.subject]);

  const filteredQuestions = useMemo(
    () => filterQuestions(QUESTIONS_DATASET, filters),
    [filters]
  );

  const handleSelectOption = (questionId: string, optionId: string) => {
    if (submittedMap[questionId]) return;
    setSelectedOptions((prev) => ({ ...prev, [questionId]: optionId }));
  };

  const handleCheckAnswer = (
    questionId: string,
    correctAnswer: string
  ) => {
    const chosen = selectedOptions[questionId];
    if (!chosen) return;
    setSubmittedMap((prev) => ({ ...prev, [questionId]: true }));
    const updated = recordPracticedQuestion({
      questionId,
      selectedAnswer: chosen,
      isCorrect: chosen === correctAnswer,
      practicedAtIso: new Date().toISOString(),
    });
    setPracticedMap(updated);
  };

  const handleResetQuestion = (questionId: string) => {
    setSubmittedMap((prev) => {
      const copy = { ...prev };
      delete copy[questionId];
      return copy;
    });
    setSelectedOptions((prev) => {
      const copy = { ...prev };
      delete copy[questionId];
      return copy;
    });
  };

  const handleToggleBookmark = (questionId: string) => {
    setBookmarkedIds(toggleBookmarkedQuestion(questionId));
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-brand-600 dark:text-brand-400 mb-1">
            <BookOpen className="h-3.5 w-3.5" />
            <span>Interactive Question Bank</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Chapter-Wise Practice & Worked Solutions
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-2xl">
            Select answers to test your understanding with instant feedback, or
            enable Revision Mode to inspect step-by-step solutions and diagrams.
          </p>
        </div>

        {/* Practice Mode Switcher */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setStudyRevealAll((prev) => !prev)}
            className={`inline-flex items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-semibold transition-colors ${
              studyRevealAll
                ? 'border-brand-500 bg-brand-50 dark:bg-brand-950 text-brand-700 dark:text-brand-300'
                : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100'
            }`}
          >
            <Eye className="h-4 w-4" />
            <span>
              {studyRevealAll
                ? 'Revision Mode Active (Solutions Shown)'
                : 'Switch to Revision Mode (Reveal All Solutions)'}
            </span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <section
        aria-label="Filter questions"
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-5 shadow-sm space-y-4"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          <div className="sm:col-span-2 relative">
            <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={filters.searchQuery}
              onChange={(e) => updateFilter({ searchQuery: e.target.value })}
              placeholder="Search question ID, formula, topic, or keyword..."
              aria-label="Search questions"
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 pl-10 pr-3 py-2 text-xs text-slate-900 dark:text-white focus:border-brand-500 focus:outline-none"
            />
          </div>

          <select
            aria-label="Filter by Examination"
            value={filters.exam}
            onChange={(e) =>
              updateFilter({ exam: e.target.value as ExamType | 'ALL' })
            }
            className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs text-slate-800 dark:text-slate-200"
          >
            <option value="ALL">All Exams</option>
            <option value="JEE Main">JEE Main (+4 / −1)</option>
            <option value="CBSE Board">CBSE Board (+1 / 0)</option>
          </select>

          <select
            aria-label="Filter by Class"
            value={filters.classLevel}
            onChange={(e) =>
              updateFilter({ classLevel: e.target.value as ClassLevel | 'ALL' })
            }
            className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs text-slate-800 dark:text-slate-200"
          >
            <option value="ALL">All Classes</option>
            <option value="Class 11">Class 11</option>
            <option value="Class 12">Class 12</option>
          </select>

          <select
            aria-label="Filter by Subject"
            value={filters.subject}
            onChange={(e) =>
              updateFilter({ subject: e.target.value as SubjectType | 'ALL' })
            }
            className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs text-slate-800 dark:text-slate-200"
          >
            <option value="ALL">All Subjects (PCM)</option>
            <option value="Physics">Physics</option>
            <option value="Chemistry">Chemistry</option>
            <option value="Mathematics">Mathematics</option>
          </select>

          <select
            aria-label="Filter by Chapter"
            value={filters.chapter}
            onChange={(e) => updateFilter({ chapter: e.target.value })}
            className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs text-slate-800 dark:text-slate-200"
          >
            <option value="ALL">All Chapters</option>
            {availableChapters.map((ch) => (
              <option key={ch} value={ch}>
                {ch}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div className="flex flex-wrap items-center gap-4">
            <label className="inline-flex items-center gap-2 cursor-pointer select-none text-slate-700 dark:text-slate-300 font-medium">
              <input
                type="checkbox"
                checked={filters.onlyWithDiagrams}
                onChange={(e) =>
                  updateFilter({ onlyWithDiagrams: e.target.checked })
                }
                className="h-4 w-4 rounded border-slate-300 text-brand-600"
              />
              <span>Only Questions with Vector Diagrams</span>
            </label>

            <div className="flex items-center gap-1.5">
              <span className="text-slate-500">Difficulty:</span>
              {(['ALL', 'Easy', 'Moderate', 'Challenging'] as const).map(
                (diff) => (
                  <button
                    key={diff}
                    type="button"
                    onClick={() => updateFilter({ difficulty: diff })}
                    className={`rounded-md px-2 py-0.5 text-xs font-medium ${
                      filters.difficulty === diff
                        ? 'bg-slate-900 dark:bg-brand-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {diff === 'ALL' ? 'All' : diff}
                  </button>
                )
              )}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-slate-500">
              Showing <strong>{filteredQuestions.length}</strong> of{' '}
              {QUESTIONS_DATASET.length} verified questions
            </span>
            <button
              type="button"
              onClick={() => setSearchParams(new URLSearchParams())}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 dark:border-slate-700 px-2.5 py-1 font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Reset</span>
            </button>
          </div>
        </div>
      </section>

      {/* Questions List */}
      <div className="space-y-5">
        {filteredQuestions.map((q, index) => {
          const chosen = selectedOptions[q.id];
          const isSubmitted = Boolean(submittedMap[q.id]);
          const showSolution = isSubmitted || studyRevealAll;
          const isCorrect = chosen === q.correctAnswer;
          const isBookmarked = bookmarkedIds.includes(q.id);
          const previousPractice = practicedMap[q.id];

          return (
            <article
              key={q.id}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-sm space-y-4"
            >
              {/* Question Metadata Header */}
              <div className="flex flex-wrap items-start justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="inline-flex h-6 px-2 items-center justify-center rounded-md bg-slate-900 dark:bg-brand-600 text-white font-bold">
                    Q{index + 1}
                  </span>
                  <span className="font-mono text-slate-500 dark:text-slate-400">
                    {q.id}
                  </span>
                  <span className="rounded-md bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800 px-2 py-0.5 font-semibold text-brand-700 dark:text-brand-300">
                    {q.exam} • {q.classLevel}
                  </span>
                  <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2 py-0.5 font-medium text-slate-700 dark:text-slate-300">
                    {q.subject} — {q.chapter}
                  </span>
                  <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2 py-0.5 text-slate-600 dark:text-slate-400">
                    {q.difficulty}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2.5 py-1 text-xs font-semibold text-slate-700 dark:text-slate-300">
                    +{q.marksCorrect} / {q.marksIncorrect} Marks
                  </span>
                  <button
                    type="button"
                    onClick={() => handleToggleBookmark(q.id)}
                    className={`inline-flex h-8 w-8 items-center justify-center rounded-lg border transition-colors ${
                      isBookmarked
                        ? 'border-brand-300 bg-brand-50 text-brand-600 dark:border-brand-700 dark:bg-brand-950 dark:text-brand-400'
                        : 'border-slate-200 dark:border-slate-700 text-slate-400 hover:text-slate-700'
                    }`}
                    aria-label={
                      isBookmarked
                        ? `Remove bookmark for ${q.id}`
                        : `Bookmark question ${q.id}`
                    }
                  >
                    <Bookmark
                      className={`h-4 w-4 ${
                        isBookmarked ? 'fill-current' : ''
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Topic & Question Stem */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  Topic: {q.topic}
                </div>
                <p className="text-sm sm:text-base font-medium leading-relaxed text-slate-900 dark:text-slate-100">
                  {q.questionText}
                </p>
              </div>

              {/* Technical Diagram if present */}
              {q.diagram && <DiagramView diagram={q.diagram} />}

              {/* Answer Options */}
              {q.options && (
                <div
                  role="radiogroup"
                  aria-label={`Answer options for question ${q.id}`}
                  className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1"
                >
                  {q.options.map((opt) => {
                    const isSelected = chosen === opt.id;
                    const isRightOption = opt.id === q.correctAnswer;

                    let cardClass =
                      'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-brand-400 text-slate-800 dark:text-slate-200';
                    if (showSolution) {
                      if (isRightOption) {
                        cardClass =
                          'border-emerald-500 bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-200 font-semibold';
                      } else if (isSelected && !isRightOption) {
                        cardClass =
                          'border-rose-500 bg-rose-50/80 dark:bg-rose-950/40 text-rose-950 dark:text-rose-200';
                      }
                    } else if (isSelected) {
                      cardClass =
                        'border-brand-600 bg-brand-50/80 dark:bg-brand-950/60 text-brand-950 dark:text-brand-200 ring-1 ring-brand-600 font-semibold';
                    }

                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => handleSelectOption(q.id, opt.id)}
                        disabled={isSubmitted}
                        className={`flex items-start gap-3 rounded-xl border p-3.5 text-left text-xs sm:text-sm transition-all ${cardClass}`}
                      >
                        <span
                          className={`inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-lg text-xs font-bold ${
                            showSolution && isRightOption
                              ? 'bg-emerald-600 text-white'
                              : showSolution && isSelected && !isRightOption
                              ? 'bg-rose-600 text-white'
                              : isSelected
                              ? 'bg-brand-600 text-white'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {opt.id}
                        </span>
                        <span className="flex-1 leading-relaxed">
                          {opt.text}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Action Bar & Provenance */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <VerificationBadge verification={q.verification} />

                <div className="flex items-center gap-2">
                  {previousPractice && !isSubmitted && (
                    <span className="text-xs text-slate-500">
                      Previously practiced:{' '}
                      <strong
                        className={
                          previousPractice.isCorrect
                            ? 'text-emerald-600'
                            : 'text-amber-600'
                        }
                      >
                        {previousPractice.isCorrect
                          ? 'Solved Correctly'
                          : `Chose (${previousPractice.selectedAnswer})`}
                      </strong>
                    </span>
                  )}

                  {!isSubmitted ? (
                    <button
                      type="button"
                      disabled={!chosen}
                      onClick={() => handleCheckAnswer(q.id, q.correctAnswer)}
                      className={`inline-flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold transition-colors ${
                        chosen
                          ? 'bg-brand-600 text-white hover:bg-brand-700 shadow-sm'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      <CheckCircle2 className="h-4 w-4" />
                      <span>Check Answer</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleResetQuestion(q.id)}
                      className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 dark:border-slate-700 px-3.5 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100"
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                      <span>Try Again</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Worked Solution Box */}
              {showSolution && (
                <div
                  className={`mt-4 rounded-xl border p-4 space-y-2.5 text-xs sm:text-sm ${
                    isSubmitted
                      ? isCorrect
                        ? 'border-emerald-200 dark:border-emerald-800/80 bg-emerald-50/50 dark:bg-emerald-950/30'
                        : 'border-rose-200 dark:border-rose-800/80 bg-rose-50/50 dark:bg-rose-950/30'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2 font-bold">
                      {isSubmitted ? (
                        isCorrect ? (
                          <span className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400">
                            <CheckCircle2 className="h-4 w-4" />
                            <span>
                              Correct! (+{q.marksCorrect} Marks) — Option (
                              {q.correctAnswer})
                            </span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 text-rose-700 dark:text-rose-400">
                            <XCircle className="h-4 w-4" />
                            <span>
                              Incorrect ({q.marksIncorrect} Mark) — You selected
                              ({chosen}), Verified Answer is Option (
                              {q.correctAnswer})
                            </span>
                          </span>
                        )
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-brand-700 dark:text-brand-300">
                          <HelpCircle className="h-4 w-4" />
                          <span>Verified Answer: Option ({q.correctAnswer})</span>
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="space-y-1.5 text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                    <div className="font-semibold text-slate-900 dark:text-white">
                      Step-by-Step Worked Solution:
                    </div>
                    {q.explanation}
                  </div>

                  {q.keyTakeaway && (
                    <div className="mt-2 flex items-start gap-2 rounded-lg bg-white/80 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-700 p-2.5 text-xs text-slate-700 dark:text-slate-300">
                      <Lightbulb className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                      <span>
                        <strong>Exam Key Takeaway:</strong> {q.keyTakeaway}
                      </span>
                    </div>
                  )}
                </div>
              )}
            </article>
          );
        })}
      </div>
    </div>
  );
};
