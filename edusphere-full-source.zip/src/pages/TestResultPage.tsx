import React, { useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  Award,
  CheckCircle2,
  XCircle,
  MinusCircle,
  Clock,
  Target,
  BarChart2,
  AlertCircle,
  ArrowRight,
  RotateCcw,
  BookOpen,
  Lightbulb,
  ArrowLeft,
} from 'lucide-react';
import { getAttemptById } from '../core/storage';
import { QUESTIONS_DATASET } from '../data/questionsData';
import { Question } from '../core/types';
import { DiagramView } from '../components/DiagramView';
import { VerificationBadge } from '../components/VerificationBadge';

function formatDurationHuman(seconds: number): string {
  const s = Math.max(0, Math.round(seconds));
  const mins = Math.floor(s / 60);
  const rem = s % 60;
  if (mins === 0) return `${rem}s`;
  return `${mins}m ${rem}s`;
}

export const TestResultPage: React.FC = () => {
  const { testId, attemptId } = useParams<{
    testId: string;
    attemptId: string;
  }>();
  const [reviewFilter, setReviewFilter] = useState<
    'ALL' | 'incorrect' | 'unanswered' | 'correct'
  >('ALL');

  const result = useMemo(
    () => (attemptId ? getAttemptById(attemptId) : null),
    [attemptId]
  );

  const questionMap = useMemo(() => {
    const map = new Map<string, Question>();
    QUESTIONS_DATASET.forEach((q) => map.set(q.id, q));
    return map;
  }, []);

  if (!result) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center space-y-4">
        <AlertCircle className="h-10 w-10 text-amber-500 mx-auto" />
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">
          Test Result Record Not Found on This Device
        </h1>
        <p className="text-xs text-slate-600 dark:text-slate-400">
          Results are stored locally in your browser. If local history was
          cleared or opened on a different device, this attempt ID (
          <code>{attemptId}</code>) will not be present.
        </p>
        <div className="flex justify-center gap-3">
          <Link
            to="/tests"
            className="inline-flex items-center gap-1.5 rounded-xl bg-brand-600 px-4 py-2 text-xs font-bold text-white"
          >
            <span>Browse Mock Tests</span>
          </Link>
          <Link
            to="/progress"
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 dark:border-slate-700 px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300"
          >
            <span>View Local History</span>
          </Link>
        </div>
      </div>
    );
  }

  const bannerTheme = {
    excellent:
      'border-emerald-300 dark:border-emerald-800 bg-emerald-50/90 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-100',
    good: 'border-brand-300 dark:border-brand-800 bg-brand-50/90 dark:bg-brand-950/40 text-brand-950 dark:text-brand-100',
    developing:
      'border-amber-300 dark:border-amber-800 bg-amber-50/90 dark:bg-amber-950/40 text-amber-950 dark:text-amber-100',
  }[result.feedbackTier];

  const filteredQuestionDetails = result.questionDetails.filter((d) => {
    if (reviewFilter === 'ALL') return true;
    return d.status === reviewFilter;
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Top Navigation Row */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link
          to="/tests"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-brand-600"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Mock Tests</span>
        </Link>

        <div className="flex flex-wrap items-center gap-2">
          <Link
            to={`/test/${testId || result.testId}`}
            className="inline-flex items-center gap-1.5 rounded-xl bg-brand-600 px-4 py-2 text-xs font-bold text-white hover:bg-brand-700 transition-colors"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Retake This Mock Test</span>
          </Link>
          <Link
            to="/progress"
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100"
          >
            <BarChart2 className="h-3.5 w-3.5" />
            <span>All Attempts History</span>
          </Link>
        </div>
      </div>

      {/* Proportional Feedback Banner */}
      <section
        aria-label="Performance summary"
        className={`rounded-2xl border p-6 sm:p-7 shadow-sm space-y-4 ${bannerTheme}`}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2 text-xs font-bold uppercase tracking-wider opacity-80">
              <span>{result.exam}</span>
              <span>•</span>
              <span>{result.classLevel}</span>
              <span>•</span>
              <span>
                {result.submissionReason === 'timer_expired'
                  ? 'Auto-Submitted on Timer Expiration'
                  : 'Completed Practice Attempt'}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold">
              {result.feedbackHeadline}
            </h1>
            <p className="text-xs sm:text-sm leading-relaxed max-w-3xl opacity-90">
              {result.feedbackMessage}
            </p>
          </div>

          {/* Big Score Badge */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 px-6 py-4 text-center shrink-0 shadow-sm">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Total Score
            </div>
            <div className="mt-0.5 text-3xl font-extrabold text-slate-900 dark:text-white">
              {result.totalScore}{' '}
              <span className="text-lg font-semibold text-slate-400">
                / {result.maxScore}
              </span>
            </div>
            <div className="mt-1 text-[11px] font-medium text-slate-600 dark:text-slate-400">
              +{result.positiveMarksEarned} earned • −
              {result.negativeMarksDeducted} penalty
            </div>
          </div>
        </div>
      </section>

      {/* Core Metric Cards: Distinguishing Percentage vs Accuracy Clearly */}
      <section
        aria-label="Detailed metrics"
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {/* Card 1: Score Percentage */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-1.5">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
            <span>Overall Score Percentage</span>
            <Award className="h-4 w-4 text-brand-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-white">
            {result.percentage}%
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
            Formula: (Total Score ÷ Max Marks) × 100 ({result.totalScore} ÷{' '}
            {result.maxScore}).
          </p>
        </div>

        {/* Card 2: Attempt Accuracy */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-1.5">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
            <span>Attempt Accuracy</span>
            <Target className="h-4 w-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-extrabold text-emerald-700 dark:text-emerald-400">
            {result.accuracy}%
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
            Formula: (Correct ÷ Attempted) × 100 ({result.correctCount} of{' '}
            {result.attemptedCount} attempted).
          </p>
        </div>

        {/* Card 3: Question Counts Breakdown */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-2">
          <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
            Response Breakdown ({result.totalQuestions} Qs)
          </div>
          <div className="flex items-center justify-between text-xs pt-0.5">
            <span className="inline-flex items-center gap-1 font-bold text-emerald-700 dark:text-emerald-400">
              <CheckCircle2 className="h-3.5 w-3.5" />
              {result.correctCount} Correct
            </span>
            <span className="inline-flex items-center gap-1 font-bold text-rose-700 dark:text-rose-400">
              <XCircle className="h-3.5 w-3.5" />
              {result.incorrectCount} Wrong
            </span>
            <span className="inline-flex items-center gap-1 font-bold text-slate-600 dark:text-slate-400">
              <MinusCircle className="h-3.5 w-3.5" />
              {result.unansweredCount} Skipped
            </span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">
            Attempted {result.attemptedCount} of {result.totalQuestions}{' '}
            questions.
          </p>
        </div>

        {/* Card 4: Time Taken */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-1.5">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
            <span>Time Taken</span>
            <Clock className="h-4 w-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-white">
            {formatDurationHuman(result.totalTimeTakenSeconds)}
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
            Out of {formatDurationHuman(result.durationAllocatedSeconds)}{' '}
            allocated (Avg{' '}
            {Math.round(
              result.totalTimeTakenSeconds / Math.max(1, result.totalQuestions)
            )}
            s / question).
          </p>
        </div>
      </section>

      {/* Subject-Wise Performance Table */}
      <section
        aria-labelledby="subject-breakdown-heading"
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm space-y-4"
      >
        <h2
          id="subject-breakdown-heading"
          className="text-base sm:text-lg font-bold text-slate-900 dark:text-white"
        >
          Subject-Wise Performance Breakdown
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                <th className="py-2.5 pr-4 font-semibold">Subject</th>
                <th className="py-2.5 px-3 font-semibold">Score</th>
                <th className="py-2.5 px-3 font-semibold">Score %</th>
                <th className="py-2.5 px-3 font-semibold">Accuracy</th>
                <th className="py-2.5 px-3 font-semibold">
                  Correct / Wrong / Skipped
                </th>
                <th className="py-2.5 pl-3 font-semibold">Time Spent</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {result.subjectBreakdown.map((sub) => (
                <tr key={sub.subject}>
                  <td className="py-3 pr-4 font-bold text-slate-900 dark:text-white">
                    {sub.subject}
                  </td>
                  <td className="py-3 px-3 font-bold text-brand-700 dark:text-brand-300">
                    {sub.score} / {sub.maxScore}
                  </td>
                  <td className="py-3 px-3">{sub.percentage}%</td>
                  <td className="py-3 px-3 font-semibold text-emerald-700 dark:text-emerald-400">
                    {sub.accuracy}%
                  </td>
                  <td className="py-3 px-3">
                    <span className="text-emerald-600 font-semibold">
                      {sub.correctCount}C
                    </span>{' '}
                    /{' '}
                    <span className="text-rose-600 font-semibold">
                      {sub.incorrectCount}W
                    </span>{' '}
                    /{' '}
                    <span className="text-slate-500">
                      {sub.unansweredCount}S
                    </span>
                  </td>
                  <td className="py-3 pl-3 font-mono text-xs text-slate-600 dark:text-slate-400">
                    {formatDurationHuman(sub.timeSpentSeconds)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Evidence-Based Mistake Analysis & Next Study Recommendations */}
      <section
        aria-labelledby="mistake-analysis-heading"
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm space-y-5"
      >
        <div className="space-y-1">
          <h2
            id="mistake-analysis-heading"
            className="text-base sm:text-lg font-bold text-slate-900 dark:text-white"
          >
            Evidence-Based Mistake Analysis & Weak-Topic Indicators
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            EduSphere strictly separates <strong>Measured Facts</strong>{' '}
            (recorded responses, marks lost, and time spent) from{' '}
            <strong>Possible Explanations to Investigate</strong> during your
            self-review.
          </p>
        </div>

        {result.mistakeAnalysis.length === 0 ? (
          <div className="rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 p-4 text-xs sm:text-sm text-emerald-900 dark:text-emerald-200 flex items-center gap-3">
            <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0" />
            <span>
              Zero incorrect or unanswered questions recorded in this attempt!
              Every tested chapter achieved 100% accuracy.
            </span>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {result.mistakeAnalysis.map((finding) => (
              <div
                key={`${finding.subject}-${finding.chapter}`}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 p-4 space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider text-brand-600 dark:text-brand-400">
                        {finding.subject}
                      </span>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                        {finding.chapter} ({finding.topic})
                      </h3>
                    </div>
                    <span
                      className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold uppercase ${
                        finding.severity === 'high'
                          ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          : finding.severity === 'medium'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {finding.severity === 'high'
                        ? 'Priority Review'
                        : 'Needs Practice'}
                    </span>
                  </div>

                  {/* Measured Facts */}
                  <div className="rounded-lg bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700 p-3 space-y-1 text-xs">
                    <div className="font-bold text-slate-800 dark:text-slate-200">
                      Measured Facts (From Attempt Data):
                    </div>
                    <ul className="list-disc list-inside space-y-1 text-slate-600 dark:text-slate-300">
                      {finding.measuredFacts.map((fact, idx) => (
                        <li key={idx}>{fact}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Possible Explanations */}
                  <div className="rounded-lg bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200/60 dark:border-indigo-800/60 p-3 space-y-1 text-xs">
                    <div className="font-bold text-indigo-900 dark:text-indigo-300">
                      Possible Explanations to Self-Check:
                    </div>
                    <ul className="list-disc list-inside space-y-1 text-slate-700 dark:text-slate-300">
                      {finding.possibleExplanations.map((exp, idx) => (
                        <li key={idx}>{exp}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between gap-2 border-t border-slate-200/70 dark:border-slate-700/70 text-xs">
                  <span className="text-slate-600 dark:text-slate-400 line-clamp-1">
                    {finding.recommendedAction}
                  </span>
                  <Link
                    to={`/practice?subject=${encodeURIComponent(
                      finding.subject
                    )}&chapter=${encodeURIComponent(finding.chapter)}`}
                    className="inline-flex items-center gap-1 rounded-lg bg-brand-600 px-3 py-1.5 font-semibold text-white hover:bg-brand-700 shrink-0"
                  >
                    <BookOpen className="h-3.5 w-3.5" />
                    <span>Practice Chapter</span>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Next Study Session Action Plan */}
        <div className="rounded-xl bg-slate-900 text-white p-4 sm:p-5 space-y-2.5">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-indigo-300">
            <Lightbulb className="h-4 w-4 text-amber-400" />
            <span>Recommended Next Study Session Plan</span>
          </div>
          <ul className="space-y-1.5 text-xs sm:text-sm text-slate-200 list-decimal list-inside">
            {result.nextStudyRecommendations.map((rec, i) => (
              <li key={i} className="leading-relaxed">
                {rec}
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Question-by-Question Answer Review & Worked Explanations */}
      <section
        aria-labelledby="question-review-heading"
        className="space-y-4"
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2
              id="question-review-heading"
              className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white"
            >
              Question-by-Question Answer & Solution Review
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Compare your selected option with the verified answer and study
              each step-by-step derivation.
            </p>
          </div>

          <div className="inline-flex rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-1">
            {[
              { id: 'ALL', label: `All (${result.totalQuestions})` },
              {
                id: 'incorrect',
                label: `Incorrect (${result.incorrectCount})`,
              },
              {
                id: 'unanswered',
                label: `Unanswered (${result.unansweredCount})`,
              },
              { id: 'correct', label: `Correct (${result.correctCount})` },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() =>
                  setReviewFilter(
                    tab.id as 'ALL' | 'incorrect' | 'unanswered' | 'correct'
                  )
                }
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                  reviewFilter === tab.id
                    ? 'bg-slate-900 dark:bg-brand-600 text-white'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          {filteredQuestionDetails.map((detail) => {
            const fullQ = questionMap.get(detail.questionId);
            if (!fullQ) return null;

            return (
              <article
                key={detail.questionId}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-sm space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 text-xs">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex h-6 px-2.5 items-center justify-center rounded-md bg-slate-900 dark:bg-brand-600 text-white font-bold">
                      Q{detail.questionNumber}
                    </span>
                    <span className="font-mono text-slate-500">
                      {detail.questionId}
                    </span>
                    <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2 py-0.5 font-medium text-slate-700 dark:text-slate-300">
                      {detail.subject} — {detail.chapter}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-slate-500 font-mono">
                      Time: {detail.timeSpentSeconds}s
                    </span>
                    <span
                      className={`rounded-lg px-2.5 py-1 font-bold ${
                        detail.status === 'correct'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : detail.status === 'incorrect'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200 dark:bg-rose-950/60 dark:text-rose-300'
                          : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                      }`}
                    >
                      {detail.status === 'correct'
                        ? `Correct (+${detail.marksAwarded})`
                        : detail.status === 'incorrect'
                        ? `Incorrect (${detail.marksAwarded})`
                        : `Unanswered (0)`}
                    </span>
                  </div>
                </div>

                <p className="text-sm sm:text-base font-medium leading-relaxed text-slate-900 dark:text-slate-100">
                  {fullQ.questionText}
                </p>

                {fullQ.diagram && <DiagramView diagram={fullQ.diagram} />}

                {fullQ.options && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {fullQ.options.map((opt) => {
                      const isCorrectOpt = opt.id === detail.correctAnswer;
                      const isUserOpt = opt.id === detail.selectedOption;

                      let boxStyle =
                        'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300';
                      if (isCorrectOpt) {
                        boxStyle =
                          'border-emerald-500 bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-200 font-semibold';
                      } else if (isUserOpt && !isCorrectOpt) {
                        boxStyle =
                          'border-rose-500 bg-rose-50/80 dark:bg-rose-950/40 text-rose-950 dark:text-rose-200 font-semibold';
                      }

                      return (
                        <div
                          key={opt.id}
                          className={`flex items-start gap-3 rounded-xl border p-3 text-xs sm:text-sm ${boxStyle}`}
                        >
                          <span
                            className={`inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-lg text-xs font-bold ${
                              isCorrectOpt
                                ? 'bg-emerald-600 text-white'
                                : isUserOpt
                                ? 'bg-rose-600 text-white'
                                : 'bg-slate-100 dark:bg-slate-800'
                            }`}
                          >
                            {opt.id}
                          </span>
                          <div className="flex-1">
                            <div>{opt.text}</div>
                            {isCorrectOpt && (
                              <span className="inline-block mt-1 text-[11px] font-bold text-emerald-700 dark:text-emerald-400">
                                ✓ Verified Correct Answer
                              </span>
                            )}
                            {isUserOpt && !isCorrectOpt && (
                              <span className="inline-block mt-1 text-[11px] font-bold text-rose-700 dark:text-rose-400">
                                ✗ Your Selected Option
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 p-4 space-y-2 text-xs sm:text-sm">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-bold text-slate-900 dark:text-white">
                      Worked Solution & Derivation:
                    </span>
                    <VerificationBadge verification={fullQ.verification} />
                  </div>
                  <p className="whitespace-pre-line text-slate-700 dark:text-slate-300 leading-relaxed">
                    {fullQ.explanation}
                  </p>
                  {fullQ.keyTakeaway && (
                    <div className="pt-1 text-xs font-semibold text-brand-700 dark:text-brand-300 flex items-center gap-1.5">
                      <ArrowRight className="h-3.5 w-3.5 shrink-0" />
                      <span>Takeaway: {fullQ.keyTakeaway}</span>
                    </div>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </section>
    </div>
  );
};
