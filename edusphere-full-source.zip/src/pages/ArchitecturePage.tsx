import React, { useState, useEffect } from 'react';
import {
  Database,
  CheckCircle2,
  AlertTriangle,
  Smartphone,
  ShieldCheck,
  Code2,
  Server,
  Play,
} from 'lucide-react';
import { validateQuestionDataset, ValidationReport } from '../core/validator';
import { QUESTIONS_DATASET } from '../data/questionsData';

const SAMPLE_VALID_QUESTION_JSON = JSON.stringify(
  [
    {
      id: 'PHY-12-SAMPLE-999',
      exam: 'JEE Main',
      classLevel: 'Class 12',
      subject: 'Physics',
      chapter: 'Electrostatics',
      topic: 'Capacitors in Parallel',
      questionType: 'mcq_single',
      difficulty: 'Easy',
      questionText:
        'Two identical parallel-plate capacitors of capacitance C = 6 μF each are connected in parallel across a 10 V battery. What is the total electrostatic energy stored in the system?',
      options: [
        { id: 'A', text: '3.0 × 10⁻⁴ J' },
        { id: 'B', text: '6.0 × 10⁻⁴ J' },
        { id: 'C', text: '1.2 × 10⁻³ J' },
        { id: 'D', text: '1.5 × 10⁻⁴ J' },
      ],
      correctAnswer: 'B',
      explanation:
        'Equivalent capacitance in parallel is C_eq = 6 + 6 = 12 μF. Total stored energy U = (1/2) C_eq V² = 0.5 × (12 × 10⁻⁶ F) × (10 V)² = 6.0 × 10⁻⁴ J.',
      marksCorrect: 4,
      marksIncorrect: -1,
      marksUnanswered: 0,
      verification: {
        status: 'edusphere_original_practice',
        label: 'EduSphere Verified Practice Question',
        source: 'EduSphere Physics Curriculum Pipeline',
        contentVersion: 'v1.0',
        lastChecked: '2026-10-14',
      },
    },
  ],
  null,
  2
);

export const ArchitecturePage: React.FC = () => {
  const [jsonInput, setJsonInput] = useState<string>(
    SAMPLE_VALID_QUESTION_JSON
  );
  const [validationReport, setValidationReport] =
    useState<ValidationReport | null>(null);
  const [parseError, setParseError] = useState<string | null>(null);
  const [apiHealth, setApiHealth] = useState<{
    status: string;
    version: string;
    counts?: { resources: number; questions: number; mockTests: number };
  } | null>(null);

  useEffect(() => {
    fetch('/api/v1/health')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data) setApiHealth(data);
      })
      .catch(() => {
        setApiHealth(null);
      });

    // Run initial validation on sample
    try {
      const parsed = JSON.parse(SAMPLE_VALID_QUESTION_JSON);
      setValidationReport(validateQuestionDataset(parsed));
    } catch {
      // ignore
    }
  }, []);

  const handleRunValidation = () => {
    setParseError(null);
    try {
      const parsed = JSON.parse(jsonInput);
      const report = validateQuestionDataset(parsed);
      setValidationReport(report);
    } catch (err) {
      setValidationReport(null);
      setParseError(
        err instanceof Error ? err.message : 'Invalid JSON syntax.'
      );
    }
  };

  const prodRepoReport = validateQuestionDataset(QUESTIONS_DATASET);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-6 space-y-2">
        <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-brand-600 dark:text-brand-400">
          <Database className="h-3.5 w-3.5" />
          <span>Content Management, Security & Android Readiness</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          Data Integrity Pipeline & Future Android Architecture
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-3xl">
          Inspect how EduSphere decouples structured educational data and the
          deterministic scoring engine from the UI, enforces strict verification
          metadata, and prepares shared REST APIs for the next-stage Android
          application.
        </p>
      </div>

      {/* Live Repository & REST API Status */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500">
            <span>Production Dataset Validation</span>
            <ShieldCheck className="h-4 w-4 text-emerald-600" />
          </div>
          <div className="text-xl font-extrabold text-emerald-700 dark:text-emerald-400">
            {prodRepoReport.valid ? '100% Schema Valid' : 'Issues Detected'}
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            {prodRepoReport.checkedCount} questions verified with 0 errors and 0
            warnings.
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500">
            <span>Shared REST API Endpoint</span>
            <Server className="h-4 w-4 text-brand-600" />
          </div>
          <div className="text-xl font-extrabold text-slate-900 dark:text-white">
            {apiHealth?.status === 'ok'
              ? `Online (v${apiHealth.version})`
              : 'Local Engine Ready'}
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            Serving <code>/api/v1/resources</code>,{' '}
            <code>/api/v1/questions</code>, <code>/api/v1/tests</code>, and{' '}
            <code>/api/v1/score</code>.
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500">
            <span>Anonymous Write Protection</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-600" />
          </div>
          <div className="text-xl font-extrabold text-slate-900 dark:text-white">
            Read-Only Public Access
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            Public visitors cannot mutate repository files; content updates go
            through validated CLI imports (<code>npm run validate:content</code>
            ).
          </p>
        </div>
      </section>

      {/* Interactive Question Set Import Validator */}
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Code2 className="h-5 w-5 text-brand-600" />
              <span>Interactive Question Dataset Schema Validator</span>
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Test and validate new JSON question sets against EduSphere’s data
              integrity rules before committing them to the content repository.
            </p>
          </div>

          <button
            type="button"
            onClick={handleRunValidation}
            className="inline-flex items-center gap-1.5 rounded-xl bg-brand-600 hover:bg-brand-700 px-4 py-2 text-xs font-bold text-white shadow-sm"
          >
            <Play className="h-3.5 w-3.5" />
            <span>Validate JSON Payload</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="json-validator-input"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
            >
              Paste Question Array JSON:
            </label>
            <textarea
              id="json-validator-input"
              rows={14}
              value={jsonInput}
              onChange={(e) => setJsonInput(e.target.value)}
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-950 text-slate-100 font-mono text-xs p-3.5 focus:border-brand-500 focus:outline-none"
            />
          </div>

          <div className="space-y-3">
            <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              Validation Report:
            </div>

            {parseError && (
              <div className="rounded-xl border border-rose-300 bg-rose-50 dark:bg-rose-950/50 p-4 text-xs text-rose-800 dark:text-rose-200 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <AlertTriangle className="h-4 w-4" />
                  <span>JSON Syntax Error</span>
                </div>
                <p className="font-mono">{parseError}</p>
              </div>
            )}

            {validationReport && (
              <div
                className={`rounded-xl border p-4 space-y-3 text-xs ${
                  validationReport.valid
                    ? 'border-emerald-200 dark:border-emerald-800 bg-emerald-50/70 dark:bg-emerald-950/30'
                    : 'border-rose-200 dark:border-rose-800 bg-rose-50/70 dark:bg-rose-950/30'
                }`}
              >
                <div className="flex items-center justify-between font-bold text-sm">
                  <span
                    className={
                      validationReport.valid
                        ? 'text-emerald-800 dark:text-emerald-300'
                        : 'text-rose-800 dark:text-rose-300'
                    }
                  >
                    {validationReport.valid
                      ? '✓ Dataset Passed All Integrity Checks'
                      : `✗ Validation Failed (${validationReport.errorCount} Error(s))`}
                  </span>
                  <span className="text-xs font-mono">
                    Checked: {validationReport.checkedCount} item(s)
                  </span>
                </div>

                {validationReport.issues.length === 0 ? (
                  <p className="text-slate-700 dark:text-slate-300">
                    All required fields (ID uniqueness, exam/class/subject
                    taxonomy, 4 distinct MCQ options A–D, valid marking rules,
                    and provenance attribution) are verified.
                  </p>
                ) : (
                  <ul className="space-y-1.5 max-h-60 overflow-y-auto">
                    {validationReport.issues.map((iss, idx) => (
                      <li
                        key={idx}
                        className="rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5"
                      >
                        <span className="font-mono font-bold text-rose-600">
                          [{iss.itemId} → {iss.field}]
                        </span>{' '}
                        <span className="text-slate-700 dark:text-slate-300">
                          {iss.message}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Next-Stage Android Application Architecture & Consultation */}
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm space-y-5">
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-600 text-white">
            <Smartphone className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
              Next-Stage Android Application Roadmap & Architecture Comparison
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Note: While this web platform is fully responsive on Android
              phones, the dedicated native Android app is planned as the next
              engineering stage reusing our decoupled core modules and REST API.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                <th className="py-2.5 pr-4 font-bold">Android Approach</th>
                <th className="py-2.5 px-3 font-bold">Code Reuse with Web</th>
                <th className="py-2.5 px-3 font-bold">
                  Offline PDF & SQLite Support
                </th>
                <th className="py-2.5 pl-3 font-bold">
                  Architectural Recommendation
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              <tr>
                <td className="py-3 pr-4 font-bold text-brand-700 dark:text-brand-300">
                  1. React Native (Expo + TypeScript) — Recommended for Fast
                  Shared Logic
                </td>
                <td className="py-3 px-3">
                  Directly shares 100% of <code>src/core/types.ts</code>,{' '}
                  <code>scoringEngine.ts</code>, <code>searchEngine.ts</code>,
                  and <code>validator.ts</code>.
                </td>
                <td className="py-3 px-3">
                  Excellent via <code>expo-sqlite</code> and{' '}
                  <code>expo-file-system</code> for offline PDF caching.
                </td>
                <td className="py-3 pl-3">
                  <strong>Best balance</strong> of native mobile UX and direct
                  reuse of EduSphere’s TypeScript scoring and validation core.
                </td>
              </tr>
              <tr>
                <td className="py-3 pr-4 font-bold text-slate-900 dark:text-white">
                  2. Native Kotlin + Jetpack Compose
                </td>
                <td className="py-3 px-3">
                  Consumes <code>/api/v1/*</code> REST endpoints and JSON
                  dataset schemas; UI & scoring ported to Kotlin.
                </td>
                <td className="py-3 px-3">
                  Best-in-class Room SQLite DB & native Android{' '}
                  <code>PdfRenderer</code>.
                </td>
                <td className="py-3 pl-3">
                  Ideal if long-term hardware-level performance and low-end
                  Android memory footprint are the top priority.
                </td>
              </tr>
              <tr>
                <td className="py-3 pr-4 font-bold text-slate-900 dark:text-white">
                  3. Capacitor / Trusted Web Activity (TWA)
                </td>
                <td className="py-3 px-3">
                  Wraps the existing Vite + React web bundle directly.
                </td>
                <td className="py-3 px-3">
                  Requires Capacitor filesystem plugins for offline PDFs.
                </td>
                <td className="py-3 pl-3">
                  Fastest initial packaging, though React Native or Kotlin
                  Compose provides superior offline exam reliability.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
