import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  Clock,
  ChevronLeft,
  ChevronRight,
  Flag,
  Trash2,
  Send,
  AlertTriangle,
  CheckCircle2,
  LayoutGrid,
  Play,
  ArrowLeft,
  ShieldAlert,
} from 'lucide-react';
import { MOCK_TESTS_DATASET } from '../data/mockTestsData';
import { QUESTIONS_DATASET } from '../data/questionsData';
import {
  ActiveTestSession,
  Question,
  QuestionPaletteStatus,
  QuestionResponseState,
} from '../core/types';
import {
  getQuestionPaletteStatus,
  scoreTestAttempt,
} from '../core/scoringEngine';
import {
  getActiveTestSession,
  saveActiveTestSession,
  saveCompletedAttempt,
  computeRemainingSeconds,
  computeElapsedSeconds,
  removeActiveTestSession,
} from '../core/storage';
import { DiagramView } from '../components/DiagramView';

function formatTimer(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds));
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = safe % 60;
  if (hrs > 0) {
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(
      2,
      '0'
    )}:${String(secs).padStart(2, '0')}`;
  }
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export const TestEnginePage: React.FC = () => {
  const { testId } = useParams<{ testId: string }>();
  const navigate = useNavigate();

  const testConfig = useMemo(
    () => MOCK_TESTS_DATASET.find((t) => t.id === testId) ?? null,
    [testId]
  );

  const testQuestions: Question[] = useMemo(() => {
    if (!testConfig) return [];
    const qMap = new Map(QUESTIONS_DATASET.map((q) => [q.id, q]));
    return testConfig.questionIds
      .map((id) => qMap.get(id))
      .filter((q): q is Question => Boolean(q));
  }, [testConfig]);

  const [session, setSession] = useState<ActiveTestSession | null>(null);
  const [showInstructions, setShowInstructions] = useState<boolean>(true);
  const [remainingSeconds, setRemainingSeconds] = useState<number>(0);
  const [showSubmitModal, setShowSubmitModal] = useState<boolean>(false);
  const [mobilePaletteOpen, setMobilePaletteOpen] = useState<boolean>(false);
  const [restoredFromStorage, setRestoredFromStorage] =
    useState<boolean>(false);

  const isSubmittingRef = useRef<boolean>(false);
  const questionEnteredAtMsRef = useRef<number>(Date.now());

  // Initialize or restore active session on mount
  useEffect(() => {
    if (!testConfig || testQuestions.length === 0) return;

    const existing = getActiveTestSession(testConfig.id);
    if (existing && !existing.isSubmitted) {
      const now = Date.now();
      const rem = computeRemainingSeconds(existing, now);
      const elapsed = computeElapsedSeconds(existing, now);
      const resumedSession: ActiveTestSession = {
        ...existing,
        elapsedSecondsBeforeResume: elapsed,
        lastTickTimestampMs: now,
      };
      saveActiveTestSession(resumedSession);
      setSession(resumedSession);
      setRemainingSeconds(rem);
      setShowInstructions(false);
      setRestoredFromStorage(true);
      questionEnteredAtMsRef.current = now;
    } else {
      setShowInstructions(true);
      setRemainingSeconds(testConfig.durationMinutes * 60);
    }
  }, [testConfig, testQuestions.length]);

  const startFreshSession = () => {
    if (!testConfig || testQuestions.length === 0) return;
    const now = Date.now();
    const initialResponses: Record<string, QuestionResponseState> = {};
    testQuestions.forEach((q, idx) => {
      initialResponses[q.id] = {
        questionId: q.id,
        selectedOption: null,
        markedForReview: false,
        visited: idx === 0,
        timeSpentSeconds: 0,
      };
    });

    const newSession: ActiveTestSession = {
      sessionId: `${testConfig.id}-${now}`,
      testId: testConfig.id,
      startedAtIso: new Date(now).toISOString(),
      lastUpdatedAtIso: new Date(now).toISOString(),
      durationSeconds: testConfig.durationMinutes * 60,
      elapsedSecondsBeforeResume: 0,
      lastTickTimestampMs: now,
      currentQuestionIndex: 0,
      responses: initialResponses,
      isSubmitted: false,
    };

    saveActiveTestSession(newSession);
    setSession(newSession);
    setRemainingSeconds(newSession.durationSeconds);
    setShowInstructions(false);
    setRestoredFromStorage(false);
    questionEnteredAtMsRef.current = now;
  };

  // Finalize submission safely (manual or timer_expired)
  const executeFinalSubmit = useCallback(
    (
      activeSession: ActiveTestSession,
      reason: 'manual_submit' | 'timer_expired'
    ) => {
      if (!testConfig || isSubmittingRef.current) return;
      isSubmittingRef.current = true;

      const now = Date.now();
      const currentQ = testQuestions[activeSession.currentQuestionIndex];
      const deltaQuestionSec = Math.max(
        0,
        Math.round((now - questionEnteredAtMsRef.current) / 1000)
      );

      const updatedResponses = { ...activeSession.responses };
      if (currentQ && updatedResponses[currentQ.id]) {
        updatedResponses[currentQ.id] = {
          ...updatedResponses[currentQ.id],
          timeSpentSeconds:
            updatedResponses[currentQ.id].timeSpentSeconds + deltaQuestionSec,
        };
      }

      const finalElapsed = computeElapsedSeconds(activeSession, now);
      const finalizedSession: ActiveTestSession = {
        ...activeSession,
        responses: updatedResponses,
        elapsedSecondsBeforeResume: finalElapsed,
        lastTickTimestampMs: now,
        isSubmitted: true,
      };

      const result = scoreTestAttempt(
        testConfig,
        testQuestions,
        finalizedSession,
        reason,
        finalElapsed
      );

      saveCompletedAttempt(result);
      navigate(`/test/${testConfig.id}/result/${result.attemptId}`, {
        replace: true,
      });
    },
    [testConfig, testQuestions, navigate]
  );

  // Live countdown interval when session is active
  useEffect(() => {
    if (!session || showInstructions || session.isSubmitted) return;

    const timer = window.setInterval(() => {
      const now = Date.now();
      const rem = computeRemainingSeconds(session, now);
      setRemainingSeconds(rem);

      if (rem <= 0 && !isSubmittingRef.current) {
        window.clearInterval(timer);
        executeFinalSubmit(session, 'timer_expired');
      }
    }, 500);

    return () => window.clearInterval(timer);
  }, [session, showInstructions, executeFinalSubmit]);

  if (!testConfig || testQuestions.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center space-y-4">
        <AlertTriangle className="h-10 w-10 text-amber-500 mx-auto" />
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">
          Mock Test Configuration Not Found
        </h1>
        <p className="text-xs text-slate-600 dark:text-slate-400">
          The requested mock test ID (<code>{testId}</code>) does not exist in
          the repository.
        </p>
        <Link
          to="/tests"
          className="inline-flex items-center gap-1.5 rounded-xl bg-brand-600 px-4 py-2 text-xs font-bold text-white"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Mock Tests</span>
        </Link>
      </div>
    );
  }

  // Pre-Test Instructions Screen
  if (showInstructions || !session) {
    const maxMarks =
      testQuestions.length * testConfig.markingScheme.correctMarks;
    return (
      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 space-y-6">
        <Link
          to="/tests"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-brand-600"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to All Mock Tests</span>
        </Link>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm space-y-6">
          <div className="space-y-2 border-b border-slate-100 dark:border-slate-800 pb-5">
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="rounded-md bg-slate-900 dark:bg-brand-600 px-2.5 py-1 font-bold text-white">
                {testConfig.exam}
              </span>
              <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2.5 py-1 font-medium text-slate-700 dark:text-slate-300">
                {testConfig.classLevel}
              </span>
              <span className="rounded-md bg-brand-50 dark:bg-brand-950/60 px-2.5 py-1 font-semibold text-brand-700 dark:text-brand-300">
                {testConfig.durationMinutes} Minutes • {testQuestions.length}{' '}
                Questions • {maxMarks} Marks
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              {testConfig.title}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              {testConfig.subtitle}
            </p>
          </div>

          {/* Marking Scheme Table */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="rounded-xl border border-emerald-200 dark:border-emerald-800/80 bg-emerald-50/60 dark:bg-emerald-950/30 p-4">
              <div className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                Correct Answer
              </div>
              <div className="mt-1 text-2xl font-extrabold text-emerald-700 dark:text-emerald-400">
                +{testConfig.markingScheme.correctMarks} Marks
              </div>
            </div>

            <div className="rounded-xl border border-rose-200 dark:border-rose-800/80 bg-rose-50/60 dark:bg-rose-950/30 p-4">
              <div className="text-xs font-semibold text-rose-800 dark:text-rose-300">
                Incorrect Answer (Negative Marking)
              </div>
              <div className="mt-1 text-2xl font-extrabold text-rose-700 dark:text-rose-400">
                {testConfig.markingScheme.negativeMarks === 0
                  ? '0 Marks (No Penalty)'
                  : `${testConfig.markingScheme.negativeMarks} Mark`}
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 p-4">
              <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Unanswered Question
              </div>
              <div className="mt-1 text-2xl font-extrabold text-slate-800 dark:text-slate-200">
                0 Marks
              </div>
            </div>
          </div>

          {/* Instructions List */}
          <div className="space-y-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
              Examination Instructions & Palette Guide
            </h2>
            <ul className="space-y-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300 list-disc list-inside">
              {testConfig.instructions.map((inst, i) => (
                <li key={i} className="leading-relaxed">
                  {inst}
                </li>
              ))}
            </ul>
          </div>

          {/* Question Palette Legend */}
          <div className="rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 p-4 space-y-2.5">
            <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Question Palette Status Indicators:
            </div>
            <div className="flex flex-wrap gap-4 text-xs">
              <div className="flex items-center gap-2">
                <span className="inline-block h-6 w-6 rounded-md bg-emerald-600 text-white font-bold text-center leading-6">
                  1
                </span>
                <span>Answered</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="inline-block h-6 w-6 rounded-md bg-rose-600 text-white font-bold text-center leading-6">
                  2
                </span>
                <span>Visited & Not Answered</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="inline-block h-6 w-6 rounded-md bg-violet-600 text-white font-bold text-center leading-6">
                  3
                </span>
                <span>Marked for Review</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="relative inline-block h-6 w-6 rounded-md bg-indigo-600 text-white font-bold text-center leading-6">
                  4
                  <span className="absolute -top-1 -right-1 h-2.5 w-2.5 rounded-full bg-emerald-400 border border-white" />
                </span>
                <span>Answered & Marked for Review (Counted in Score)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="inline-block h-6 w-6 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-center leading-6">
                  5
                </span>
                <span>Not Visited</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <ShieldAlert className="h-4 w-4 text-brand-600 shrink-0" />
              <span>
                Self-paced timed practice simulation • Auto-saved locally in
                your browser
              </span>
            </div>
            <button
              type="button"
              onClick={startFreshSession}
              className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-6 py-3 text-sm font-bold text-white hover:bg-brand-700 transition-colors shadow-sm"
            >
              <Play className="h-4 w-4" />
              <span>Begin Timed Test Now</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Active Examination Screen
  const currentIndex = session.currentQuestionIndex;
  const currentQuestion = testQuestions[currentIndex] || testQuestions[0];
  const currentResponse = session.responses[currentQuestion.id] || {
    questionId: currentQuestion.id,
    selectedOption: null,
    markedForReview: false,
    visited: true,
    timeSpentSeconds: 0,
  };

  // Helper to update session state & persist to localStorage
  const commitSessionUpdate = (
    updater: (prev: ActiveTestSession, deltaQuestionSec: number) => ActiveTestSession
  ) => {
    const now = Date.now();
    const deltaQuestionSec = Math.max(
      0,
      Math.round((now - questionEnteredAtMsRef.current) / 1000)
    );
    questionEnteredAtMsRef.current = now;

    setSession((prev) => {
      if (!prev) return prev;
      const elapsedTotal = computeElapsedSeconds(prev, now);
      const baseWithTime: ActiveTestSession = {
        ...prev,
        elapsedSecondsBeforeResume: elapsedTotal,
        lastTickTimestampMs: now,
        responses: {
          ...prev.responses,
          [currentQuestion.id]: {
            ...(prev.responses[currentQuestion.id] || currentResponse),
            visited: true,
            timeSpentSeconds:
              (prev.responses[currentQuestion.id]?.timeSpentSeconds ?? 0) +
              deltaQuestionSec,
          },
        },
      };
      const updated = updater(baseWithTime, deltaQuestionSec);
      saveActiveTestSession(updated);
      return updated;
    });
  };

  const handleSelectOption = (optionId: string) => {
    commitSessionUpdate((prev) => ({
      ...prev,
      responses: {
        ...prev.responses,
        [currentQuestion.id]: {
          ...prev.responses[currentQuestion.id],
          selectedOption: optionId,
          visited: true,
        },
      },
    }));
  };

  const handleClearResponse = () => {
    commitSessionUpdate((prev) => ({
      ...prev,
      responses: {
        ...prev.responses,
        [currentQuestion.id]: {
          ...prev.responses[currentQuestion.id],
          selectedOption: null,
          visited: true,
        },
      },
    }));
  };

  const handleToggleMarkForReview = () => {
    commitSessionUpdate((prev) => {
      const curr = prev.responses[currentQuestion.id];
      return {
        ...prev,
        responses: {
          ...prev.responses,
          [currentQuestion.id]: {
            ...curr,
            markedForReview: !curr.markedForReview,
            visited: true,
          },
        },
      };
    });
  };

  const goToQuestionIndex = (targetIdx: number) => {
    const clamped = Math.max(
      0,
      Math.min(testQuestions.length - 1, targetIdx)
    );
    const targetQuestion = testQuestions[clamped];
    commitSessionUpdate((prev) => ({
      ...prev,
      currentQuestionIndex: clamped,
      responses: {
        ...prev.responses,
        [targetQuestion.id]: {
          ...(prev.responses[targetQuestion.id] || {
            questionId: targetQuestion.id,
            selectedOption: null,
            markedForReview: false,
            timeSpentSeconds: 0,
          }),
          visited: true,
        },
      },
    }));
    setMobilePaletteOpen(false);
  };

  const handleMarkForReviewAndNext = () => {
    const nextIdx =
      currentIndex < testQuestions.length - 1 ? currentIndex + 1 : currentIndex;
    const nextQuestion = testQuestions[nextIdx];
    commitSessionUpdate((prev) => ({
      ...prev,
      currentQuestionIndex: nextIdx,
      responses: {
        ...prev.responses,
        [currentQuestion.id]: {
          ...prev.responses[currentQuestion.id],
          markedForReview: true,
          visited: true,
        },
        [nextQuestion.id]: {
          ...(prev.responses[nextQuestion.id] || {
            questionId: nextQuestion.id,
            selectedOption: null,
            markedForReview: false,
            timeSpentSeconds: 0,
          }),
          visited: true,
        },
      },
    }));
  };

  // Compute palette summary counts
  const paletteCounts = {
    answered: 0,
    not_answered: 0,
    marked_for_review: 0,
    answered_marked_for_review: 0,
    not_visited: 0,
  };

  testQuestions.forEach((q) => {
    const st = getQuestionPaletteStatus(session.responses[q.id]);
    paletteCounts[st] += 1;
  });

  const paletteButtonStyle = (
    status: QuestionPaletteStatus,
    isCurrent: boolean
  ) => {
    const ring = isCurrent
      ? 'ring-2 ring-offset-2 ring-slate-900 dark:ring-white'
      : '';
    switch (status) {
      case 'answered':
        return `bg-emerald-600 text-white font-bold ${ring}`;
      case 'not_answered':
        return `bg-rose-600 text-white font-bold ${ring}`;
      case 'marked_for_review':
        return `bg-violet-600 text-white font-bold ${ring}`;
      case 'answered_marked_for_review':
        return `bg-indigo-600 text-white font-bold ${ring}`;
      case 'not_visited':
      default:
        return `bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold ${ring}`;
    }
  };

  const qMarksCorrect = testConfig.markingScheme.useQuestionSpecificMarks
    ? currentQuestion.marksCorrect
    : testConfig.markingScheme.correctMarks;
  const qMarksIncorrect = testConfig.markingScheme.useQuestionSpecificMarks
    ? currentQuestion.marksIncorrect
    : testConfig.markingScheme.negativeMarks;

  return (
    <div className="mx-auto max-w-7xl px-3 sm:px-6 lg:px-8 py-4 space-y-4">
      {/* Top Distraction-Free Exam Header Bar */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-900 text-white px-4 py-3 sm:px-6 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div className="min-w-0">
          <div className="flex items-center gap-2 text-[11px] text-indigo-300 font-semibold">
            <span>{testConfig.exam}</span>
            <span>•</span>
            <span>{testConfig.markingScheme.schemeName}</span>
            {restoredFromStorage && (
              <span className="rounded bg-emerald-500/20 border border-emerald-400/40 px-1.5 py-0.5 text-[10px] text-emerald-300">
                Session Restored
              </span>
            )}
          </div>
          <h1 className="text-sm sm:text-base font-bold truncate">
            {testConfig.title}
          </h1>
        </div>

        {/* Countdown Timer & Submit Action */}
        <div className="flex items-center gap-3">
          <div
            aria-live="polite"
            aria-label="Remaining time"
            className={`inline-flex items-center gap-2 rounded-xl px-3.5 py-2 font-mono text-sm sm:text-base font-extrabold border ${
              remainingSeconds <= 180
                ? 'bg-rose-600/20 border-rose-400 text-rose-300 animate-pulse'
                : 'bg-slate-800 border-slate-700 text-white'
            }`}
          >
            <Clock className="h-4 w-4 text-indigo-400 shrink-0" />
            <span>{formatTimer(remainingSeconds)}</span>
          </div>

          <button
            type="button"
            onClick={() => setMobilePaletteOpen((prev) => !prev)}
            className="inline-flex lg:hidden items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-semibold text-slate-200"
          >
            <LayoutGrid className="h-4 w-4" />
            <span>Palette</span>
          </button>

          <button
            type="button"
            onClick={() => setShowSubmitModal(true)}
            className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 px-4 py-2 text-xs sm:text-sm font-bold text-white transition-colors shadow-sm"
          >
            <Send className="h-3.5 w-3.5" />
            <span>Submit Test</span>
          </button>
        </div>
      </div>

      {/* NTA-Style Subject Section Switcher Tabs (for Multi-Subject Full Papers like 75-Q JEE Main & 52-Q CBSE Board) */}
      {testConfig.subjects.length > 1 && (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3.5 py-2.5 shadow-sm">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mr-1">
              Sections:
            </span>
            {testConfig.subjects.map((subj) => {
              const firstIdx = testQuestions.findIndex((q) => q.subject === subj);
              const subjQuestions = testQuestions.filter((q) => q.subject === subj);
              const subjAnswered = subjQuestions.filter(
                (q) => session.responses[q.id]?.selectedOption !== null
              ).length;
              const isActiveSubj = currentQuestion.subject === subj;
              if (firstIdx === -1) return null;
              return (
                <button
                  key={subj}
                  type="button"
                  onClick={() => goToQuestionIndex(firstIdx)}
                  className={`inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-bold transition-colors ${
                    isActiveSubj
                      ? 'bg-brand-600 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <span>{subj}</span>
                  <span
                    className={`rounded px-1.5 py-0.5 text-[10px] font-extrabold ${
                      isActiveSubj
                        ? 'bg-white/20 text-white'
                        : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {subjAnswered}/{subjQuestions.length}
                  </span>
                </button>
              );
            })}
          </div>
          <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            Total Answered:{' '}
            <span className="font-bold text-emerald-600 dark:text-emerald-400">
              {paletteCounts.answered + paletteCounts.answered_marked_for_review}
            </span>{' '}
            / {testQuestions.length}
          </div>
        </div>
      )}

      {/* Main Two-Column Exam Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Column: Active Question Workspace (8 cols) */}
        <div className="lg:col-span-8 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-sm flex flex-col justify-between min-h-[520px]">
          <div className="space-y-4">
            {/* Question Number & Marks Header */}
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center justify-center rounded-lg bg-brand-600 px-3 py-1 text-xs sm:text-sm font-extrabold text-white">
                  Question {currentIndex + 1} of {testQuestions.length}
                </span>
                <span className="rounded-lg bg-slate-100 dark:bg-slate-800 px-2.5 py-1 text-xs font-semibold text-slate-700 dark:text-slate-300">
                  {currentQuestion.subject} — {currentQuestion.chapter}
                </span>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="rounded-lg bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 px-2.5 py-1 font-bold text-emerald-700 dark:text-emerald-300">
                  Correct: +{qMarksCorrect}
                </span>
                <span className="rounded-lg bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 px-2.5 py-1 font-bold text-rose-700 dark:text-rose-300">
                  Incorrect: {qMarksIncorrect}
                </span>
              </div>
            </div>

            {/* Question Stem */}
            <div className="space-y-2 pt-1">
              <p className="text-sm sm:text-base font-medium leading-relaxed text-slate-900 dark:text-slate-100">
                {currentQuestion.questionText}
              </p>
            </div>

            {/* SVG Diagram if present */}
            {currentQuestion.diagram && (
              <DiagramView diagram={currentQuestion.diagram} />
            )}

            {/* Answer Options */}
            {currentQuestion.options && (
              <div
                role="radiogroup"
                aria-label={`Question ${currentIndex + 1} options`}
                className="space-y-2.5 pt-2"
              >
                {currentQuestion.options.map((opt) => {
                  const isSelected =
                    currentResponse.selectedOption === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      role="radio"
                      aria-checked={isSelected}
                      onClick={() => handleSelectOption(opt.id)}
                      className={`w-full flex items-start gap-3.5 rounded-xl border p-3.5 sm:p-4 text-left text-xs sm:text-sm transition-all ${
                        isSelected
                          ? 'border-brand-600 bg-brand-50/90 dark:bg-brand-950/60 text-brand-950 dark:text-white ring-1 ring-brand-600 font-semibold shadow-sm'
                          : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-brand-300 hover:bg-slate-50/80 dark:hover:bg-slate-800/60 text-slate-800 dark:text-slate-200'
                      }`}
                    >
                      <span
                        className={`inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-lg text-xs font-bold ${
                          isSelected
                            ? 'bg-brand-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {opt.id}
                      </span>
                      <span className="flex-1 leading-relaxed">{opt.text}</span>
                      {isSelected && (
                        <CheckCircle2 className="h-4 w-4 text-brand-600 dark:text-brand-400 shrink-0 mt-0.5" />
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Bottom Question Navigation & Review Controls */}
          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleToggleMarkForReview}
                className={`inline-flex items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-semibold transition-colors ${
                  currentResponse.markedForReview
                    ? 'border-violet-400 bg-violet-50 dark:bg-violet-950/60 text-violet-800 dark:text-violet-300'
                    : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                }`}
              >
                <Flag className="h-3.5 w-3.5" />
                <span>
                  {currentResponse.markedForReview
                    ? 'Marked for Review'
                    : 'Mark for Review'}
                </span>
              </button>

              <button
                type="button"
                onClick={handleMarkForReviewAndNext}
                className="inline-flex items-center gap-1.5 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50/70 dark:bg-indigo-950/50 px-3.5 py-2 text-xs font-semibold text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 transition-colors"
              >
                <span>Mark for Review & Next</span>
              </button>

              <button
                type="button"
                disabled={!currentResponse.selectedOption}
                onClick={handleClearResponse}
                className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-semibold transition-colors ${
                  currentResponse.selectedOption
                    ? 'border-slate-300 dark:border-slate-700 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40'
                    : 'border-slate-200 dark:border-slate-800 text-slate-400 cursor-not-allowed'
                }`}
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Clear Response</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={currentIndex === 0}
                onClick={() => goToQuestionIndex(currentIndex - 1)}
                className={`inline-flex items-center gap-1 rounded-xl border px-3.5 py-2 text-xs font-bold transition-colors ${
                  currentIndex > 0
                    ? 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-100'
                    : 'border-slate-200 dark:border-slate-800 text-slate-400 cursor-not-allowed'
                }`}
              >
                <ChevronLeft className="h-4 w-4" />
                <span>Previous</span>
              </button>

              {currentIndex < testQuestions.length - 1 ? (
                <button
                  type="button"
                  onClick={() => goToQuestionIndex(currentIndex + 1)}
                  className="inline-flex items-center gap-1 rounded-xl bg-brand-600 hover:bg-brand-700 px-4 py-2 text-xs font-bold text-white transition-colors shadow-sm"
                >
                  <span>Save & Next</span>
                  <ChevronRight className="h-4 w-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowSubmitModal(true)}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 px-4 py-2 text-xs font-bold text-white transition-colors shadow-sm"
                >
                  <Send className="h-3.5 w-3.5" />
                  <span>Review & Submit Test</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Question Palette & Status Summary (4 cols) */}
        <aside
          aria-label="Question Palette"
          className={`lg:col-span-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-5 ${
            mobilePaletteOpen ? 'block' : 'hidden lg:block'
          }`}
        >
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">
              Question Palette
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Click any question number to jump directly to it.
            </p>
          </div>

          {/* Status Counts Grid */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-2 rounded-lg bg-slate-50 dark:bg-slate-800/70 p-2">
              <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-emerald-600 text-white font-bold text-[11px]">
                {paletteCounts.answered}
              </span>
              <span className="text-slate-700 dark:text-slate-300 font-medium">
                Answered
              </span>
            </div>

            <div className="flex items-center gap-2 rounded-lg bg-slate-50 dark:bg-slate-800/70 p-2">
              <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-rose-600 text-white font-bold text-[11px]">
                {paletteCounts.not_answered}
              </span>
              <span className="text-slate-700 dark:text-slate-300 font-medium">
                Not Answered
              </span>
            </div>

            <div className="flex items-center gap-2 rounded-lg bg-slate-50 dark:bg-slate-800/70 p-2">
              <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-violet-600 text-white font-bold text-[11px]">
                {paletteCounts.marked_for_review}
              </span>
              <span className="text-slate-700 dark:text-slate-300 font-medium">
                Marked Review
              </span>
            </div>

            <div className="flex items-center gap-2 rounded-lg bg-slate-50 dark:bg-slate-800/70 p-2">
              <span className="relative inline-flex h-5 w-5 items-center justify-center rounded bg-indigo-600 text-white font-bold text-[11px]">
                {paletteCounts.answered_marked_for_review}
                <span className="absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              <span className="text-slate-700 dark:text-slate-300 font-medium">
                Ans + Marked
              </span>
            </div>

            <div className="col-span-2 flex items-center gap-2 rounded-lg bg-slate-50 dark:bg-slate-800/70 p-2">
              <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-[11px]">
                {paletteCounts.not_visited}
              </span>
              <span className="text-slate-700 dark:text-slate-300 font-medium">
                Not Visited Yet
              </span>
            </div>
          </div>

          {/* Question Number Buttons Grid */}
          <div className="grid grid-cols-5 gap-2.5 pt-1">
            {testQuestions.map((q, idx) => {
              const status = getQuestionPaletteStatus(session.responses[q.id]);
              const isCurrent = idx === currentIndex;
              return (
                <button
                  key={q.id}
                  type="button"
                  onClick={() => goToQuestionIndex(idx)}
                  aria-label={`Go to Question ${idx + 1} (${status.replace(
                    /_/g,
                    ' '
                  )})`}
                  className={`relative h-10 w-full rounded-xl text-xs transition-all flex items-center justify-center ${paletteButtonStyle(
                    status,
                    isCurrent
                  )}`}
                >
                  <span>{idx + 1}</span>
                  {status === 'answered_marked_for_review' && (
                    <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-emerald-400 border-2 border-white dark:border-slate-900" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Submit Action inside Palette */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
            <button
              type="button"
              onClick={() => setShowSubmitModal(true)}
              className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 px-4 py-2.5 text-xs font-bold text-white transition-colors shadow-sm"
            >
              <Send className="h-4 w-4" />
              <span>Submit Mock Test</span>
            </button>
            <button
              type="button"
              onClick={() => {
                removeActiveTestSession(testConfig.id);
                setShowInstructions(true);
              }}
              className="w-full text-center text-[11px] font-medium text-slate-500 hover:text-rose-600 transition-colors"
            >
              Discard In-Progress Session & View Instructions
            </button>
          </div>
        </aside>
      </div>

      {/* Submit Confirmation Modal */}
      {showSubmitModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="submit-confirm-title"
        >
          <div className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-5">
            <div className="space-y-1">
              <h2
                id="submit-confirm-title"
                className="text-lg font-extrabold text-slate-900 dark:text-white"
              >
                Confirm Mock Test Submission
              </h2>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                Please verify your attempt summary before finalizing your test
                score and unlocking solutions.
              </p>
            </div>

            <div className="rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 p-4 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-600 dark:text-slate-400">
                  Total Questions:
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {testQuestions.length}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                  Answered (including Answered & Marked):
                </span>
                <span className="font-bold text-emerald-700 dark:text-emerald-400">
                  {paletteCounts.answered +
                    paletteCounts.answered_marked_for_review}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-rose-700 dark:text-rose-400 font-medium">
                  Unanswered (Visited + Not Visited):
                </span>
                <span className="font-bold text-rose-700 dark:text-rose-400">
                  {paletteCounts.not_answered +
                    paletteCounts.marked_for_review +
                    paletteCounts.not_visited}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-violet-700 dark:text-violet-400 font-medium">
                  Flagged for Review:
                </span>
                <span className="font-bold text-violet-700 dark:text-violet-400">
                  {paletteCounts.marked_for_review +
                    paletteCounts.answered_marked_for_review}
                </span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-200 dark:border-slate-700">
                <span className="text-slate-600 dark:text-slate-400">
                  Remaining Time:
                </span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">
                  {formatTimer(remainingSeconds)}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowSubmitModal(false)}
                className="rounded-xl border border-slate-300 dark:border-slate-700 px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100"
              >
                Return to Questions
              </button>
              <button
                type="button"
                onClick={() => executeFinalSubmit(session, 'manual_submit')}
                className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 px-5 py-2 text-xs font-bold text-white shadow-sm"
              >
                <CheckCircle2 className="h-4 w-4" />
                <span>Submit & View Results</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
