import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Search,
  Filter,
  RotateCcw,
  FileText,
  CheckCircle2,
  Clock,
  FolderOpen,
} from 'lucide-react';
import { STUDY_RESOURCES_DATASET } from '../data/resourcesData';
import { QUESTIONS_DATASET } from '../data/questionsData';
import {
  ClassLevel,
  ExamType,
  ResourceCategory,
  ResourceFilterState,
  StudyResource,
  SubjectType,
} from '../core/types';
import {
  filterResources,
  getAdaptiveFilterMetadata,
} from '../core/searchEngine';
import {
  getBookmarkedResourceIds,
  toggleBookmarkedResource,
} from '../core/storage';
import { ResourceCard } from '../components/ResourceCard';
import { PdfViewerModal } from '../components/PdfViewerModal';

export const LibraryPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [selectedResource, setSelectedResource] =
    useState<StudyResource | null>(null);

  useEffect(() => {
    setBookmarkedIds(getBookmarkedResourceIds());
  }, []);

  // Read filters from URL searchParams so navigating back from PDF viewer or external view keeps filters intact
  const filters: ResourceFilterState = useMemo(() => {
    const examParam = searchParams.get('exam') as ExamType | null;
    const classParam = searchParams.get('class') as ClassLevel | null;
    const subjectParam = searchParams.get('subject') as SubjectType | null;
    const chapterParam = searchParams.get('chapter');
    const yearParam = searchParams.get('year');
    const sessionParam = searchParams.get('session');
    const categoryParam = searchParams.get('category') as ResourceCategory | null;
    const pdfOnlyParam = searchParams.get('pdfOnly') === 'true';
    const qParam = searchParams.get('q') || '';

    return {
      searchQuery: qParam,
      exam:
        examParam === 'JEE Main' || examParam === 'CBSE Board'
          ? examParam
          : 'ALL',
      classLevel:
        classParam === 'Class 11' ||
        classParam === 'Class 12' ||
        classParam === 'Class 11 & 12'
          ? classParam
          : 'ALL',
      subject:
        subjectParam === 'Physics' ||
        subjectParam === 'Chemistry' ||
        subjectParam === 'Mathematics'
          ? subjectParam
          : 'ALL',
      chapter: chapterParam || 'ALL',
      year: yearParam && !Number.isNaN(Number(yearParam)) ? Number(yearParam) : 'ALL',
      sessionOrSet: sessionParam || 'ALL',
      category: categoryParam || 'ALL',
      onlyPdfAvailable: pdfOnlyParam,
    };
  }, [searchParams]);

  const updateFilter = (patch: Partial<ResourceFilterState>) => {
    const next: ResourceFilterState = { ...filters, ...patch };

    // If exam changed, reset exam-specific sub-filters if they no longer apply
    if (patch.exam !== undefined && patch.exam !== filters.exam) {
      next.sessionOrSet = 'ALL';
      if (patch.exam === 'JEE Main' && next.category === 'Board PYQ') {
        next.category = 'ALL';
      }
      if (
        patch.exam === 'CBSE Board' &&
        (next.category === 'JEE Main PYQ' || next.category === 'Practice Paper')
      ) {
        next.category = 'ALL';
      }
    }

    if (patch.subject !== undefined && patch.subject !== filters.subject) {
      next.chapter = 'ALL';
    }

    const params = new URLSearchParams();
    if (next.searchQuery.trim()) params.set('q', next.searchQuery.trim());
    if (next.exam !== 'ALL') params.set('exam', next.exam);
    if (next.classLevel !== 'ALL') params.set('class', next.classLevel);
    if (next.subject !== 'ALL') params.set('subject', next.subject);
    if (next.chapter !== 'ALL') params.set('chapter', next.chapter);
    if (next.year !== 'ALL') params.set('year', String(next.year));
    if (next.sessionOrSet !== 'ALL') params.set('session', next.sessionOrSet);
    if (next.category !== 'ALL') params.set('category', next.category);
    if (next.onlyPdfAvailable) params.set('pdfOnly', 'true');

    setSearchParams(params, { replace: true });
  };

  const resetAllFilters = () => {
    setSearchParams(new URLSearchParams(), { replace: true });
  };

  const adaptiveMeta = useMemo(
    () =>
      getAdaptiveFilterMetadata(
        {
          exam: filters.exam,
          subject: filters.subject,
          classLevel: filters.classLevel,
        },
        STUDY_RESOURCES_DATASET
      ),
    [filters.exam, filters.subject, filters.classLevel]
  );

  const filteredResources = useMemo(
    () => filterResources(STUDY_RESOURCES_DATASET, filters),
    [filters]
  );

  const pdfReadyCount = useMemo(
    () => filteredResources.filter((r) => r.pdfAvailable).length,
    [filteredResources]
  );

  const handleToggleBookmark = (id: string) => {
    setBookmarkedIds(toggleBookmarkedResource(id));
  };

  const linkedQuestionsForModal = selectedResource
    ? QUESTIONS_DATASET.filter((q) =>
        selectedResource.linkedQuestionIds.includes(q.id)
      )
    : [];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-brand-600 dark:text-brand-400 mb-1">
            <FileText className="h-3.5 w-3.5" />
            <span>Study-Material Library</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Question Papers, Sample Sets & Worked Solutions
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-2xl">
            Browse verified CBSE Class 11 & 12 and JEE Main study resources.
            Filters adapt dynamically to your chosen examination.
          </p>
        </div>

        {/* Summary Counts */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 px-3 py-1.5 font-semibold text-emerald-800 dark:text-emerald-300">
            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
            <span>{pdfReadyCount} Ready PDFs</span>
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 px-3 py-1.5 font-medium text-slate-700 dark:text-slate-300">
            <span>{filteredResources.length} Total Matching</span>
          </span>
        </div>
      </div>

      {/* Adaptive Filter Panel */}
      <section
        aria-label="Filter study materials"
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-5 shadow-sm space-y-4"
      >
        {/* Search Input + Exam Tabs */}
        <div className="flex flex-col lg:flex-row gap-3 justify-between">
          <div className="relative flex-1">
            <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={filters.searchQuery}
              onChange={(e) => updateFilter({ searchQuery: e.target.value })}
              placeholder="Search by title, subject, chapter (e.g., Electrostatics, Integrals, VSEPR), or year..."
              aria-label="Search study library"
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 pl-10 pr-4 py-2 text-xs sm:text-sm text-slate-900 dark:text-white focus:border-brand-500 focus:bg-white dark:focus:bg-slate-900 focus:outline-none"
            />
          </div>

          {/* Primary Examination Selector */}
          <div
            role="group"
            aria-label="Filter by examination"
            className="inline-flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 shrink-0"
          >
            {(['ALL', 'JEE Main', 'CBSE Board'] as const).map((examOpt) => (
              <button
                key={examOpt}
                type="button"
                onClick={() => updateFilter({ exam: examOpt })}
                className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all ${
                  filters.exam === examOpt
                    ? 'bg-slate-900 dark:bg-brand-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                }`}
              >
                {examOpt === 'ALL' ? 'All Exams' : examOpt}
              </button>
            ))}
          </div>
        </div>

        {/* Adaptive Dropdown Filters Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 pt-1">
          {/* Class Filter */}
          <div>
            <label
              htmlFor="filter-class"
              className="block text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1"
            >
              Class Level
            </label>
            <select
              id="filter-class"
              value={filters.classLevel}
              onChange={(e) =>
                updateFilter({
                  classLevel: e.target.value as ClassLevel | 'ALL',
                })
              }
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-2 text-xs text-slate-800 dark:text-slate-200 focus:border-brand-500 focus:outline-none"
            >
              <option value="ALL">All Classes (11 & 12)</option>
              <option value="Class 11">Class 11</option>
              <option value="Class 12">Class 12</option>
            </select>
          </div>

          {/* Subject Filter */}
          <div>
            <label
              htmlFor="filter-subject"
              className="block text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1"
            >
              Subject
            </label>
            <select
              id="filter-subject"
              value={filters.subject}
              onChange={(e) =>
                updateFilter({
                  subject: e.target.value as SubjectType | 'ALL',
                })
              }
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-2 text-xs text-slate-800 dark:text-slate-200 focus:border-brand-500 focus:outline-none"
            >
              <option value="ALL">All Subjects (PCM)</option>
              <option value="Physics">Physics</option>
              <option value="Chemistry">Chemistry</option>
              <option value="Mathematics">Mathematics</option>
            </select>
          </div>

          {/* Adaptive Resource Category Filter */}
          <div>
            <label
              htmlFor="filter-category"
              className="block text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1"
            >
              Resource Type
            </label>
            <select
              id="filter-category"
              value={filters.category}
              onChange={(e) =>
                updateFilter({
                  category: e.target.value as ResourceCategory | 'ALL',
                })
              }
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-2 text-xs text-slate-800 dark:text-slate-200 focus:border-brand-500 focus:outline-none"
            >
              <option value="ALL">All Resource Types</option>
              {adaptiveMeta.availableCategories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Adaptive Chapter Filter */}
          <div>
            <label
              htmlFor="filter-chapter"
              className="block text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1"
            >
              Chapter / Topic
            </label>
            <select
              id="filter-chapter"
              value={filters.chapter}
              onChange={(e) => updateFilter({ chapter: e.target.value })}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-2 text-xs text-slate-800 dark:text-slate-200 focus:border-brand-500 focus:outline-none"
            >
              <option value="ALL">All Chapters</option>
              {adaptiveMeta.availableChapters.map((chap) => (
                <option key={chap} value={chap}>
                  {chap}
                </option>
              ))}
            </select>
          </div>

          {/* Year Filter */}
          <div>
            <label
              htmlFor="filter-year"
              className="block text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1"
            >
              Examination Year
            </label>
            <select
              id="filter-year"
              value={filters.year}
              onChange={(e) =>
                updateFilter({
                  year:
                    e.target.value === 'ALL' ? 'ALL' : Number(e.target.value),
                })
              }
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-2 text-xs text-slate-800 dark:text-slate-200 focus:border-brand-500 focus:outline-none"
            >
              <option value="ALL">All Years</option>
              {adaptiveMeta.availableYears.map((yr) => (
                <option key={yr} value={yr}>
                  {yr}
                </option>
              ))}
            </select>
          </div>

          {/* Adaptive Session / Shift (JEE) or Paper Set (CBSE) Filter */}
          <div>
            <label
              htmlFor="filter-session"
              className="block text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1"
            >
              {adaptiveMeta.sessionFilterLabel}
            </label>
            <select
              id="filter-session"
              value={filters.sessionOrSet}
              onChange={(e) => updateFilter({ sessionOrSet: e.target.value })}
              className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-2 text-xs text-slate-800 dark:text-slate-200 focus:border-brand-500 focus:outline-none"
            >
              <option value="ALL">All {adaptiveMeta.sessionFilterLabel}s</option>
              {adaptiveMeta.availableSessionsOrSets.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Bottom Filter Controls: Ready PDF Toggle & Reset */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
          <label className="inline-flex items-center gap-2 cursor-pointer select-none text-slate-700 dark:text-slate-300 font-medium">
            <input
              type="checkbox"
              checked={filters.onlyPdfAvailable}
              onChange={(e) =>
                updateFilter({ onlyPdfAvailable: e.target.checked })
              }
              className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500"
            />
            <span>Show only resources with downloadable PDF files ready</span>
          </label>

          <div className="flex items-center gap-3">
            <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <Filter className="h-3.5 w-3.5" />
              <span>
                Adaptive Mode:{' '}
                <strong>
                  {filters.exam === 'ALL'
                    ? 'Combined (JEE Main + CBSE Board)'
                    : `${filters.exam} Specific Filters`}
                </strong>
              </span>
            </span>
            <button
              type="button"
              onClick={resetAllFilters}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 dark:border-slate-700 px-2.5 py-1 font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Reset Filters</span>
            </button>
          </div>
        </div>
      </section>

      {/* Resource Cards Grid or Honest Empty State */}
      {filteredResources.length > 0 ? (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
          {filteredResources.map((resource) => (
            <ResourceCard
              key={resource.id}
              resource={resource}
              isBookmarked={bookmarkedIds.includes(resource.id)}
              onToggleBookmark={handleToggleBookmark}
              onOpenViewer={(res) => setSelectedResource(res)}
            />
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-10 text-center space-y-4">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500">
            <FolderOpen className="h-6 w-6" />
          </div>
          <div className="max-w-md mx-auto space-y-1.5">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              No Study Resources Match Your Exact Filter Combination
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              This specific combination of examination, chapter, or year has not
              yet been added to the verified repository. Try clearing one of the
              filters or searching by broader topic name.
            </p>
          </div>
          <button
            type="button"
            onClick={resetAllFilters}
            className="inline-flex items-center gap-1.5 rounded-xl bg-brand-600 px-4 py-2 text-xs font-bold text-white hover:bg-brand-700 transition-colors"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset All Filters</span>
          </button>
        </div>
      )}

      {/* Transparency Note on Pending Archival Items */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100/70 dark:bg-slate-900/60 p-4 flex items-start gap-3 text-xs text-slate-600 dark:text-slate-400">
        <Clock className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-slate-800 dark:text-slate-200">
            Archival Honesty Policy:
          </span>{' '}
          Resources labeled <strong>PDF Ready</strong> download genuine 2-page
          PDF documents generated from verified syllabus sets. Historical board
          and JEE shift entries whose external scanned PDFs have not yet been
          cleared for redistribution are explicitly marked{' '}
          <strong>PDF Pending Verification</strong> and provide direct online
          question practice instead of broken links.
        </div>
      </div>

      {/* PDF & DOCUMENT VIEWER MODAL */}
      <PdfViewerModal
        resource={selectedResource}
        linkedQuestions={linkedQuestionsForModal}
        onClose={() => setSelectedResource(null)}
      />
    </div>
  );
};
