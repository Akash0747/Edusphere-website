import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  BarChart2,
  Trash2,
  HardDrive,
  Bookmark,
  CheckCircle2,
  ArrowRight,
  AlertTriangle,
  Play,
  FileText,
} from 'lucide-react';
import {
  getAttemptHistory,
  getBookmarkedResourceIds,
  getBookmarkedQuestionIds,
  getPracticedQuestions,
  clearAllLocalEduSphereData,
  toggleBookmarkedResource,
  toggleBookmarkedQuestion,
} from '../core/storage';
import { STUDY_RESOURCES_DATASET } from '../data/resourcesData';
import { QUESTIONS_DATASET } from '../data/questionsData';
import { TestAttemptResult } from '../core/types';

export const ProgressPage: React.FC = () => {
  const [attempts, setAttempts] = useState<TestAttemptResult[]>([]);
  const [bookmarkedResIds, setBookmarkedResIds] = useState<string[]>([]);
  const [bookmarkedQIds, setBookmarkedQIds] = useState<string[]>([]);
  const [practicedCount, setPracticedCount] = useState<number>(0);
  const [confirmClearOpen, setConfirmClearOpen] = useState<boolean>(false);

  const loadLocalData = () => {
    setAttempts(getAttemptHistory());
    setBookmarkedResIds(getBookmarkedResourceIds());
    setBookmarkedQIds(getBookmarkedQuestionIds());
    setPracticedCount(Object.keys(getPracticedQuestions()).length);
  };

  useEffect(() => {
    loadLocalData();
  }, []);

  const handleClearAll = () => {
    clearAllLocalEduSphereData();
    setConfirmClearOpen(false);
    loadLocalData();
  };

  const bookmarkedResources = STUDY_RESOURCES_DATASET.filter((r) =>
    bookmarkedResIds.includes(r.id)
  );
  const bookmarkedQuestions = QUESTIONS_DATASET.filter((q) =>
    bookmarkedQIds.includes(q.id)
  );

  // Aggregate subject performance across all completed attempts
  const subjectTotals: Record<
    string,
    { attempted: number; correct: number; score: number; maxScore: number }
  > = {
    Physics: { attempted: 0, correct: 0, score: 0, maxScore: 0 },
    Chemistry: { attempted: 0, correct: 0, score: 0, maxScore: 0 },
    Mathematics: { attempted: 0, correct: 0, score: 0, maxScore: 0 },
  };

  attempts.forEach((att) => {
    att.subjectBreakdown.forEach((sub) => {
      const entry = subjectTotals[sub.subject];
      if (entry) {
        entry.attempted += sub.attemptedCount;
        entry.correct += sub.correctCount;
        entry.score += sub.score;
        entry.maxScore += sub.maxScore;
      }
    });
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-brand-600 dark:text-brand-400 mb-1">
            <BarChart2 className="h-3.5 w-3.5" />
            <span>Progress Without Accounts</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Local Study History, Analytics & Bookmarks
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-2xl">
            Review your completed mock tests, cumulative subject accuracy, and
            bookmarked resources stored locally on this device.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setConfirmClearOpen(true)}
          disabled={
            attempts.length === 0 &&
            bookmarkedResIds.length === 0 &&
            bookmarkedQIds.length === 0 &&
            practicedCount === 0
          }
          className={`inline-flex items-center gap-1.5 rounded-xl border px-4 py-2 text-xs font-bold transition-colors ${
            attempts.length > 0 ||
            bookmarkedResIds.length > 0 ||
            bookmarkedQIds.length > 0 ||
            practicedCount > 0
              ? 'border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 hover:bg-rose-100'
              : 'border-slate-200 dark:border-slate-800 text-slate-400 cursor-not-allowed'
          }`}
        >
          <Trash2 className="h-3.5 w-3.5" />
          <span>Clear Local History</span>
        </button>
      </div>

      {/* Explicit Device-Local Storage Disclosure Banner */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-5 flex items-start gap-3.5 shadow-sm">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-50 dark:bg-brand-950/60 text-brand-600">
          <HardDrive className="h-5 w-5" />
        </div>
        <div className="space-y-1 text-xs">
          <h2 className="font-bold text-slate-900 dark:text-white">
            How Local Progress Storage Works (No Login Required)
          </h2>
          <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
            EduSphere saves your test attempts, active timers, and bookmarks
            directly in your browser’s <code>localStorage</code> on this device.
            Because no user account or cloud profile is required,{' '}
            <strong>
              your local history does not automatically synchronize across
              separate phones or computers
            </strong>
            . Never store sensitive personal information on shared public
            computers; use the Clear Local History button above when finished on
            a shared device.
          </p>
        </div>
      </div>

      {/* Summary Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-semibold text-slate-500">
            Completed Mock Tests
          </div>
          <div className="mt-1 text-2xl font-extrabold text-slate-900 dark:text-white">
            {attempts.length}
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            Saved on this browser
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-semibold text-slate-500">
            Questions Practiced (Bank)
          </div>
          <div className="mt-1 text-2xl font-extrabold text-brand-600 dark:text-brand-400">
            {practicedCount} / {QUESTIONS_DATASET.length}
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            Untimed chapter practice
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-semibold text-slate-500">
            Bookmarked Papers
          </div>
          <div className="mt-1 text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">
            {bookmarkedResources.length}
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            Saved study resources
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-semibold text-slate-500">
            Bookmarked Questions
          </div>
          <div className="mt-1 text-2xl font-extrabold text-amber-600 dark:text-amber-400">
            {bookmarkedQuestions.length}
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            Flagged for quick revision
          </p>
        </div>
      </div>

      {/* Subject Performance Across Completed Tests */}
      {attempts.length > 0 && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm space-y-4">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            Cumulative Subject Accuracy (Across {attempts.length} Test
            Attempt(s))
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {(['Physics', 'Chemistry', 'Mathematics'] as const).map((sub) => {
              const data = subjectTotals[sub];
              const acc =
                data.attempted > 0
                  ? Math.round((data.correct / data.attempted) * 100)
                  : 0;
              return (
                <div
                  key={sub}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 p-4 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-slate-900 dark:text-white">
                      {sub}
                    </span>
                    <span className="text-xs font-bold text-brand-600 dark:text-brand-400">
                      {acc}% Accuracy
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                    <div
                      className="h-full bg-brand-600 rounded-full"
                      style={{ width: `${Math.min(100, acc)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-500">
                    <span>
                      Correct: {data.correct} / {data.attempted} attempted
                    </span>
                    <span>
                      Marks: {data.score} / {data.maxScore}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Completed Mock Test Attempts List */}
      <section className="space-y-4">
        <h2 className="text-lg font-bold text-slate-900 dark:text-white">
          Completed Mock Test Attempts
        </h2>

        {attempts.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center space-y-3">
            <CheckCircle2 className="h-8 w-8 text-slate-400 mx-auto" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              No Mock Tests Completed on This Device Yet
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 max-w-md mx-auto">
              Start any chapter-wise or full-length simulation to see your
              score, accuracy, and mistake analysis saved here automatically.
            </p>
            <Link
              to="/tests"
              className="inline-flex items-center gap-1.5 rounded-xl bg-brand-600 px-4 py-2 text-xs font-bold text-white hover:bg-brand-700"
            >
              <Play className="h-3.5 w-3.5" />
              <span>Explore Mock Tests</span>
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {attempts.map((att) => (
              <div
                key={att.attemptId}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="rounded bg-slate-900 dark:bg-brand-600 px-2 py-0.5 font-bold text-white">
                      {att.exam}
                    </span>
                    <span className="text-slate-500">
                      {new Date(att.submittedAtIso).toLocaleString()}
                    </span>
                  </div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                    {att.testTitle}
                  </h3>
                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 dark:text-slate-400">
                    <span>
                      Score:{' '}
                      <strong className="text-slate-900 dark:text-white">
                        {att.totalScore}/{att.maxScore} ({att.percentage}%)
                      </strong>
                    </span>
                    <span>•</span>
                    <span>
                      Accuracy:{' '}
                      <strong className="text-emerald-600">
                        {att.accuracy}%
                      </strong>
                    </span>
                    <span>•</span>
                    <span>
                      {att.correctCount}C / {att.incorrectCount}W /{' '}
                      {att.unansweredCount}S
                    </span>
                  </div>
                </div>

                <Link
                  to={`/test/${att.testId}/result/${att.attemptId}`}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-brand-50 dark:bg-brand-950/70 border border-brand-200 dark:border-brand-800 px-4 py-2 text-xs font-bold text-brand-700 dark:text-brand-300 hover:bg-brand-100 shrink-0"
                >
                  <span>Full Analysis & Solutions</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Bookmarked Resources & Questions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bookmarked Resources */}
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="h-4 w-4 text-brand-600" />
              <span>Bookmarked Study Papers ({bookmarkedResources.length})</span>
            </h2>
            <Link
              to="/library"
              className="text-xs font-semibold text-brand-600 hover:underline"
            >
              Browse Library →
            </Link>
          </div>

          {bookmarkedResources.length === 0 ? (
            <p className="text-xs text-slate-500 py-4">
              Click the bookmark icon on any paper card in the Resource Library
              to pin it here for quick access.
            </p>
          ) : (
            <div className="space-y-2">
              {bookmarkedResources.map((res) => (
                <div
                  key={res.id}
                  className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 dark:border-slate-800 p-3 text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-bold text-slate-900 dark:text-white truncate">
                      {res.title}
                    </div>
                    <div className="text-slate-500">
                      {res.exam} • {res.subject} ({res.year})
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Link
                      to={`/library?q=${encodeURIComponent(res.title)}`}
                      className="rounded-lg bg-brand-600 px-2.5 py-1 font-semibold text-white"
                    >
                      Open
                    </Link>
                    <button
                      type="button"
                      onClick={() =>
                        setBookmarkedResIds(toggleBookmarkedResource(res.id))
                      }
                      className="text-slate-400 hover:text-rose-600"
                      title="Remove bookmark"
                    >
                      <Bookmark className="h-4 w-4 fill-current" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Bookmarked Questions */}
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Bookmark className="h-4 w-4 text-amber-500" />
              <span>Bookmarked Questions ({bookmarkedQuestions.length})</span>
            </h2>
            <Link
              to="/practice"
              className="text-xs font-semibold text-brand-600 hover:underline"
            >
              Question Bank →
            </Link>
          </div>

          {bookmarkedQuestions.length === 0 ? (
            <p className="text-xs text-slate-500 py-4">
              Bookmark challenging questions in the Question Bank to revisit
              their derivations before your exam.
            </p>
          ) : (
            <div className="space-y-2">
              {bookmarkedQuestions.map((q) => (
                <div
                  key={q.id}
                  className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 dark:border-slate-800 p-3 text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-bold text-slate-900 dark:text-white truncate">
                      [{q.id}] {q.chapter} — {q.topic}
                    </div>
                    <div className="text-slate-500 truncate">
                      {q.questionText}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Link
                      to={`/practice?q=${encodeURIComponent(q.id)}`}
                      className="rounded-lg bg-brand-600 px-2.5 py-1 font-semibold text-white"
                    >
                      Review
                    </Link>
                    <button
                      type="button"
                      onClick={() =>
                        setBookmarkedQIds(toggleBookmarkedQuestion(q.id))
                      }
                      className="text-slate-400 hover:text-rose-600"
                      title="Remove bookmark"
                    >
                      <Bookmark className="h-4 w-4 fill-current" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Clear Confirmation Modal */}
      {confirmClearOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-6 w-6 text-rose-600 shrink-0" />
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  Clear All Local Study Data?
                </h2>
                <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  This will permanently remove all completed test attempts,
                  in-progress test sessions, and bookmarks stored in this
                  browser.
                </p>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmClearOpen(false)}
                className="rounded-xl border border-slate-300 dark:border-slate-700 px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleClearAll}
                className="rounded-xl bg-rose-600 hover:bg-rose-700 px-4 py-2 text-xs font-bold text-white"
              >
                Yes, Clear Local History
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
