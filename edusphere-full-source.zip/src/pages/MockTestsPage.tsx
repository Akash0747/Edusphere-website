import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  CheckSquare,
  Play,
  Clock,
  Award,
  Layers,
  RotateCcw,
  ShieldAlert,
  BarChart2,
} from 'lucide-react';
import { MOCK_TESTS_DATASET } from '../data/mockTestsData';
import { ExamType, ActiveTestSession, TestAttemptResult } from '../core/types';
import {
  getActiveTestSessions,
  getAttemptHistory,
  removeActiveTestSession,
  computeRemainingSeconds,
} from '../core/storage';
import { VerificationBadge } from '../components/VerificationBadge';

export const MockTestsPage: React.FC = () => {
  const [examFilter, setExamFilter] = useState<ExamType | 'ALL'>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<
    'ALL' | 'full_simulation' | 'chapter_test'
  >('ALL');
  const [activeSessions, setActiveSessions] = useState<
    Record<string, ActiveTestSession>
  >({});
  const [history, setHistory] = useState<TestAttemptResult[]>([]);

  const refreshLocalState = () => {
    setActiveSessions(getActiveTestSessions());
    setHistory(getAttemptHistory());
  };

  useEffect(() => {
    refreshLocalState();
  }, []);

  const handleDiscardSession = (testId: string) => {
    removeActiveTestSession(testId);
    refreshLocalState();
  };

  const filteredTests = MOCK_TESTS_DATASET.filter((test) => {
    if (examFilter !== 'ALL' && test.exam !== examFilter) return false;
    if (categoryFilter !== 'ALL' && test.category !== categoryFilter)
      return false;
    return true;
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-brand-600 dark:text-brand-400 mb-1">
            <CheckSquare className="h-3.5 w-3.5" />
            <span>Interactive Mock-Test Engine</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Chapter-Wise Tests & Full-Length Simulations
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-2xl">
            Practice in a distraction-free exam interface with live countdown
            timer, question palette, mark-for-review states, configurable
            marking rules, and evidence-based mistake analysis.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1">
            {(['ALL', 'JEE Main', 'CBSE Board'] as const).map((ex) => (
              <button
                key={ex}
                type="button"
                onClick={() => setExamFilter(ex)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                  examFilter === ex
                    ? 'bg-slate-900 dark:bg-brand-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                }`}
              >
                {ex === 'ALL' ? 'All Exams' : ex}
              </button>
            ))}
          </div>

          <div className="inline-flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1">
            {[
              { id: 'ALL', label: 'All Formats' },
              { id: 'full_simulation', label: 'Full Simulations' },
              { id: 'chapter_test', label: 'Chapter Tests' },
            ].map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() =>
                  setCategoryFilter(
                    cat.id as 'ALL' | 'full_simulation' | 'chapter_test'
                  )
                }
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                  categoryFilter === cat.id
                    ? 'bg-white dark:bg-slate-900 text-brand-700 dark:text-brand-300 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Honest Practice Environment Notice */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-600 dark:text-slate-400">
        <div className="flex items-start gap-2.5">
          <ShieldAlert className="h-4 w-4 text-brand-600 shrink-0 mt-0.5" />
          <span>
            <strong>Practice Simulation Notice:</strong> These tests replicate
            official marking rules (<strong>+4 / −1</strong> for JEE Main and{' '}
            <strong>+1 / 0</strong> for CBSE Section A) and auto-save your
            in-progress timer locally in your browser. They are self-paced
            practice tools, not proctored official examinations.
          </span>
        </div>
        {history.length > 0 && (
          <Link
            to="/progress"
            className="inline-flex items-center gap-1.5 font-semibold text-brand-600 dark:text-brand-400 shrink-0 hover:underline"
          >
            <BarChart2 className="h-3.5 w-3.5" />
            <span>View {history.length} Completed Attempt(s)</span>
          </Link>
        )}
      </div>

      {/* Mock Test Cards Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {filteredTests.map((test) => {
          const activeSession = activeSessions[test.id];
          const hasUnfinished = activeSession && !activeSession.isSubmitted;
          const remainingSeconds = hasUnfinished
            ? computeRemainingSeconds(activeSession)
            : 0;
          const previousAttempts = history.filter((h) => h.testId === test.id);
          const bestAttempt =
            previousAttempts.length > 0
              ? previousAttempts.reduce((best, curr) =>
                  curr.totalScore > best.totalScore ? curr : best
                )
              : null;
          const maxMarks =
            test.questionIds.length * test.markingScheme.correctMarks;

          return (
            <article
              key={test.id}
              className="flex flex-col justify-between rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm hover:border-brand-300 dark:hover:border-brand-700 transition-all"
            >
              <div className="space-y-4">
                {/* Badges */}
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-md bg-slate-900 dark:bg-brand-600 px-2.5 py-1 font-bold text-white">
                      {test.exam}
                    </span>
                    <span
                      className={`rounded-md px-2.5 py-1 font-semibold ${
                        test.category === 'full_simulation'
                          ? 'bg-indigo-50 text-indigo-800 border border-indigo-200 dark:bg-indigo-950/60 dark:text-indigo-300 dark:border-indigo-800'
                          : 'bg-emerald-50 text-emerald-800 border border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                      }`}
                    >
                      {test.category === 'full_simulation'
                        ? 'Full-Length Simulation'
                        : 'Chapter-Wise Test'}
                    </span>
                    <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2.5 py-1 font-medium text-slate-700 dark:text-slate-300">
                      {test.classLevel}
                    </span>
                  </div>

                  <span className="inline-flex items-center gap-1 font-semibold text-slate-600 dark:text-slate-300">
                    <Clock className="h-3.5 w-3.5 text-brand-600" />
                    <span>{test.durationMinutes} Mins</span>
                  </span>
                </div>

                {/* Title & Subtitle */}
                <div>
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                    {test.title}
                  </h2>
                  <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                    {test.subtitle}
                  </p>
                </div>

                {/* Marking Scheme & Coverage Box */}
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/70 p-3.5 space-y-2 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <Award className="h-3.5 w-3.5 text-brand-600" />
                      <span>{test.markingScheme.schemeName}</span>
                    </span>
                    <span className="font-semibold text-slate-700 dark:text-slate-300">
                      {test.questionIds.length} Questions • {maxMarks} Max Marks
                    </span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400">
                    {test.markingScheme.description}
                  </p>
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    <Layers className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    <span className="text-slate-500 font-medium">
                      Chapters:
                    </span>
                    {test.chaptersCovered.slice(0, 5).map((ch) => (
                      <span
                        key={ch}
                        className="rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 px-1.5 py-0.5 text-[11px] text-slate-700 dark:text-slate-300"
                      >
                        {ch}
                      </span>
                    ))}
                    {test.chaptersCovered.length > 5 && (
                      <span className="text-[11px] text-slate-500">
                        +{test.chaptersCovered.length - 5} more
                      </span>
                    )}
                  </div>
                </div>

                <VerificationBadge verification={test.verification} />
              </div>

              {/* Action Footer */}
              <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  {bestAttempt ? (
                    <div className="flex items-center gap-2">
                      <span>
                        Best Score:{' '}
                        <strong className="text-emerald-600 dark:text-emerald-400">
                          {bestAttempt.totalScore}/{bestAttempt.maxScore} (
                          {bestAttempt.percentage}%)
                        </strong>
                      </span>
                      <span>•</span>
                      <Link
                        to={`/test/${test.id}/result/${bestAttempt.attemptId}`}
                        className="font-semibold text-brand-600 dark:text-brand-400 hover:underline"
                      >
                        Review Report
                      </Link>
                    </div>
                  ) : (
                    <span>Not yet attempted on this device</span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {hasUnfinished ? (
                    <>
                      <button
                        type="button"
                        onClick={() => handleDiscardSession(test.id)}
                        className="inline-flex items-center gap-1 rounded-xl border border-slate-300 dark:border-slate-700 px-3 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                        title="Discard saved session and start fresh"
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                        <span>Reset</span>
                      </button>
                      <Link
                        to={`/test/${test.id}`}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-amber-600 px-4 py-2 text-xs font-bold text-white hover:bg-amber-700 transition-colors shadow-sm"
                      >
                        <Play className="h-3.5 w-3.5" />
                        <span>
                          Resume ({Math.ceil(remainingSeconds / 60)}m left)
                        </span>
                      </Link>
                    </>
                  ) : (
                    <Link
                      to={`/test/${test.id}`}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-brand-600 px-5 py-2.5 text-xs font-bold text-white hover:bg-brand-700 transition-colors shadow-sm"
                    >
                      <Play className="h-3.5 w-3.5" />
                      <span>
                        {previousAttempts.length > 0
                          ? 'Retake Test'
                          : 'Start Mock Test'}
                      </span>
                    </Link>
                  )}
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
};
