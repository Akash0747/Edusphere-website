import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Search,
  ArrowRight,
  FileText,
  CheckSquare,
  BookOpen,
  Award,
  Play,
  ShieldCheck,
  Clock,
  HardDrive,
  Sparkles,
} from 'lucide-react';
import { STUDY_RESOURCES_DATASET } from '../data/resourcesData';
import { MOCK_TESTS_DATASET } from '../data/mockTestsData';
import { QUESTIONS_DATASET } from '../data/questionsData';
import { StudyResource } from '../core/types';
import {
  getActiveTestSessions,
  getBookmarkedResourceIds,
  toggleBookmarkedResource,
  computeRemainingSeconds,
} from '../core/storage';
import { ResourceCard } from '../components/ResourceCard';
import { PdfViewerModal } from '../components/PdfViewerModal';

export const HomePage: React.FC = () => {
  const [searchInput, setSearchInput] = useState('');
  const [selectedResource, setSelectedResource] =
    useState<StudyResource | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [activeSessionsList, setActiveSessionsList] = useState<
    Array<{ testId: string; remainingSec: number }>
  >([]);
  const navigate = useNavigate();

  useEffect(() => {
    setBookmarkedIds(getBookmarkedResourceIds());
    const sessions = getActiveTestSessions();
    const list = Object.values(sessions)
      .filter((s) => !s.isSubmitted)
      .map((s) => ({
        testId: s.testId,
        remainingSec: computeRemainingSeconds(s),
      }));
    setActiveSessionsList(list);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = searchInput.trim();
    if (trimmed) {
      navigate(`/library?q=${encodeURIComponent(trimmed)}`);
    } else {
      navigate('/library');
    }
  };

  const handleToggleBookmark = (id: string) => {
    const updated = toggleBookmarkedResource(id);
    setBookmarkedIds(updated);
  };

  const featuredResources = STUDY_RESOURCES_DATASET.filter(
    (r) => r.pdfAvailable
  ).slice(0, 4);

  const featuredTests = MOCK_TESTS_DATASET.slice(0, 3);

  const linkedQuestionsForModal = selectedResource
    ? QUESTIONS_DATASET.filter((q) =>
        selectedResource.linkedQuestionIds.includes(q.id)
      )
    : [];

  return (
    <div className="space-y-12 pb-8">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden bg-slate-900 text-white border-b border-slate-800">
        {/* Subtle controlled academic grid pattern */}
        <div
          className="absolute inset-0 opacity-15 pointer-events-none"
          style={{
            backgroundImage:
              'radial-gradient(circle at 20% 25%, #6366f1 0%, transparent 45%), radial-gradient(circle at 80% 75%, #3b82f6 0%, transparent 45%)',
          }}
        />
        <div className="relative mx-auto max-w-7xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
          <div className="mx-auto max-w-3xl text-center space-y-6">
            <div className="inline-flex items-center gap-2 rounded-full border border-indigo-400/30 bg-indigo-500/10 px-3.5 py-1 text-xs font-semibold text-indigo-300">
              <Sparkles className="h-3.5 w-3.5 text-indigo-400" />
              <span>
                Class 11 & 12 • CBSE Board • JEE Main — Open-Access Study
                Ecosystem
              </span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
              Prepare Smarter.{' '}
              <span className="text-indigo-400">Achieve More.</span>
            </h1>

            <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl mx-auto">
              Access verified practice papers, downloadable PDFs, worked
              solutions, chapter-wise question banks with technical diagrams,
              and timed mock tests—completely free with zero mandatory
              registration.
            </p>

            {/* Prominent Search Bar */}
            <form
              onSubmit={handleSearchSubmit}
              className="mx-auto max-w-2xl pt-2"
              role="search"
              aria-label="Search study materials"
            >
              <div className="flex flex-col sm:flex-row gap-2 rounded-2xl bg-white/10 p-2 backdrop-blur-md border border-white/15 focus-within:border-indigo-400 transition-colors">
                <div className="relative flex-1 flex items-center">
                  <Search className="h-5 w-5 text-slate-300 ml-3 shrink-0" />
                  <input
                    type="search"
                    value={searchInput}
                    onChange={(e) => setSearchInput(e.target.value)}
                    placeholder="Search subjects, chapters (e.g., Electrostatics, Integrals), exams, or papers..."
                    aria-label="Search subjects, chapters, exams, and papers"
                    className="w-full bg-transparent px-3 py-2.5 text-sm text-white placeholder-slate-300 focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-brand-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-brand-500 transition-colors shrink-0 shadow-sm"
                >
                  <span>Search Library</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>

              {/* Quick Filter Suggestions */}
              <div className="mt-3 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-300">
                <span className="text-slate-400">Popular searches:</span>
                {[
                  'Electrostatics',
                  'Integrals',
                  'Electrochemistry',
                  'Ray Optics',
                  'Sample Paper',
                  'Class 11',
                ].map((term) => (
                  <button
                    key={term}
                    type="button"
                    onClick={() =>
                      navigate(`/library?q=${encodeURIComponent(term)}`)
                    }
                    className="rounded-full bg-slate-800/90 hover:bg-slate-700 border border-slate-700 px-2.5 py-0.5 text-slate-200 transition-colors"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </form>

            {/* Primary CTA Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <Link
                to="/library"
                className="inline-flex items-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-bold text-slate-900 hover:bg-slate-100 transition-colors shadow-sm"
              >
                <FileText className="h-4 w-4 text-brand-600" />
                <span>Explore PYQs & Papers</span>
              </Link>
              <Link
                to="/tests"
                className="inline-flex items-center gap-2 rounded-xl bg-brand-600 border border-brand-500 px-5 py-3 text-sm font-bold text-white hover:bg-brand-500 transition-colors shadow-sm"
              >
                <Play className="h-4 w-4" />
                <span>Start a Mock Test</span>
              </Link>
              <Link
                to="/practice"
                className="inline-flex items-center gap-2 rounded-xl bg-slate-800 border border-slate-700 px-4 py-3 text-sm font-semibold text-slate-200 hover:bg-slate-700 transition-colors"
              >
                <BookOpen className="h-4 w-4 text-indigo-400" />
                <span>Chapter Question Bank</span>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* RESUME ACTIVE TEST BANNER (IF ANY IN LOCALSTORAGE) */}
      {activeSessionsList.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="rounded-2xl border border-amber-300 dark:border-amber-800 bg-amber-50/90 dark:bg-amber-950/40 p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <Clock className="h-5 w-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <div>
                <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                  Unfinished Mock Test Saved on This Device
                </h2>
                <p className="text-xs text-slate-700 dark:text-slate-300">
                  Your active test timer and selected responses were preserved
                  locally. You can resume right where you left off.
                </p>
              </div>
            </div>
            <Link
              to={`/test/${activeSessionsList[0].testId}`}
              className="inline-flex items-center gap-1.5 rounded-xl bg-amber-600 px-4 py-2 text-xs font-bold text-white hover:bg-amber-700 transition-colors shrink-0"
            >
              <Play className="h-3.5 w-3.5" />
              <span>
                Resume Test (
                {Math.ceil(activeSessionsList[0].remainingSec / 60)}m left)
              </span>
            </Link>
          </div>
        </section>
      )}

      {/* 4 MAIN RESOURCE CATEGORIES BELOW HERO */}
      <section
        aria-labelledby="resource-categories-heading"
        className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
      >
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-6">
          <div>
            <h2
              id="resource-categories-heading"
              className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white"
            >
              Core Study Resource Categories
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              Jump directly to exam-specific papers, worked solutions, or timed
              simulations.
            </p>
          </div>
          <Link
            to="/library"
            className="inline-flex items-center gap-1 text-xs font-semibold text-brand-600 dark:text-brand-400 hover:underline"
          >
            <span>View Full Library ({STUDY_RESOURCES_DATASET.length} items)</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {/* Category 1: Board PYQs */}
          <Link
            to="/library?exam=CBSE+Board"
            className="group rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm hover:border-brand-400 hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-navy-900 text-white dark:bg-brand-950 dark:text-brand-300">
                <FileText className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                  1. Board PYQs & Papers
                </h3>
                <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  CBSE Class 11 & Class 12 paper archives, code sets, and
                  linked online objective question sets.
                </p>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-brand-600 dark:text-brand-400">
              <span>Browse CBSE Resources</span>
              <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </Link>

          {/* Category 2: JEE Main PYQs */}
          <Link
            to="/library?exam=JEE+Main"
            className="group rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm hover:border-brand-400 hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-brand-600 text-white">
                <Award className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                  2. JEE Main PYQs & Shifts
                </h3>
                <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Session 1 & Session 2 shift practice sets, topic archives, and
                  step-by-step worked derivations.
                </p>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-brand-600 dark:text-brand-400">
              <span>Explore JEE Main Sets</span>
              <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </Link>

          {/* Category 3: Sample Papers */}
          <Link
            to="/library?category=Sample+Paper"
            className="group rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm hover:border-brand-400 hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 text-white">
                <BookOpen className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                  3. Sample Papers & Keys
                </h3>
                <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Downloadable 2-page PDF sample papers with verified answer
                  keys and NCERT stepwise marking notes.
                </p>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-brand-600 dark:text-brand-400">
              <span>Open Sample Papers</span>
              <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </Link>

          {/* Category 4: Interactive Mock Tests */}
          <Link
            to="/tests"
            className="group rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm hover:border-brand-400 hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-amber-600 text-white">
                <CheckSquare className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                  4. Interactive Mock Tests
                </h3>
                <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Chapter-wise and full-length timed simulations with question
                  palette, +4/−1 or +1/0 scoring, and mistake analysis.
                </p>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-brand-600 dark:text-brand-400">
              <span>Launch Mock Test Engine</span>
              <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </Link>
        </div>
      </section>

      {/* DIRECT STUDY ACCESS: FEATURED DOWNLOADABLE PAPERS */}
      <section
        aria-labelledby="featured-papers-heading"
        className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
      >
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-6">
          <div>
            <h2
              id="featured-papers-heading"
              className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white"
            >
              Ready-to-Download Study Papers & Worked Keys
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              View in-browser or download real multi-page PDFs with complete
              worked solutions.
            </p>
          </div>
          <Link
            to="/library"
            className="inline-flex items-center gap-1 text-xs font-semibold text-brand-600 dark:text-brand-400 hover:underline"
          >
            <span>Filter by Class, Subject, Chapter & Year</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
          {featuredResources.map((resource) => (
            <ResourceCard
              key={resource.id}
              resource={resource}
              isBookmarked={bookmarkedIds.includes(resource.id)}
              onToggleBookmark={handleToggleBookmark}
              onOpenViewer={(res) => setSelectedResource(res)}
            />
          ))}
        </div>
      </section>

      {/* DIRECT ACCESS: INTERACTIVE MOCK TESTS */}
      <section
        aria-labelledby="featured-tests-heading"
        className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
      >
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-6">
          <div>
            <h2
              id="featured-tests-heading"
              className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white"
            >
              Start a Timed Mock Test Immediately
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              No sign-up required. Configurable marking schemes verified against
              JEE Main (+4/−1) and CBSE Board (+1/0).
            </p>
          </div>
          <Link
            to="/tests"
            className="inline-flex items-center gap-1 text-xs font-semibold text-brand-600 dark:text-brand-400 hover:underline"
          >
            <span>All {MOCK_TESTS_DATASET.length} Mock Tests</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          {featuredTests.map((test) => (
            <div
              key={test.id}
              className="flex flex-col justify-between rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm hover:border-brand-300 transition-all"
            >
              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="rounded-md bg-slate-900 dark:bg-brand-600 px-2.5 py-0.5 font-semibold text-white">
                    {test.exam}
                  </span>
                  <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2.5 py-0.5 font-medium text-slate-700 dark:text-slate-300">
                    {test.durationMinutes} Mins • {test.questionIds.length} Qs
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {test.title}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {test.subtitle}
                </p>

                <div className="rounded-xl bg-slate-50 dark:bg-slate-800/70 p-3 text-xs space-y-1">
                  <div className="font-semibold text-slate-800 dark:text-slate-200">
                    Marking: {test.markingScheme.schemeName}
                  </div>
                  <div className="text-slate-500 dark:text-slate-400">
                    Subjects: {test.subjects.join(', ')} ({test.classLevel})
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">
                  Max Marks:{' '}
                  {test.questionIds.length * test.markingScheme.correctMarks}
                </span>
                <Link
                  to={`/test/${test.id}`}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-brand-600 px-4 py-2 text-xs font-bold text-white hover:bg-brand-700 transition-colors"
                >
                  <Play className="h-3.5 w-3.5" />
                  <span>Start Test</span>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ACADEMIC TRUST, VERIFICATION & LOCAL PRIVACY BANNER */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex items-start gap-3.5">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Transparent Content Provenance
              </h3>
              <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                We clearly distinguish Verified Pattern Keys, Independently
                Prepared Solutions, Practice Questions Written for EduSphere,
                and Pending Archival Entries—never inventing fake citations.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-50 dark:bg-brand-950/60 text-brand-600">
              <BookOpen className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Real PDFs & Vector Diagrams
              </h3>
              <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                Available papers download as genuine multi-page PDFs. Physics,
                Chemistry, and Calculus diagrams are rendered as crisp SVGs with
                preserved aspect ratios.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600">
              <HardDrive className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Zero Login • Local Device Storage
              </h3>
              <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                No sign-up walls or subscriptions. Your test attempts and
                bookmarks are stored locally in your browser and can be cleared
                anytime.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* PDF & DOCUMENT VIEWER MODAL */}
      <PdfViewerModal
        resource={selectedResource}
        linkedQuestions={linkedQuestionsForModal}
        onClose={() => setSelectedResource(null)}
      />
    </div>
  );
};
