import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { LibraryPage } from './pages/LibraryPage';
import { PracticePage } from './pages/PracticePage';
import { MockTestsPage } from './pages/MockTestsPage';
import { TestEnginePage } from './pages/TestEnginePage';
import { TestResultPage } from './pages/TestResultPage';
import { ProgressPage } from './pages/ProgressPage';
import { ArchitecturePage } from './pages/ArchitecturePage';
import { getThemePreference, setThemePreference } from './core/storage';

const ScrollToTop: React.FC = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

export const App: React.FC = () => {
  const [theme, setTheme] = useState<'light' | 'dark'>(() =>
    getThemePreference()
  );

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    setThemePreference(theme);
  }, [theme]);

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  return (
    <BrowserRouter>
      <ScrollToTop />
      <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 transition-colors">
        <Navbar theme={theme} onToggleTheme={handleToggleTheme} />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/library" element={<LibraryPage />} />
            <Route path="/practice" element={<PracticePage />} />
            <Route path="/tests" element={<MockTestsPage />} />
            <Route path="/test/:testId" element={<TestEnginePage />} />
            <Route
              path="/test/:testId/result/:attemptId"
              element={<TestResultPage />}
            />
            <Route path="/progress" element={<ProgressPage />} />
            <Route path="/architecture" element={<ArchitecturePage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
};
