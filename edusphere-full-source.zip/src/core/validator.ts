import { Question, StudyResource } from './types';

export interface ValidationIssue {
  itemId: string;
  field: string;
  severity: 'error' | 'warning';
  message: string;
}

export interface ValidationReport {
  valid: boolean;
  checkedCount: number;
  errorCount: number;
  warningCount: number;
  issues: ValidationIssue[];
}

const VALID_EXAMS = new Set(['JEE Main', 'CBSE Board']);
const VALID_CLASSES = new Set(['Class 11', 'Class 12', 'Class 11 & 12']);
const VALID_SUBJECTS = new Set(['Physics', 'Chemistry', 'Mathematics']);
const VALID_VERIFICATION_STATUSES = new Set([
  'verified_official_key',
  'independently_prepared_solution',
  'edusphere_original_practice',
  'pending_verification',
]);

export function validateQuestionDataset(
  questionsInput: unknown
): ValidationReport {
  const issues: ValidationIssue[] = [];

  if (!Array.isArray(questionsInput)) {
    return {
      valid: false,
      checkedCount: 0,
      errorCount: 1,
      warningCount: 0,
      issues: [
        {
          itemId: 'ROOT',
          field: 'questions',
          severity: 'error',
          message: 'Dataset root must be a JSON array of Question objects.',
        },
      ],
    };
  }

  const seenIds = new Set<string>();

  questionsInput.forEach((rawItem, index) => {
    const q = rawItem as Partial<Question>;
    const itemId = q?.id || `index-${index}`;

    if (!q || typeof q !== 'object') {
      issues.push({
        itemId,
        field: 'root',
        severity: 'error',
        message: 'Question entry must be an object.',
      });
      return;
    }

    if (!q.id || typeof q.id !== 'string' || q.id.trim().length < 3) {
      issues.push({
        itemId,
        field: 'id',
        severity: 'error',
        message: 'Question ID must be a non-empty string of at least 3 characters.',
      });
    } else if (seenIds.has(q.id)) {
      issues.push({
        itemId: q.id,
        field: 'id',
        severity: 'error',
        message: `Duplicate Question ID "${q.id}" found in dataset.`,
      });
    } else {
      seenIds.add(q.id);
    }

    if (!q.exam || !VALID_EXAMS.has(q.exam)) {
      issues.push({
        itemId,
        field: 'exam',
        severity: 'error',
        message: `Invalid exam "${String(q.exam)}". Expected JEE Main or CBSE Board.`,
      });
    }

    if (!q.classLevel || !VALID_CLASSES.has(q.classLevel)) {
      issues.push({
        itemId,
        field: 'classLevel',
        severity: 'error',
        message: `Invalid classLevel "${String(q.classLevel)}".`,
      });
    }

    if (!q.subject || !VALID_SUBJECTS.has(q.subject)) {
      issues.push({
        itemId,
        field: 'subject',
        severity: 'error',
        message: `Invalid subject "${String(q.subject)}".`,
      });
    }

    if (!q.chapter || typeof q.chapter !== 'string' || !q.chapter.trim()) {
      issues.push({
        itemId,
        field: 'chapter',
        severity: 'error',
        message: 'Chapter name is required.',
      });
    }

    if (
      !q.questionText ||
      typeof q.questionText !== 'string' ||
      q.questionText.trim().length < 10
    ) {
      issues.push({
        itemId,
        field: 'questionText',
        severity: 'error',
        message: 'Question text must be at least 10 characters long.',
      });
    }

    if (q.questionType === 'mcq_single') {
      if (!Array.isArray(q.options) || q.options.length !== 4) {
        issues.push({
          itemId,
          field: 'options',
          severity: 'error',
          message: 'Single-choice MCQ questions must provide exactly 4 options (A, B, C, D).',
        });
      } else {
        const optionIds = q.options.map((o) => o.id);
        const expected = ['A', 'B', 'C', 'D'];
        if (expected.some((exp) => !optionIds.includes(exp as 'A' | 'B' | 'C' | 'D'))) {
          issues.push({
            itemId,
            field: 'options',
            severity: 'error',
            message: 'MCQ options must have IDs A, B, C, and D.',
          });
        }
        if (!q.correctAnswer || !optionIds.includes(q.correctAnswer as 'A' | 'B' | 'C' | 'D')) {
          issues.push({
            itemId,
            field: 'correctAnswer',
            severity: 'error',
            message: `correctAnswer "${String(q.correctAnswer)}" must match one of the option IDs (A, B, C, D).`,
          });
        }
      }
    } else if (q.questionType === 'numerical') {
      if (
        q.correctAnswer === undefined ||
        Number.isNaN(Number(q.correctAnswer))
      ) {
        issues.push({
          itemId,
          field: 'correctAnswer',
          severity: 'error',
          message: 'Numerical question correctAnswer must be a valid number.',
        });
      }
    } else {
      issues.push({
        itemId,
        field: 'questionType',
        severity: 'error',
        message: `Unsupported questionType "${String(q.questionType)}".`,
      });
    }

    if (typeof q.marksCorrect !== 'number' || q.marksCorrect <= 0) {
      issues.push({
        itemId,
        field: 'marksCorrect',
        severity: 'error',
        message: 'marksCorrect must be a positive number.',
      });
    }

    if (typeof q.marksIncorrect !== 'number' || q.marksIncorrect > 0) {
      issues.push({
        itemId,
        field: 'marksIncorrect',
        severity: 'error',
        message: 'marksIncorrect must be 0 or a negative number (e.g., -1).',
      });
    }

    if (
      !q.explanation ||
      typeof q.explanation !== 'string' ||
      q.explanation.trim().length < 15
    ) {
      issues.push({
        itemId,
        field: 'explanation',
        severity: 'warning',
        message: 'Detailed worked explanation is missing or too short (< 15 chars).',
      });
    }

    if (
      !q.verification ||
      !VALID_VERIFICATION_STATUSES.has(q.verification.status) ||
      !q.verification.source ||
      !q.verification.contentVersion
    ) {
      issues.push({
        itemId,
        field: 'verification',
        severity: 'error',
        message:
          'Every question must include verification metadata (status, source, contentVersion).',
      });
    }

    if (q.diagram) {
      if (
        !q.diagram.svgContent ||
        !q.diagram.aspectRatio ||
        !q.diagram.altText
      ) {
        issues.push({
          itemId,
          field: 'diagram',
          severity: 'error',
          message:
            'Diagram must include svgContent, aspectRatio, and accessible altText.',
        });
      }
    }
  });

  const errorCount = issues.filter((i) => i.severity === 'error').length;
  const warningCount = issues.filter((i) => i.severity === 'warning').length;

  return {
    valid: errorCount === 0,
    checkedCount: questionsInput.length,
    errorCount,
    warningCount,
    issues,
  };
}

export function validateResourceDataset(
  resourcesInput: unknown
): ValidationReport {
  const issues: ValidationIssue[] = [];

  if (!Array.isArray(resourcesInput)) {
    return {
      valid: false,
      checkedCount: 0,
      errorCount: 1,
      warningCount: 0,
      issues: [
        {
          itemId: 'ROOT',
          field: 'resources',
          severity: 'error',
          message: 'Dataset root must be a JSON array of StudyResource objects.',
        },
      ],
    };
  }

  const seenIds = new Set<string>();

  resourcesInput.forEach((raw, idx) => {
    const r = raw as Partial<StudyResource>;
    const itemId = r?.id || `res-${idx}`;

    if (!r.id || seenIds.has(r.id)) {
      issues.push({
        itemId,
        field: 'id',
        severity: 'error',
        message: 'Resource ID must be unique and non-empty.',
      });
    } else {
      seenIds.add(r.id);
    }

    if (r.pdfAvailable && (!r.pdfUrl || !r.pdfUrl.endsWith('.pdf'))) {
      issues.push({
        itemId,
        field: 'pdfUrl',
        severity: 'error',
        message:
          'Resources marked pdfAvailable=true must specify a valid .pdf URL path.',
      });
    }

    if (!r.pdfAvailable && !r.unavailableReason) {
      issues.push({
        itemId,
        field: 'unavailableReason',
        severity: 'warning',
        message:
          'Resources with pdfAvailable=false should provide an honest unavailableReason for students.',
      });
    }
  });

  const errorCount = issues.filter((i) => i.severity === 'error').length;
  const warningCount = issues.filter((i) => i.severity === 'warning').length;

  return {
    valid: errorCount === 0,
    checkedCount: resourcesInput.length,
    errorCount,
    warningCount,
    issues,
  };
}
