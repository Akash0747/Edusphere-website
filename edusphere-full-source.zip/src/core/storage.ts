import { ActiveTestSession, TestAttemptResult } from './types';

const STORAGE_KEYS = {
  ACTIVE_SESSIONS: 'edusphere_v1_active_test_sessions',
  ATTEMPT_HISTORY: 'edusphere_v1_attempt_history',
  BOOKMARKED_RESOURCES: 'edusphere_v1_bookmarked_resources',
  BOOKMARKED_QUESTIONS: 'edusphere_v1_bookmarked_questions',
  PRACTICED_QUESTIONS: 'edusphere_v1_practiced_questions',
  THEME_PREF: 'edusphere_v1_theme_pref',
} as const;

const memoryStore: Record<string, string> = {};

function getStorage(): {
  getItem(key: string): string | null;
  setItem(key: string, val: string): void;
  removeItem(key: string): void;
} {
  if (typeof window !== 'undefined' && window.localStorage) {
    return window.localStorage;
  }
  return {
    getItem: (k) => (k in memoryStore ? memoryStore[k] : null),
    setItem: (k, v) => {
      memoryStore[k] = v;
    },
    removeItem: (k) => {
      delete memoryStore[k];
    },
  };
}

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function getActiveTestSessions(): Record<string, ActiveTestSession> {
  const store = getStorage();
  return safeParse<Record<string, ActiveTestSession>>(
    store.getItem(STORAGE_KEYS.ACTIVE_SESSIONS),
    {}
  );
}

export function getActiveTestSession(testId: string): ActiveTestSession | null {
  const all = getActiveTestSessions();
  const session = all[testId];
  if (!session || session.isSubmitted) return null;
  return session;
}

export function saveActiveTestSession(session: ActiveTestSession): void {
  const store = getStorage();
  const all = getActiveTestSessions();
  all[session.testId] = {
    ...session,
    lastUpdatedAtIso: new Date().toISOString(),
  };
  store.setItem(STORAGE_KEYS.ACTIVE_SESSIONS, JSON.stringify(all));
}

export function removeActiveTestSession(testId: string): void {
  const store = getStorage();
  const all = getActiveTestSessions();
  delete all[testId];
  store.setItem(STORAGE_KEYS.ACTIVE_SESSIONS, JSON.stringify(all));
}

export function computeRemainingSeconds(
  session: ActiveTestSession,
  nowMs: number = Date.now()
): number {
  const deltaSinceLastTickSeconds = Math.max(
    0,
    Math.floor((nowMs - session.lastTickTimestampMs) / 1000)
  );
  const totalElapsed =
    session.elapsedSecondsBeforeResume + deltaSinceLastTickSeconds;
  return Math.max(0, session.durationSeconds - totalElapsed);
}

export function computeElapsedSeconds(
  session: ActiveTestSession,
  nowMs: number = Date.now()
): number {
  const deltaSinceLastTickSeconds = Math.max(
    0,
    Math.floor((nowMs - session.lastTickTimestampMs) / 1000)
  );
  return Math.min(
    session.durationSeconds,
    session.elapsedSecondsBeforeResume + deltaSinceLastTickSeconds
  );
}

export function getAttemptHistory(): TestAttemptResult[] {
  const store = getStorage();
  return safeParse<TestAttemptResult[]>(
    store.getItem(STORAGE_KEYS.ATTEMPT_HISTORY),
    []
  );
}

export function getAttemptById(attemptId: string): TestAttemptResult | null {
  const history = getAttemptHistory();
  return history.find((a) => a.attemptId === attemptId) ?? null;
}

/**
 * Saves a completed test attempt to local history and atomically clears
 * the in-progress session. Prevents duplicate submissions with the same attemptId.
 */
export function saveCompletedAttempt(result: TestAttemptResult): {
  saved: boolean;
  alreadyExisted: boolean;
} {
  const store = getStorage();
  const history = getAttemptHistory();
  const alreadyExisted = history.some((a) => a.attemptId === result.attemptId);

  if (!alreadyExisted) {
    const updated = [result, ...history];
    store.setItem(STORAGE_KEYS.ATTEMPT_HISTORY, JSON.stringify(updated));
  }

  // Always remove the active session for this test so it cannot be re-submitted
  removeActiveTestSession(result.testId);

  return {
    saved: !alreadyExisted,
    alreadyExisted,
  };
}

export function getBookmarkedResourceIds(): string[] {
  const store = getStorage();
  return safeParse<string[]>(
    store.getItem(STORAGE_KEYS.BOOKMARKED_RESOURCES),
    []
  );
}

export function toggleBookmarkedResource(resourceId: string): string[] {
  const store = getStorage();
  const current = getBookmarkedResourceIds();
  const updated = current.includes(resourceId)
    ? current.filter((id) => id !== resourceId)
    : [...current, resourceId];
  store.setItem(STORAGE_KEYS.BOOKMARKED_RESOURCES, JSON.stringify(updated));
  return updated;
}

export function getBookmarkedQuestionIds(): string[] {
  const store = getStorage();
  return safeParse<string[]>(
    store.getItem(STORAGE_KEYS.BOOKMARKED_QUESTIONS),
    []
  );
}

export function toggleBookmarkedQuestion(questionId: string): string[] {
  const store = getStorage();
  const current = getBookmarkedQuestionIds();
  const updated = current.includes(questionId)
    ? current.filter((id) => id !== questionId)
    : [...current, questionId];
  store.setItem(STORAGE_KEYS.BOOKMARKED_QUESTIONS, JSON.stringify(updated));
  return updated;
}

export interface PracticedQuestionRecord {
  questionId: string;
  selectedAnswer: string;
  isCorrect: boolean;
  practicedAtIso: string;
}

export function getPracticedQuestions(): Record<string, PracticedQuestionRecord> {
  const store = getStorage();
  return safeParse<Record<string, PracticedQuestionRecord>>(
    store.getItem(STORAGE_KEYS.PRACTICED_QUESTIONS),
    {}
  );
}

export function recordPracticedQuestion(
  record: PracticedQuestionRecord
): Record<string, PracticedQuestionRecord> {
  const store = getStorage();
  const current = getPracticedQuestions();
  current[record.questionId] = record;
  store.setItem(STORAGE_KEYS.PRACTICED_QUESTIONS, JSON.stringify(current));
  return current;
}

export function clearAllLocalEduSphereData(): void {
  const store = getStorage();
  store.removeItem(STORAGE_KEYS.ACTIVE_SESSIONS);
  store.removeItem(STORAGE_KEYS.ATTEMPT_HISTORY);
  store.removeItem(STORAGE_KEYS.BOOKMARKED_RESOURCES);
  store.removeItem(STORAGE_KEYS.BOOKMARKED_QUESTIONS);
  store.removeItem(STORAGE_KEYS.PRACTICED_QUESTIONS);
}

export function getThemePreference(): 'light' | 'dark' {
  const store = getStorage();
  const raw = store.getItem(STORAGE_KEYS.THEME_PREF);
  return raw === 'dark' ? 'dark' : 'light';
}

export function setThemePreference(theme: 'light' | 'dark'): void {
  const store = getStorage();
  store.setItem(STORAGE_KEYS.THEME_PREF, theme);
}
