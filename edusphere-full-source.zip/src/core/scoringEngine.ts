import {
  ActiveTestSession,
  MockTestConfig,
  Question,
  QuestionPaletteStatus,
  QuestionResponseState,
  QuestionScoreDetail,
  SubjectPerformance,
  SubjectType,
  TestAttemptResult,
  TopicMistakeFinding,
} from './types';

export function getQuestionPaletteStatus(
  response: QuestionResponseState | undefined
): QuestionPaletteStatus {
  if (!response || !response.visited) {
    return 'not_visited';
  }
  const hasAnswer =
    response.selectedOption !== null &&
    response.selectedOption.trim() !== '';

  if (hasAnswer && response.markedForReview) {
    return 'answered_marked_for_review';
  }
  if (hasAnswer) {
    return 'answered';
  }
  if (response.markedForReview) {
    return 'marked_for_review';
  }
  return 'not_answered';
}

export function normalizeAnswer(val: string | null | undefined): string {
  if (val === null || val === undefined) return '';
  return val.trim().toUpperCase();
}

export function isAnswerCorrect(
  question: Question,
  selectedOption: string | null | undefined
): boolean {
  const normalizedSelected = normalizeAnswer(selectedOption);
  if (!normalizedSelected) return false;
  const normalizedCorrect = normalizeAnswer(question.correctAnswer);

  if (question.questionType === 'numerical') {
    const numSelected = Number(normalizedSelected);
    const numCorrect = Number(normalizedCorrect);
    if (!Number.isNaN(numSelected) && !Number.isNaN(numCorrect)) {
      return Math.abs(numSelected - numCorrect) < 1e-4;
    }
  }
  return normalizedSelected === normalizedCorrect;
}

export function scoreTestAttempt(
  testConfig: MockTestConfig,
  questions: Question[],
  session: ActiveTestSession,
  submissionReason: 'manual_submit' | 'timer_expired' = 'manual_submit',
  totalElapsedSecondsOverride?: number
): TestAttemptResult {
  const questionMap = new Map<string, Question>();
  for (const q of questions) {
    questionMap.set(q.id, q);
  }

  // Order questions according to testConfig.questionIds
  const orderedQuestions: Question[] = [];
  for (const qId of testConfig.questionIds) {
    const found = questionMap.get(qId);
    if (found) {
      orderedQuestions.push(found);
    }
  }

  let totalScore = 0;
  let maxScore = 0;
  let positiveMarksEarned = 0;
  let negativeMarksDeducted = 0;
  let attemptedCount = 0;
  let correctCount = 0;
  let incorrectCount = 0;
  let unansweredCount = 0;
  let sumQuestionTimeSeconds = 0;

  const questionDetails: QuestionScoreDetail[] = [];

  orderedQuestions.forEach((question, idx) => {
    const response = session.responses[question.id];
    const selected = response?.selectedOption ?? null;
    const hasSelected = selected !== null && selected.trim() !== '';
    const timeSpent = Math.max(0, Math.round(response?.timeSpentSeconds ?? 0));
    sumQuestionTimeSeconds += timeSpent;

    const qCorrectMarks = testConfig.markingScheme.useQuestionSpecificMarks
      ? question.marksCorrect
      : testConfig.markingScheme.correctMarks;

    // Ensure negativeMarks is represented as a negative or zero value (e.g. -1)
    const rawNeg = testConfig.markingScheme.useQuestionSpecificMarks
      ? question.marksIncorrect
      : testConfig.markingScheme.negativeMarks;
    const qIncorrectMarks = rawNeg > 0 ? -rawNeg : rawNeg;

    const qUnansweredMarks = testConfig.markingScheme.useQuestionSpecificMarks
      ? question.marksUnanswered
      : testConfig.markingScheme.unansweredMarks;

    maxScore += qCorrectMarks;

    let status: 'correct' | 'incorrect' | 'unanswered';
    let marksAwarded = 0;

    if (!hasSelected) {
      status = 'unanswered';
      marksAwarded = qUnansweredMarks;
      unansweredCount += 1;
    } else {
      attemptedCount += 1;
      if (isAnswerCorrect(question, selected)) {
        status = 'correct';
        marksAwarded = qCorrectMarks;
        positiveMarksEarned += qCorrectMarks;
        correctCount += 1;
      } else {
        status = 'incorrect';
        marksAwarded = qIncorrectMarks;
        negativeMarksDeducted += Math.abs(qIncorrectMarks);
        incorrectCount += 1;
      }
    }

    totalScore += marksAwarded;

    questionDetails.push({
      questionId: question.id,
      questionNumber: idx + 1,
      subject: question.subject,
      chapter: question.chapter,
      topic: question.topic,
      selectedOption: hasSelected ? selected!.trim() : null,
      correctAnswer: question.correctAnswer,
      status,
      marksAwarded,
      maxMarks: qCorrectMarks,
      negativeMarksApplied: qIncorrectMarks,
      timeSpentSeconds: timeSpent,
      markedForReview: Boolean(response?.markedForReview),
    });
  });

  const rawPercentage =
    maxScore > 0 ? Number(((totalScore / maxScore) * 100).toFixed(1)) : 0;
  const percentage = Math.max(0, rawPercentage);
  const accuracy =
    attemptedCount > 0
      ? Number(((correctCount / attemptedCount) * 100).toFixed(1))
      : 0;

  // Subject breakdown
  const subjectsInTest = Array.from(
    new Set(orderedQuestions.map((q) => q.subject))
  );
  const subjectBreakdown: SubjectPerformance[] = subjectsInTest.map(
    (subject: SubjectType) => {
      const subDetails = questionDetails.filter((d) => d.subject === subject);
      const subTotalQ = subDetails.length;
      const subCorrect = subDetails.filter((d) => d.status === 'correct').length;
      const subIncorrect = subDetails.filter(
        (d) => d.status === 'incorrect'
      ).length;
      const subUnanswered = subDetails.filter(
        (d) => d.status === 'unanswered'
      ).length;
      const subAttempted = subCorrect + subIncorrect;
      const subScore = subDetails.reduce((acc, d) => acc + d.marksAwarded, 0);
      const subMax = subDetails.reduce((acc, d) => acc + d.maxMarks, 0);
      const subTime = subDetails.reduce(
        (acc, d) => acc + d.timeSpentSeconds,
        0
      );

      return {
        subject,
        totalQuestions: subTotalQ,
        attemptedCount: subAttempted,
        correctCount: subCorrect,
        incorrectCount: subIncorrect,
        unansweredCount: subUnanswered,
        score: subScore,
        maxScore: subMax,
        percentage:
          subMax > 0
            ? Math.max(0, Number(((subScore / subMax) * 100).toFixed(1)))
            : 0,
        accuracy:
          subAttempted > 0
            ? Number(((subCorrect / subAttempted) * 100).toFixed(1))
            : 0,
        timeSpentSeconds: subTime,
      };
    }
  );

  // Evidence-based Mistake Analysis grouped by Chapter + Topic
  const chapterGroupMap = new Map<
    string,
    {
      subject: SubjectType;
      chapter: string;
      topic: string;
      details: QuestionScoreDetail[];
    }
  >();

  for (const detail of questionDetails) {
    const key = `${detail.subject}::${detail.chapter}`;
    const existing = chapterGroupMap.get(key);
    if (existing) {
      existing.details.push(detail);
    } else {
      chapterGroupMap.set(key, {
        subject: detail.subject,
        chapter: detail.chapter,
        topic: detail.topic,
        details: [detail],
      });
    }
  }

  const mistakeAnalysis: TopicMistakeFinding[] = [];

  for (const group of chapterGroupMap.values()) {
    const inc = group.details.filter((d) => d.status === 'incorrect');
    const unans = group.details.filter((d) => d.status === 'unanswered');
    const corr = group.details.filter((d) => d.status === 'correct');

    if (inc.length === 0 && unans.length === 0) {
      continue;
    }

    const marksLostToNegative = inc.reduce(
      (acc, d) => acc + Math.abs(d.negativeMarksApplied),
      0
    );
    const marksMissedOpportunity = [...inc, ...unans].reduce(
      (acc, d) => acc + d.maxMarks,
      0
    );
    const totalTimeSpent = group.details.reduce(
      (acc, d) => acc + d.timeSpentSeconds,
      0
    );

    const measuredFacts: string[] = [
      `Answered ${corr.length} of ${group.details.length} question(s) correctly in ${group.chapter} (${group.subject}).`,
    ];

    if (inc.length > 0) {
      measuredFacts.push(
        `${inc.length} incorrect response(s) resulted in ${
          marksLostToNegative > 0
            ? `a deduction of ${marksLostToNegative} mark(s) from negative marking`
            : '0 marks awarded'
        } and ${inc.reduce((a, b) => a + b.maxMarks, 0)} missed positive mark(s).`
      );
    }
    if (unans.length > 0) {
      measuredFacts.push(
        `${unans.length} question(s) were left unanswered (${unans.reduce(
          (a, b) => a + b.maxMarks,
          0
        )} potential mark(s) unattempted).`
      );
    }
    measuredFacts.push(
      `Total recorded time on this chapter's questions: ${totalTimeSpent} second(s).`
    );

    const possibleExplanations: string[] = [];
    if (inc.length > 0) {
      possibleExplanations.push(
        `Possible factor — Formula or sign convention slip: When reviewing Q${inc
          .map((d) => d.questionNumber)
          .join(', Q')}, check whether the core physical/mathematical relation was set up properly before arithmetic substitution.`
      );
      possibleExplanations.push(
        `Possible factor — Option distractor trap: Compare your selected option (${inc
          .map((d) => d.selectedOption)
          .join(', ')}) against the worked explanation to verify whether an intermediate value was chosen instead of the final asked quantity.`
      );
    }
    if (unans.length > 0) {
      possibleExplanations.push(
        `Possible factor — Topic unfamiliarity or cautious skipping under negative marking: Leaving uncertain questions blank avoids penalty (${testConfig.markingScheme.negativeMarks} mark), though reviewing the worked solution for Q${unans
          .map((d) => d.questionNumber)
          .join(', Q')} can convert this topic into a scoring area.`
      );
    }

    const severity: 'high' | 'medium' | 'low' =
      inc.length >= 2 || (inc.length >= 1 && marksLostToNegative > 0)
        ? 'high'
        : inc.length === 1 || unans.length >= 2
        ? 'medium'
        : 'low';

    const recommendedAction =
      inc.length > 0
        ? `Review the step-by-step worked solution for ${group.chapter} (Q${inc
            .map((d) => d.questionNumber)
            .join(', Q')}) and solve 2–3 untimed practice questions in the Question Bank before your next timed simulation.`
        : `Study the solved derivation for ${group.chapter} (Q${unans
            .map((d) => d.questionNumber)
            .join(', Q')}) and attempt the chapter practice set in untimed mode.`;

    mistakeAnalysis.push({
      subject: group.subject,
      chapter: group.chapter,
      topic: group.topic,
      totalQuestions: group.details.length,
      incorrectCount: inc.length,
      unansweredCount: unans.length,
      correctCount: corr.length,
      marksLostToNegative,
      marksMissedOpportunity,
      totalTimeSpentSeconds: totalTimeSpent,
      severity,
      measuredFacts,
      possibleExplanations,
      recommendedAction,
      relatedQuestionIds: [...inc, ...unans].map((d) => d.questionId),
    });
  }

  // Sort mistake findings by severity (high -> medium -> low) then by marks missed
  const severityRank = { high: 3, medium: 2, low: 1 };
  mistakeAnalysis.sort((a, b) => {
    if (severityRank[b.severity] !== severityRank[a.severity]) {
      return severityRank[b.severity] - severityRank[a.severity];
    }
    return (
      b.marksMissedOpportunity +
      b.marksLostToNegative -
      (a.marksMissedOpportunity + a.marksLostToNegative)
    );
  });

  // Proportional, truthful feedback tier
  let feedbackTier: 'excellent' | 'good' | 'developing';
  let feedbackHeadline: string;
  let feedbackMessage: string;

  if (rawPercentage >= 75 && accuracy >= 75) {
    feedbackTier = 'excellent';
    feedbackHeadline = 'Excellent work! Your accuracy is improving.';
    feedbackMessage = `You scored ${totalScore} out of ${maxScore} (${percentage}%) with ${accuracy}% accuracy across ${attemptedCount} attempted question(s). Review any remaining skipped or missed questions below to lock in full mastery.`;
  } else if (rawPercentage >= 45) {
    feedbackTier = 'good';
    feedbackHeadline = "Great effort. You've completed another practice session.";
    feedbackMessage = `You scored ${totalScore} out of ${maxScore} (${percentage}%) with ${accuracy}% accuracy. ${
      negativeMarksDeducted > 0
        ? `Note that ${negativeMarksDeducted} mark(s) were deducted due to negative marking on ${incorrectCount} incorrect response(s).`
        : `You answered ${correctCount} question(s) correctly.`
    } Use the chapter breakdown below to target your next revision block.`;
  } else {
    feedbackTier = 'developing';
    feedbackHeadline =
      "Let's strengthen a few topics before your next attempt.";
    feedbackMessage = `You scored ${totalScore} out of ${maxScore} with ${correctCount} correct, ${incorrectCount} incorrect, and ${unansweredCount} unanswered question(s). Focus first on reading the step-by-step worked solutions below and practicing individual chapters without time pressure.`;
  }

  const nextStudyRecommendations: string[] = [];
  if (mistakeAnalysis.length === 0) {
    nextStudyRecommendations.push(
      'All questions in this test were answered accurately. Challenge yourself with another full-length simulation or explore advanced JEE Main numerical problems in the Question Bank.'
    );
  } else {
    for (const item of mistakeAnalysis.slice(0, 3)) {
      nextStudyRecommendations.push(
        `${item.subject} — ${item.chapter}: ${item.recommendedAction}`
      );
    }
    if (negativeMarksDeducted > 0 && accuracy < 70) {
      nextStudyRecommendations.push(
        `Negative Marking Control: ${negativeMarksDeducted} mark(s) were lost to incorrect guesses. In exams with ${testConfig.markingScheme.negativeMarks} negative marking, eliminate at least two options and verify units/dimensions before committing.`
      );
    }
  }

  const durationAllocatedSeconds = testConfig.durationMinutes * 60;
  const totalTimeTakenSeconds =
    totalElapsedSecondsOverride !== undefined
      ? Math.min(
          durationAllocatedSeconds,
          Math.max(1, Math.round(totalElapsedSecondsOverride))
        )
      : Math.min(
          durationAllocatedSeconds,
          Math.max(sumQuestionTimeSeconds, Math.round(session.elapsedSecondsBeforeResume))
        );

  return {
    attemptId: `att-${session.sessionId}`,
    testId: testConfig.id,
    testTitle: testConfig.title,
    exam: testConfig.exam,
    classLevel: testConfig.classLevel,
    category: testConfig.category,
    submittedAtIso: new Date().toISOString(),
    submissionReason,
    totalScore,
    maxScore,
    positiveMarksEarned,
    negativeMarksDeducted,
    percentage,
    rawPercentage,
    accuracy,
    totalQuestions: orderedQuestions.length,
    attemptedCount,
    correctCount,
    incorrectCount,
    unansweredCount,
    totalTimeTakenSeconds,
    durationAllocatedSeconds,
    feedbackTier,
    feedbackHeadline,
    feedbackMessage,
    subjectBreakdown,
    questionDetails,
    mistakeAnalysis,
    nextStudyRecommendations,
  };
}
