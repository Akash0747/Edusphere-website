export type ExamType = 'JEE Main' | 'CBSE Board';

export type ClassLevel = 'Class 11' | 'Class 12' | 'Class 11 & 12';

export type SubjectType = 'Physics' | 'Chemistry' | 'Mathematics';

export type ResourceCategory =
  | 'Board PYQ'
  | 'JEE Main PYQ'
  | 'Sample Paper'
  | 'Practice Paper'
  | 'Answer Key & Solutions';

export type VerificationStatus =
  | 'verified_official_key'
  | 'independently_prepared_solution'
  | 'edusphere_original_practice'
  | 'pending_verification';

export interface VerificationMetadata {
  status: VerificationStatus;
  label: string;
  source: string;
  contentVersion: string;
  lastChecked: string;
  notes?: string;
}

export interface QuestionDiagram {
  id: string;
  title: string;
  altText: string;
  caption?: string;
  width: number;
  height: number;
  aspectRatio: string; // e.g., "16/9" or "4/3"
  svgContent: string;
}

export interface QuestionOption {
  id: 'A' | 'B' | 'C' | 'D';
  text: string;
}

export type QuestionType = 'mcq_single' | 'numerical';

export type DifficultyLevel = 'Easy' | 'Moderate' | 'Challenging';

export interface Question {
  id: string;
  exam: ExamType;
  classLevel: ClassLevel;
  subject: SubjectType;
  chapter: string;
  topic: string;
  questionType: QuestionType;
  difficulty: DifficultyLevel;
  questionText: string;
  diagram?: QuestionDiagram;
  options?: QuestionOption[];
  correctAnswer: string;
  explanation: string;
  keyTakeaway?: string;
  marksCorrect: number;
  marksIncorrect: number; // negative or 0, e.g. -1 for JEE Main MCQ, 0 for CBSE Board
  marksUnanswered: number; // typically 0
  year?: number;
  session?: string; // e.g. "Jan Session 1 - Shift 1" or "Set 55/1/1"
  verification: VerificationMetadata;
}

export interface DocumentPreviewSection {
  heading: string;
  content: string[];
}

export interface StudyResource {
  id: string;
  title: string;
  subtitle: string;
  exam: ExamType;
  classLevel: ClassLevel;
  subject: SubjectType;
  chapter?: string;
  year: number;
  sessionOrSet?: string; // e.g., "Session 1 (Jan Shift 1)" for JEE Main, or "Set 1 (Code 55/1/1)" for CBSE
  category: ResourceCategory;
  description: string;
  pdfAvailable: boolean;
  pdfUrl?: string;
  pdfFileSize?: string;
  pdfPageCount?: number;
  unavailableReason?: string;
  hasOnlineQuestionSet: boolean;
  linkedQuestionIds: string[];
  linkedTestId?: string;
  hasAnswerKey: boolean;
  hasWorkedSolutions: boolean;
  verification: VerificationMetadata;
  documentPreview?: DocumentPreviewSection[];
}

export interface MarkingSchemeConfig {
  correctMarks: number;
  negativeMarks: number; // e.g. -1 (stored as negative or positive magnitude, we normalize carefully)
  unansweredMarks: number;
  useQuestionSpecificMarks: boolean;
  schemeName: string;
  description: string;
}

export interface MockTestConfig {
  id: string;
  title: string;
  subtitle: string;
  category: 'chapter_test' | 'full_simulation';
  exam: ExamType;
  classLevel: ClassLevel;
  subjects: SubjectType[];
  chaptersCovered: string[];
  durationMinutes: number;
  questionIds: string[];
  markingScheme: MarkingSchemeConfig;
  testMode: 'exam_simulation' | 'practice_with_review';
  instructions: string[];
  verification: VerificationMetadata;
}

export type QuestionPaletteStatus =
  | 'not_visited'
  | 'not_answered'
  | 'answered'
  | 'marked_for_review'
  | 'answered_marked_for_review';

export interface QuestionResponseState {
  questionId: string;
  selectedOption: string | null;
  markedForReview: boolean;
  visited: boolean;
  timeSpentSeconds: number;
}

export interface ActiveTestSession {
  sessionId: string;
  testId: string;
  startedAtIso: string;
  lastUpdatedAtIso: string;
  durationSeconds: number;
  elapsedSecondsBeforeResume: number;
  lastTickTimestampMs: number;
  currentQuestionIndex: number;
  responses: Record<string, QuestionResponseState>;
  isSubmitted: boolean;
}

export interface QuestionScoreDetail {
  questionId: string;
  questionNumber: number;
  subject: SubjectType;
  chapter: string;
  topic: string;
  selectedOption: string | null;
  correctAnswer: string;
  status: 'correct' | 'incorrect' | 'unanswered';
  marksAwarded: number;
  maxMarks: number;
  negativeMarksApplied: number;
  timeSpentSeconds: number;
  markedForReview: boolean;
}

export interface SubjectPerformance {
  subject: SubjectType;
  totalQuestions: number;
  attemptedCount: number;
  correctCount: number;
  incorrectCount: number;
  unansweredCount: number;
  score: number;
  maxScore: number;
  percentage: number;
  accuracy: number;
  timeSpentSeconds: number;
}

export interface TopicMistakeFinding {
  subject: SubjectType;
  chapter: string;
  topic: string;
  totalQuestions: number;
  incorrectCount: number;
  unansweredCount: number;
  correctCount: number;
  marksLostToNegative: number;
  marksMissedOpportunity: number;
  totalTimeSpentSeconds: number;
  severity: 'high' | 'medium' | 'low';
  measuredFacts: string[];
  possibleExplanations: string[];
  recommendedAction: string;
  relatedQuestionIds: string[];
}

export interface TestAttemptResult {
  attemptId: string;
  testId: string;
  testTitle: string;
  exam: ExamType;
  classLevel: ClassLevel;
  category: 'chapter_test' | 'full_simulation';
  submittedAtIso: string;
  submissionReason: 'manual_submit' | 'timer_expired';
  totalScore: number;
  maxScore: number;
  positiveMarksEarned: number;
  negativeMarksDeducted: number;
  percentage: number; // (totalScore / maxScore) * 100 (clamped >= 0 for display or raw)
  rawPercentage: number;
  accuracy: number; // (correctCount / attemptedCount) * 100
  totalQuestions: number;
  attemptedCount: number;
  correctCount: number;
  incorrectCount: number;
  unansweredCount: number;
  totalTimeTakenSeconds: number;
  durationAllocatedSeconds: number;
  feedbackTier: 'excellent' | 'good' | 'developing';
  feedbackHeadline: string;
  feedbackMessage: string;
  subjectBreakdown: SubjectPerformance[];
  questionDetails: QuestionScoreDetail[];
  mistakeAnalysis: TopicMistakeFinding[];
  nextStudyRecommendations: string[];
}

export interface ResourceFilterState {
  searchQuery: string;
  exam: ExamType | 'ALL';
  classLevel: ClassLevel | 'ALL';
  subject: SubjectType | 'ALL';
  chapter: string | 'ALL';
  year: number | 'ALL';
  sessionOrSet: string | 'ALL';
  category: ResourceCategory | 'ALL';
  onlyPdfAvailable: boolean;
}
