import {
  ClassLevel,
  ExamType,
  Question,
  ResourceCategory,
  ResourceFilterState,
  StudyResource,
  SubjectType,
  VerificationStatus,
} from './types';

export interface AdaptiveFilterOptions {
  availableCategories: ResourceCategory[];
  availableChapters: string[];
  availableYears: number[];
  availableSessionsOrSets: string[];
  sessionFilterLabel: string;
  showSessionFilter: boolean;
}

export function getAdaptiveFilterMetadata(
  filters: Pick<ResourceFilterState, 'exam' | 'subject' | 'classLevel'>,
  allResources: StudyResource[]
): AdaptiveFilterOptions {
  // Narrow resources by exam, classLevel, and subject first to derive relevant options
  const scoped = allResources.filter((r) => {
    if (filters.exam !== 'ALL' && r.exam !== filters.exam) return false;
    if (
      filters.classLevel !== 'ALL' &&
      r.classLevel !== filters.classLevel &&
      r.classLevel !== 'Class 11 & 12'
    ) {
      return false;
    }
    if (filters.subject !== 'ALL' && r.subject !== filters.subject) return false;
    return true;
  });

  let availableCategories: ResourceCategory[];
  if (filters.exam === 'JEE Main') {
    availableCategories = [
      'JEE Main PYQ',
      'Practice Paper',
      'Answer Key & Solutions',
    ];
  } else if (filters.exam === 'CBSE Board') {
    availableCategories = [
      'Board PYQ',
      'Sample Paper',
      'Answer Key & Solutions',
    ];
  } else {
    availableCategories = [
      'Board PYQ',
      'JEE Main PYQ',
      'Sample Paper',
      'Practice Paper',
      'Answer Key & Solutions',
    ];
  }

  const chaptersSet = new Set<string>();
  const yearsSet = new Set<number>();
  const sessionsSet = new Set<string>();

  for (const r of scoped) {
    if (r.chapter) chaptersSet.add(r.chapter);
    if (r.year) yearsSet.add(r.year);
    if (r.sessionOrSet) sessionsSet.add(r.sessionOrSet);
  }

  const sessionFilterLabel =
    filters.exam === 'JEE Main'
      ? 'JEE Session & Shift'
      : filters.exam === 'CBSE Board'
      ? 'Board Paper Set / Code'
      : 'Session / Paper Set';

  return {
    availableCategories,
    availableChapters: Array.from(chaptersSet).sort(),
    availableYears: Array.from(yearsSet).sort((a, b) => b - a),
    availableSessionsOrSets: Array.from(sessionsSet).sort(),
    sessionFilterLabel,
    showSessionFilter: sessionsSet.size > 0,
  };
}

export function filterResources(
  resources: StudyResource[],
  filters: ResourceFilterState
): StudyResource[] {
  const queryTokens = filters.searchQuery
    .toLowerCase()
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  return resources.filter((resource) => {
    if (filters.exam !== 'ALL' && resource.exam !== filters.exam) {
      return false;
    }

    if (
      filters.classLevel !== 'ALL' &&
      resource.classLevel !== filters.classLevel &&
      resource.classLevel !== 'Class 11 & 12'
    ) {
      return false;
    }

    if (filters.subject !== 'ALL' && resource.subject !== filters.subject) {
      return false;
    }

    if (filters.chapter !== 'ALL' && resource.chapter !== filters.chapter) {
      return false;
    }

    if (filters.year !== 'ALL' && resource.year !== filters.year) {
      return false;
    }

    if (
      filters.sessionOrSet !== 'ALL' &&
      resource.sessionOrSet !== filters.sessionOrSet
    ) {
      return false;
    }

    if (filters.category !== 'ALL' && resource.category !== filters.category) {
      return false;
    }

    if (filters.onlyPdfAvailable && !resource.pdfAvailable) {
      return false;
    }

    if (queryTokens.length > 0) {
      const searchableBlob = [
        resource.title,
        resource.subtitle,
        resource.exam,
        resource.classLevel,
        resource.subject,
        resource.chapter || '',
        String(resource.year),
        resource.sessionOrSet || '',
        resource.category,
        resource.description,
        resource.verification.label,
        resource.verification.source,
      ]
        .join(' ')
        .toLowerCase();

      const matchesAllTokens = queryTokens.every((token) =>
        searchableBlob.includes(token)
      );
      if (!matchesAllTokens) return false;
    }

    return true;
  });
}

export interface QuestionFilterState {
  searchQuery: string;
  exam: ExamType | 'ALL';
  classLevel: ClassLevel | 'ALL';
  subject: SubjectType | 'ALL';
  chapter: string | 'ALL';
  difficulty: 'Easy' | 'Moderate' | 'Challenging' | 'ALL';
  verificationStatus: VerificationStatus | 'ALL';
  onlyWithDiagrams: boolean;
}

export function filterQuestions(
  questions: Question[],
  filters: QuestionFilterState
): Question[] {
  const queryTokens = filters.searchQuery
    .toLowerCase()
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  return questions.filter((q) => {
    if (filters.exam !== 'ALL' && q.exam !== filters.exam) return false;
    if (
      filters.classLevel !== 'ALL' &&
      q.classLevel !== filters.classLevel &&
      q.classLevel !== 'Class 11 & 12'
    ) {
      return false;
    }
    if (filters.subject !== 'ALL' && q.subject !== filters.subject) return false;
    if (filters.chapter !== 'ALL' && q.chapter !== filters.chapter) return false;
    if (filters.difficulty !== 'ALL' && q.difficulty !== filters.difficulty) {
      return false;
    }
    if (
      filters.verificationStatus !== 'ALL' &&
      q.verification.status !== filters.verificationStatus
    ) {
      return false;
    }
    if (filters.onlyWithDiagrams && !q.diagram) {
      return false;
    }

    if (queryTokens.length > 0) {
      const searchableBlob = [
        q.id,
        q.exam,
        q.classLevel,
        q.subject,
        q.chapter,
        q.topic,
        q.questionText,
        q.explanation,
        q.verification.source,
      ]
        .join(' ')
        .toLowerCase();

      return queryTokens.every((t) => searchableBlob.includes(t));
    }

    return true;
  });
}
